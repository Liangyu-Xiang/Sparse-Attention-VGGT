"""Dedicated true probe rows;ordinary AV keeps its original MMA layout.

Ordinary AV masks probe Q loads/stores (Tensor Core padding remains). Probe rows
compute both formal AV and raw historical evidence once in a small-row kernel.
"""
import torch,triton
import triton.language as tl
from .teacher_history_attention import _bias

@triton.jit
def _main(Q,K,V,IDS,SPECIAL,BIAS,OUT,H:tl.constexpr,R:tl.constexpr,A:tl.constexpr,S:tl.constexpr,D:tl.constexpr,QH:tl.constexpr,KH:tl.constexpr,VH:tl.constexpr,SCALE:tl.constexpr,BD:tl.constexpr,BK:tl.constexpr,P:tl.constexpr,SPLIT:tl.constexpr):
 t=tl.program_id(0);h=tl.program_id(1);row=tl.arange(0,64);rr=t*64+row;g=t//4;dd=tl.arange(0,BD);kk=tl.arange(0,BK);valid_query=rr<R
 if SPLIT:
  for slot in tl.static_range(P):valid_query=valid_query&(rr!=tl.minimum(g*256+slot*(256//P)+32,R-1))
 q=tl.load(Q+h*QH+rr[:,None]*D+dd[None,:],valid_query[:,None]&(dd[None,:]<D),0.)
 maximum=tl.full((64,),-float('inf'),tl.float32);den=tl.zeros((64,),tl.float32);acc=tl.zeros((64,BD),tl.float32)
 for tile in range(tl.cdiv(S+A,BK)):
  at=tile*BK+kk;key=tl.load(IDS+g*A+at-S,(at>=S)&(at<S+A),-1);special=tl.load(SPECIAL+at,at<S,0);key=tl.where(at<S,special,key);valid=(at<S+A)&(key>=0);bias=tl.load(BIAS+g*A+at-S,(at>=S)&valid,0.)
  k=tl.load(K+h*KH+tl.maximum(key,0)[None,:]*D+dd[:,None],valid[None,:]&(dd[:,None]<D),0.);v=tl.load(V+h*VH+tl.maximum(key,0)[:,None]*D+dd[None,:],valid[:,None]&(dd[None,:]<D),0.)
  z=tl.where(valid[None,:],tl.dot(q,k,allow_tf32=False)*SCALE+bias[None,:],-float('inf'));mx=tl.maximum(maximum,tl.max(z,1));safe=tl.where(mx==-float('inf'),0.,mx);alpha=tl.exp(maximum-safe);p=tl.exp(z-safe[:,None]);acc=acc*alpha[:,None]+tl.dot(p.to(v.dtype),v,allow_tf32=False);den=den*alpha+tl.sum(p,1);maximum=mx
 tl.store(OUT+(h*R+rr[:,None])*D+dd[None,:],acc/den[:,None],valid_query[:,None]&(dd[None,:]<D))

@triton.jit
def _probes(Q,K,V,IDS,SPECIAL,BIAS,INV,OUT,RAW,SHIFT,LSE,H:tl.constexpr,R:tl.constexpr,G:tl.constexpr,A:tl.constexpr,S:tl.constexpr,D:tl.constexpr,QH:tl.constexpr,KH:tl.constexpr,VH:tl.constexpr,SCALE:tl.constexpr,BD:tl.constexpr,BK:tl.constexpr,P:tl.constexpr):
 g=tl.program_id(0);h=tl.program_id(1);row=tl.arange(0,16);pos=tl.minimum(g*256+row*(256//P)+32,R-1);dd=tl.arange(0,BD);kk=tl.arange(0,BK)
 q=tl.load(Q+h*QH+pos[:,None]*D+dd[None,:],(row[:,None]<P)&(dd[None,:]<D),0.)
 maximum=tl.full((16,),-float('inf'),tl.float32);den=tl.zeros((16,),tl.float32);rawden=tl.zeros((16,),tl.float32);acc=tl.zeros((16,BD),tl.float32)
 for tile in range(tl.cdiv(S+A,BK)):
  at=tile*BK+kk;key=tl.load(IDS+g*A+at-S,(at>=S)&(at<S+A),-1);special=tl.load(SPECIAL+at,at<S,0);key=tl.where(at<S,special,key);valid=(at<S+A)&(key>=0)
  bias=tl.load(BIAS+g*A+at-S,(at>=S)&valid,0.);inv=tl.load(INV+g*A+at-S,(at>=S)&valid,1.)
  k=tl.load(K+h*KH+tl.maximum(key,0)[None,:]*D+dd[:,None],valid[None,:]&(dd[:,None]<D),0.);v=tl.load(V+h*VH+tl.maximum(key,0)[:,None]*D+dd[None,:],valid[:,None]&(dd[None,:]<D),0.)
  raw=tl.dot(q,k,allow_tf32=False)*SCALE;rv=tl.where(valid[None,:],raw,-float('inf'));center=tl.max(rv,1);center=tl.where(center==-float('inf'),0.,center)
  tl.store(RAW+((g*H+h)*P+row[:,None])*(S+A)+at[None,:],rv-center[:,None],(row[:,None]<P)&(at[None,:]<S+A));tl.store(SHIFT+((g*H+h)*P+row)*tl.cdiv(S+A,BK)+tile,center,row<P)
  z=tl.where(valid[None,:],raw+bias[None,:],-float('inf'));mx=tl.maximum(maximum,tl.max(z,1));safe=tl.where(mx==-float('inf'),0.,mx);alpha=tl.exp(maximum-safe);p=tl.exp(z-safe[:,None]);rawden=rawden*alpha+tl.sum(p*inv[None,:],1);acc=acc*alpha[:,None]+tl.dot(p.to(v.dtype),v,allow_tf32=False);den=den*alpha+tl.sum(p,1);maximum=mx
 previous=tl.minimum(g*256+(row-1)*(256//P)+32,R-1);first=(row==0)|(pos!=previous)
 tl.store(OUT+(h*R+pos[:,None])*D+dd[None,:],acc/den[:,None],(row[:,None]<P)&first[:,None]&(dd[None,:]<D));tl.store(LSE+(h*G+g)*P+row,maximum+tl.log(tl.maximum(rawden,1.e-37)),row<P)

def attention(q,k,v,ids,specials,weights,scale,probes=4,capture=True,warps=4,stages=2):
 h,r,d=q.shape;g,a=ids.shape;s=len(specials);assert g==triton.cdiv(r,256)
 bias=torch.empty_like(weights);inv=torch.empty_like(weights);_bias[(triton.cdiv(weights.numel(),256),)](weights,bias,inv,weights.numel(),256,num_warps=4)
 out=torch.empty_like(q);raw=torch.empty((g,h,probes,s+a),device=q.device,dtype=torch.float16) if capture else out;shift=torch.empty((g,h,probes,triton.cdiv(s+a,128)),device=q.device) if capture else out;lse=torch.empty((h,g,probes),device=q.device) if capture else out
 _main[(triton.cdiv(r,64),h)](q,k,v,ids,specials,bias,out,h,r,a,s,d,q.stride(0),k.stride(0),v.stride(0),scale,triton.next_power_of_2(d),128,probes,capture,num_warps=warps,num_stages=stages)
 if capture:_probes[(g,h)](q,k,v,ids,specials,bias,inv,out,raw,shift,lse,h,r,g,a,s,d,q.stride(0),k.stride(0),v.stride(0),scale,triton.next_power_of_2(d),128,probes,num_warps=4,num_stages=2)
 return out,dict(encoded=raw,shifts=shift,raw_lse=lse,probes=probes,block_keys=128)
