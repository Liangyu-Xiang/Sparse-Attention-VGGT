"""Exact compact reuse operations. No state pruning or approximate allocator.

Value geometry is independent of query groups: cache within-cluster cosine
costs once per layer, then contract the EXISTING arbitrary per-token prior.
This preserves cross-grid priors, clamp/self conventions and all H-only states.
"""
import torch
import triton
import triton.language as tl


@triton.jit
def _geometry(Z,MEM,LABEL,RANK,REP,DIST,DR,P:tl.constexpr,D:tl.constexpr,M:tl.constexpr,BD:tl.constexpr,B:tl.constexpr,L2:tl.constexpr):
    pair=tl.program_id(0)*B+tl.arange(0,B);j=pair//M;col=pair%M;dd=tl.arange(0,BD)
    valid=j<P;c=tl.load(LABEL+j,valid,0);other=tl.load(MEM+c*M+col,valid,-1)
    z=tl.load(Z+j[:,None]*D+dd[None,:],valid[:,None]&(dd[None,:]<D),0.)
    zo=tl.load(Z+tl.maximum(other,0)[:,None]*D+dd[None,:],valid[:,None]&(other[:,None]>=0)&(dd[None,:]<D),0.)
    distance=tl.sum((z-zo)*(z-zo),1) if L2 else tl.minimum(2.,tl.maximum(0.,1.-tl.sum(z*zo,1)))
    distance=tl.where(j==other,0.,distance)
    tl.store(DIST+pair,distance,valid)
    rep=tl.load(REP+c,valid,0)
    tl.store(DR+j,distance,valid&(other==rep))


def prepare_geometry(z,labels,reps,population,l2=False):
    p,d=z.shape;f=len(reps)
    width=triton.next_power_of_2(int(population.max()))
    # A pathological oversized cluster falls back to the original kernels;
    # this is an implementation-memory guard, never a state/quality change.
    if width>512:return None
    order=labels.argsort(stable=True)
    starts=population.long().cumsum(0)-population.long()
    rank=torch.empty(p,device=z.device,dtype=torch.int32)
    rank[order]=(torch.arange(p,device=z.device)-starts[labels[order]]).int()
    members=torch.full((f,width),-1,device=z.device,dtype=torch.int32)
    members[labels,rank.long()]=torch.arange(p,device=z.device,dtype=torch.int32)
    distances=torch.empty((p,width),device=z.device,dtype=torch.float32)
    rep_distance=torch.empty(p,device=z.device,dtype=torch.float32)
    _geometry[(triton.cdiv(p*width,128),)](z,members,labels,rank,reps,distances,rep_distance,p,d,width,triton.next_power_of_2(d),128,l2,num_warps=4)
    return dict(members=members,rank=rank,distances=distances,rep_distance=rep_distance,norm2=(z*z).sum(1).contiguous(),l2=l2,width=width)


@triton.jit
def _top(POS,PRIOR,MEM,REP,OUT,DISCARD,P:tl.constexpr,F:tl.constexpr,M:tl.constexpr,H:tl.constexpr,B:tl.constexpr):
    group=tl.program_id(0);c=tl.program_id(1)*B+tl.arange(0,B);col=tl.arange(0,M)
    members=tl.load(MEM+c[:,None]*M+col[None,:],c[:,None]<F,-1)
    pos=tl.load(POS+group*(P+1)+tl.maximum(members,0),(c[:,None]<F)&(members>=0),-1)
    rep=tl.load(REP+c,c<F,0)
    mass=tl.load(PRIOR+group*P+tl.maximum(members,0),(c[:,None]<F)&(members>=0),0.)
    valid=(members>=0)&(pos>=0)&(members!=rep[:,None])&(mass>0)&(c[:,None]<F)
    total=tl.sum(valid.to(tl.int32),1)
    scores=tl.where(valid,mass,-1.)
    for slot in tl.static_range(H):
        best=tl.max(scores,1)
        position=tl.min(tl.where((scores==best[:,None])&(best[:,None]>0),pos,2147483647),1)
        winner=(pos==position[:,None])&(scores==best[:,None])&(best[:,None]>0)
        key=tl.max(tl.where(winner,members,-1),1)
        tl.store(OUT+(group*F+c)*H+slot,key,c<F)
        scores=tl.where(winner,-1.,scores)
    tl.store(DISCARD+group*F+c,tl.maximum(total-H,0),c<F)


def top_history(ids,prior,reps,geometry,limit):
    g,p=prior.shape;f=len(reps)
    positions=torch.full((g,p+1),-1,device=prior.device,dtype=torch.int32)
    source=torch.arange(ids.shape[1],device=ids.device,dtype=torch.int32)[None].expand_as(ids)
    positions.scatter_(1,ids.long().masked_fill(ids<0,p),source.masked_fill(ids<0,-1))
    hids=torch.empty((g,f,limit),device=ids.device,dtype=torch.int32)
    discard=torch.empty((g,f),device=ids.device,dtype=torch.int32)
    _top[(g,triton.cdiv(f,32))](positions,prior,geometry['members'],reps,hids,discard,p,f,geometry['width'],limit,32,num_warps=4)
    return hids,discard.sum(1)


@triton.jit
def _loss(DIST,DR,NORM2,RANK,LABEL,HIDS,PRIOR,E,ACTIVE_ONLY:tl.constexpr,L2:tl.constexpr,P:tl.constexpr,F:tl.constexpr,M:tl.constexpr,H:tl.constexpr,B:tl.constexpr):
    group=tl.program_id(0);j=tl.program_id(1)*B+tl.arange(0,B);valid=j<P
    c=tl.load(LABEL+j,valid,0);a=tl.load(PRIOR+group*P+j,valid,0.);dr=tl.load(DR+j,valid,0.)
    base=(group*F+c)*(2*H+3)
    if L2:tl.atomic_add(E+base,a*tl.load(NORM2+j,valid,0.),valid,sem='relaxed')
    tl.atomic_add(E+base+1,a*dr,valid,sem='relaxed')
    minimum=tl.full((B,),1.e30 if L2 else 2.,tl.float32);chosen=tl.full((B,),False,tl.int1)
    for slot in tl.static_range(H):
        h=tl.load(HIDS+(group*F+c)*H+slot,valid,-1)
        rank=tl.load(RANK+tl.maximum(h,0),valid&(h>=0),0)
        d=tl.load(DIST+j*M+rank,valid,2.)
        minimum=tl.minimum(minimum,tl.where(h>=0,d,1.e30 if L2 else 2.));chosen=chosen|(j==h)
        tl.atomic_add(E+base+2+slot,a*minimum,valid&((h>=0) if ACTIVE_ONLY else True),sem='relaxed')
        tl.atomic_add(E+base+2+H+slot,a*tl.where(chosen,0.,dr),valid&((h>=0) if ACTIVE_ONLY else True),sem='relaxed')


def losses(labels,hids,prior,geometry,clusters):
    g,p=prior.shape;h=hids.shape[-1]
    errors=torch.zeros((g,clusters,2*h+3),device=prior.device)
    _loss[(g,triton.cdiv(p,256))](geometry['distances'],geometry['rep_distance'],geometry['norm2'],geometry['rank'],labels,hids,prior,errors,geometry.get('skip_invalid_states',False),geometry['l2'],p,clusters,geometry['width'],h,256,num_warps=4)
    return errors


@triton.jit
def _multi_transfer(DIST,RANK,LABEL,IDS,PRIOR,SEL,MASS,P:tl.constexpr,F:tl.constexpr,M:tl.constexpr,H:tl.constexpr,B:tl.constexpr):
    group=tl.program_id(0);j=tl.program_id(1)*B+tl.arange(0,B);valid=j<P
    c=tl.load(LABEL+j,valid,0);s=tl.load(SEL+group*F+c,valid,0)
    active=valid&(s>=3)&(s<=H+1)
    if tl.sum(active.to(tl.int32),0)>0:
        nearest=tl.full((B,),0,tl.int32);minimum=tl.full((B,),float('inf'),tl.float32)
        for slot in tl.static_range(H):
            h=tl.load(IDS+(group*F+c)*H+slot,active,-1)
            rank=tl.load(RANK+tl.maximum(h,0),active&(h>=0),0)
            d=tl.load(DIST+j*M+rank,active,2.)
            d=tl.where(j==h,-1.,d)
            use=active&(slot<s-1)&(h>=0);better=use&(d<minimum)
            nearest=tl.where(better,h,nearest);minimum=tl.where(better,d,minimum)
        a=tl.load(PRIOR+group*P+j,active,0.)
        tl.atomic_add(MASS+group*P+nearest,a,active,sem='relaxed')


@triton.jit
def _analytic_transfer(KEYS,LABEL,REP,HIDS,PRIOR,PI,SEL,MASS,W,MEM,P:tl.constexpr,F:tl.constexpr,A:tl.constexpr,H:tl.constexpr,M:tl.constexpr,B:tl.constexpr):
    group=tl.program_id(0);col=tl.program_id(1)*B+tl.arange(0,B)
    key=tl.load(KEYS+group*A+col,col<A,-1);valid=(col<A)&(key>=0)
    c=tl.load(LABEL+tl.maximum(key,0),valid,0);rep=tl.load(REP+c,valid,0)
    state=tl.load(SEL+group*F+c,valid,0)
    own=tl.load(PRIOR+group*P+tl.maximum(key,0),valid,0.)
    pi=tl.load(PI+group*F+c,valid,0.)
    hr=(state>=H+2)&(state<=2*H+1);total=tl.full((B,),0.,tl.float32)
    for slot in tl.static_range(H):
        hist=tl.load(HIDS+(group*F+c)*H+slot,valid&hr,-1)
        a=tl.load(PRIOR+group*P+tl.maximum(hist,0),valid&hr&(hist>=0),0.)
        total+=tl.where(slot<state-H-1,a,0.)
    assigned=tl.where((state==1)|(state==2),pi,own)
    residual=pi-total
    unstable=valid&hr&(key==rep)&(residual<.01*pi)
    if tl.sum(unstable.to(tl.int32),0)>0:
        col_member=tl.arange(0,M)
        members=tl.load(MEM+c[:,None]*M+col_member[None,:],unstable[:,None],-1)
        remaining=members>=0
        for slot in tl.static_range(H):
            hist=tl.load(HIDS+(group*F+c)*H+slot,unstable,-1)
            remaining=remaining&~((members==hist[:,None])&(slot<state[:,None]-H-1))
        values=tl.load(PRIOR+group*P+tl.maximum(members,0),unstable[:,None]&remaining,0.)
        residual=tl.where(unstable,tl.sum(values,1),residual)
    assigned=tl.where(hr&(key==rep),residual,assigned)
    multiple=(state>=3)&(state<=H+1)
    multi_mass=tl.load(MASS+group*P+tl.maximum(key,0),valid&multiple,0.)
    assigned=tl.where(multiple,multi_mass,assigned)
    weight=tl.maximum(1.,assigned/tl.maximum(own,1.e-30))
    tl.store(W+group*A+col,tl.where(valid,weight,0.),col<A)


def transfer(selected,labels,reps,hids,prior,pi,packed,geometry):
    g,p=prior.shape;f=len(reps);h=hids.shape[-1]
    mass=torch.zeros_like(prior)
    _multi_transfer[(g,triton.cdiv(p,256))](geometry['distances'],geometry['rank'],labels,hids,prior,selected,mass,p,f,geometry['width'],h,256,num_warps=4)
    weights=torch.empty(packed.shape,device=prior.device,dtype=torch.float32)
    _analytic_transfer[(g,triton.cdiv(packed.shape[1],256))](packed,labels,reps,hids,prior,pi,selected,mass,weights,geometry['members'],p,f,packed.shape[1],h,geometry['width'],256,num_warps=4)
    return weights


@triton.jit
def _choose(E,C,DUAL,PART,SEL,F:tl.constexpr,S:tl.constexpr,T:tl.constexpr,FINAL:tl.constexpr,B:tl.constexpr,BS:tl.constexpr):
    group=tl.program_id(0);tile=tl.program_id(1)
    c=tile*B+tl.arange(0,B);s=tl.arange(0,BS)
    value=tl.load(E+(group*F+c[:,None])*S+s[None,:],(c[:,None]<F)&(s[None,:]<S),float('inf'))
    cost=tl.load(C+(group*F+c[:,None])*S+s[None,:],(c[:,None]<F)&(s[None,:]<S),0.)
    lo=tl.load(DUAL+group*2);hi=tl.load(DUAL+group*2+1)
    lam=hi if FINAL else (lo+hi)*.5
    objective=value+lam*cost
    winner=tl.argmin(objective,1,tie_break_left=True)
    chosen=tl.sum(tl.where(s[None,:]==winner[:,None],cost,0.),1)
    tl.store(PART+group*T+tile,tl.sum(tl.where(c<F,chosen,0.),0))
    if FINAL:tl.store(SEL+group*F+c,winner,c<F)


@triton.jit
def _dual(PART,DUAL,T:tl.constexpr,BUDGET:tl.constexpr,BT:tl.constexpr):
    group=tl.program_id(0);t=tl.arange(0,BT)
    count=tl.sum(tl.load(PART+group*T+t,t<T,0.),0)
    lo=tl.load(DUAL+group*2);hi=tl.load(DUAL+group*2+1);mid=(lo+hi)*.5
    tl.store(DUAL+group*2,tl.where(count>BUDGET,mid,lo))
    tl.store(DUAL+group*2+1,tl.where(count>BUDGET,hi,mid))


def budget(errors,costs,upper,cap,iterations):
    g,f,s=errors.shape;tiles=triton.cdiv(f,128)
    dual=torch.stack((torch.zeros_like(upper),upper),1).contiguous()
    partial=torch.empty((g,tiles),device=errors.device);selected=torch.empty((g,f),device=errors.device,dtype=torch.int64)
    for _ in range(iterations):
        _choose[(g,tiles)](errors,costs,dual,partial,selected,f,s,tiles,False,128,triton.next_power_of_2(s),num_warps=4,enable_fp_fusion=False)
        _dual[(g,)](partial,dual,tiles,cap,triton.next_power_of_2(tiles),num_warps=4,enable_fp_fusion=False)
    _choose[(g,tiles)](errors,costs,dual,partial,selected,f,s,tiles,True,128,triton.next_power_of_2(s),num_warps=4,enable_fp_fusion=False)
    return selected,partial.sum(1)


@triton.jit
def _support_raw(SEL,HIDS,REP,LABEL,POP,group,col,F:tl.constexpr,P:tl.constexpr,H:tl.constexpr):
    is_h=col<F*H;is_rep=(col>=F*H)&(col<F*(H+1));is_member=(col>=F*(H+1))&(col<F*(H+1)+P)
    cluster=tl.where(is_h,col//H,col-F*H)
    member=col-F*(H+1)
    member_cluster=tl.load(LABEL+tl.maximum(member,0),is_member,0)
    cluster=tl.where(is_member,member_cluster,cluster)
    safe=tl.maximum(0,tl.minimum(cluster,F-1))
    state=tl.load(SEL+group*F+safe)
    t=tl.where((state>=2)&(state<=H+1),state-1,tl.where((state>=H+2)&(state<=2*H+1),state-H-1,0))
    history=tl.load(HIDS+(group*F+safe)*H+col%H,is_h,-1)
    rep=tl.load(REP+safe,is_rep,-1)
    valid=(is_h&(col%H<t)&(history>=0))|(is_rep&((state==1)|((state>=H+2)&(state<=2*H+1))))|(is_member&(state==2*H+2))
    key=tl.where(is_h,history,tl.where(is_rep,rep,member))
    return key,valid


@triton.jit
def _pack(SEL,HIDS,REP,LABEL,POP,COUNTS,OUT,F:tl.constexpr,P:tl.constexpr,H:tl.constexpr,A:tl.constexpr,T:tl.constexpr,WRITE:tl.constexpr,B:tl.constexpr):
    group=tl.program_id(0);tile=tl.program_id(1);col=tile*B+tl.arange(0,B)
    key,valid=_support_raw(SEL,HIDS,REP,LABEL,POP,group,col,F,P,H)
    if WRITE:
        before=tl.load(COUNTS+group*T+tile-1,tile>0,0)
        pos=before+tl.cumsum(valid.to(tl.int32),0)-1
        tl.store(OUT+group*A+pos,key,valid&(pos<A))
    else:tl.store(COUNTS+group*T+tile,tl.sum(valid.to(tl.int32),0))


def pack(selected,hids,reps,labels,population,cap):
    g,f=selected.shape;h=hids.shape[-1];p=len(labels);tiles=triton.cdiv(f*(h+1)+p,1024)
    counts=torch.empty((g,tiles),device=selected.device,dtype=torch.int32)
    ids=torch.full((g,cap),-1,device=selected.device,dtype=torch.int32)
    _pack[(g,tiles)](selected,hids,reps,labels,population,counts,ids,f,p,h,cap,tiles,False,1024,num_warps=4)
    prefix=counts.cumsum(1,dtype=torch.int32).contiguous()
    _pack[(g,tiles)](selected,hids,reps,labels,population,prefix,ids,f,p,h,cap,tiles,True,1024,num_warps=4)
    hr=(selected>=h+2)&(selected<=2*h+1)
    t=torch.where((selected>=2)&(selected<=h+1),selected-1,torch.where(hr,selected-h-1,0))
    rep=(selected==1)|hr
    record=dict(reuse_edges=t.sum(1),representatives=rep.sum(1),exact_edges=((selected==2*h+2)*population[None]).sum(1),dropped_clusters=(selected==0).sum(1),counts=counts.sum(1))
    return ids,ids>=0,record


@triton.jit
def _finalize(E,PI,DROP_VALUES,POP,HIDS,ALLOW,COST,OBJ,F:tl.constexpr,H:tl.constexpr,S:tl.constexpr,DROP:tl.constexpr,L2:tl.constexpr,CUSTOM_DROP:tl.constexpr,B:tl.constexpr,BS:tl.constexpr):
    group=tl.program_id(0);c=tl.program_id(1)*B+tl.arange(0,B);s=tl.arange(0,BS)
    value=tl.load(E+(group*F+c[:,None])*S+s[None,:],(c[:,None]<F)&(s[None,:]<S),0.)
    baseline=tl.load(E+(group*F+c)*S+1,c<F,0.)
    pi=tl.load(PI+group*F+c,c<F,0.);pop=tl.load(POP+c,c<F,0.)
    only=(s>=2)&(s<=H+1);hr=(s>=H+2)&(s<=2*H+1)
    amount=tl.where(only,s-1,tl.where(hr,s-H-1,0))
    prefix=tl.full((B,BS),True,tl.int1)
    for slot in tl.static_range(H):
        hid=tl.load(HIDS+(group*F+c)*H+slot,c<F,-1)
        prefix=prefix&((hid[:,None]>=0)|(slot>=amount[None,:]))
    valid=~(only[None,:]|hr[None,:])|prefix
    valid=valid&(~hr[None,:]|(pop[:,None]>amount[None,:]))
    allowed=tl.load(ALLOW+group*F+c,c<F,False)
    dv=tl.load(DROP_VALUES+group*F+c,c<F,0.) if CUSTOM_DROP else pi
    value=tl.where(s[None,:]==0,(dv[:,None] if CUSTOM_DROP else DROP*(value if L2 else pi[:,None])),value)
    value=tl.where(s[None,:]==S-1,tl.where(allowed[:,None],0.,float('inf')),value)
    value=tl.where(valid,value,float('inf'))
    cost=tl.where(s==0,0,tl.where(s==1,1,tl.where(only,amount,tl.where(hr,amount+1,0)))).to(tl.float32)
    costs=tl.where(s[None,:]==S-1,pop[:,None],cost[None,:])
    mask=(c[:,None]<F)&(s[None,:]<S)
    tl.store(E+(group*F+c[:,None])*S+s[None,:],value,mask)
    tl.store(COST+(group*F+c[:,None])*S+s[None,:],costs,mask)
    tl.store(OBJ+(group*F+c[:,None])*S+s[None,:],value-baseline[:,None],mask)


def finalize(errors,pi,population,hids,allowed,drop,l2=False,drop_values=None):
    g,f,s=errors.shape;h=hids.shape[-1]
    costs=torch.empty_like(errors);objective=torch.empty_like(errors)
    _finalize[(g,triton.cdiv(f,128))](errors,pi,pi if drop_values is None else drop_values,population,hids,allowed,costs,objective,f,h,s,drop,l2,drop_values is not None,128,triton.next_power_of_2(s),num_warps=4,enable_fp_fusion=False)
    return errors,costs,objective


@triton.jit
def _diagnostics(E,SEL,HIDS,OUT,F:tl.constexpr,H:tl.constexpr,S:tl.constexpr,T:tl.constexpr,K:tl.constexpr,B:tl.constexpr,BS:tl.constexpr):
    group=tl.program_id(0);tile=tl.program_id(1);c=tile*B+tl.arange(0,B);s=tl.arange(0,BS)
    valid=(c[:,None]<F)&(s[None,:]<S)
    error=tl.load(E+(group*F+c[:,None])*S+s[None,:],valid,float('inf'))
    rep=tl.load(E+(group*F+c)*S+1,c<F,0.)
    gain=rep[:,None]-error;finite=valid&(error!=float('inf'))
    selected=tl.load(SEL+group*F+c,c<F,0)
    counts=tl.sum(((s[None,:]==selected[:,None])&valid).to(tl.float32),0)
    gain_sum=tl.sum(tl.where(finite,gain,0.),0)
    valid_count=tl.sum(finite.to(tl.float32),0)
    base=(group*T+tile)*K
    tl.store(OUT+base+s,counts,s<S);tl.store(OUT+base+S+s,gain_sum,s<S);tl.store(OUT+base+2*S+s,valid_count,s<S)
    positive=finite&(gain>0);negative=finite&(gain<0)
    tl.store(OUT+base+3*S,tl.sum(tl.sum(positive.to(tl.float32),1),0))
    tl.store(OUT+base+3*S+1,tl.sum(tl.sum(tl.where(positive,gain,0.),1),0))
    tl.store(OUT+base+3*S+2,tl.sum(tl.sum(tl.where(negative,gain,0.),1),0))
    tl.store(OUT+base+3*S+3,tl.min(tl.min(tl.where(finite,gain,float('inf')),1),0))
    tl.store(OUT+base+3*S+4,tl.max(tl.max(tl.where(finite,gain,-float('inf')),1),0))
    selected_gain=tl.sum(tl.where((s[None,:]==selected[:,None])&finite,gain,0.),1)
    tl.store(OUT+base+3*S+5,tl.sum(selected_gain,0))
    candidates=tl.full((B,),0,tl.int32)
    for slot in tl.static_range(H):
        hid=tl.load(HIDS+(group*F+c)*H+slot,c<F,-1)
        candidates+=(hid>=0).to(tl.int32)
    tl.store(OUT+base+3*S+6,tl.sum(candidates,0))
    drop=tl.load(E+(group*F+c)*S,c<F,0.)
    chosen=tl.load(E+(group*F+c)*S+selected,c<F,0.)
    tl.store(OUT+base+3*S+7,tl.sum(drop,0));tl.store(OUT+base+3*S+8,tl.sum(chosen,0))
    amount=tl.where((selected>=2)&(selected<=H+1),selected-1,tl.where((selected>=H+2)&(selected<=2*H+1),selected-H-1,0))
    for count in tl.static_range(H+1):
        tl.store(OUT+base+3*S+9+count,tl.sum(((amount==count)&(c<F)).to(tl.float32),0))


@triton.jit
def _observed(IDS,LABEL,REP,OUT,A:tl.constexpr,T:tl.constexpr,B:tl.constexpr):
    group=tl.program_id(0);tile=tl.program_id(1);col=tile*B+tl.arange(0,B)
    key=tl.load(IDS+group*A+col,col<A,-1);valid=(col<A)&(key>=0)
    cluster=tl.load(LABEL+tl.maximum(key,0),valid,0);rep=tl.load(REP+cluster,valid,-1)
    tl.store(OUT+(group*T+tile)*2,tl.sum(valid.to(tl.float32),0))
    tl.store(OUT+(group*T+tile)*2+1,tl.sum((valid&(key==rep)).to(tl.float32),0))


def diagnostics(errors,selected,hids,old_ids,labels,reps):
    g,f,s=errors.shape;h=hids.shape[-1];tiles=triton.cdiv(f,128);k=3*s+9+h+1
    partial=torch.empty((g,tiles,k),device=errors.device)
    _diagnostics[(g,tiles)](errors,selected,hids,partial,f,h,s,tiles,k,128,triton.next_power_of_2(s),num_warps=4)
    sums=partial.sum(1);gain_mean=sums[:,s:2*s]/sums[:,2*s:3*s].clamp_min(1)
    record={f'state_{i}_clusters':sums[:,i] for i in range(s)}
    record.update({f'gain_{i}':gain_mean[:,i] for i in range(s)})
    names=('positive_gain_states','positive_gain_sum','negative_gain_sum','gain_min','gain_max','selected_gain','history_candidates','proxy_drop_error','proxy_selected_error')
    for i,name in enumerate(names):record[name]=sums[:,3*s+i]
    record['gain_min']=partial[:,:,3*s+3].amin(1);record['gain_max']=partial[:,:,3*s+4].amax(1)
    for count in range(h+1):record[f'selected_history_count_{count}_clusters']=sums[:,3*s+9+count]
    banktiles=triton.cdiv(old_ids.shape[1],256)
    observed=torch.empty((g,banktiles,2),device=errors.device)
    _observed[(g,banktiles)](old_ids,labels,reps,observed,old_ids.shape[1],banktiles,256,num_warps=4)
    stats=observed.sum(1)
    record['observed_history']=stats[:,0];record['history_rep_overlap']=stats[:,1]
    return record
