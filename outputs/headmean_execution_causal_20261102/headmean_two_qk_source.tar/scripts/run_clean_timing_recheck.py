import os,sys,json,time,subprocess,concurrent.futures,statistics
from pathlib import Path
ROOT=Path('/tmp/eth3d_drop_raw_history_20261031');OUT=Path('/mnt/rfs/users/xiangliangyu/projects/Sparse-Attention-VGGT/outputs/eth3d_drop_raw_history_20261031/timing_recheck');OUT.mkdir(parents=True,exist_ok=True)
SCENES=['courtyard','electro','kicker','pipes','relief','delivery_area','facade','office','playground','relief_2','terrains'];METHODS=['dense','rep_m5c','rep_m5c_drop_mean','rep_m5c_drop_raw','rep_m5c_fewer_clusters']
def apps(uuid):
 r=subprocess.run(['nvidia-smi','--query-compute-apps=gpu_uuid,pid','--format=csv,noheader,nounits'],capture_output=True,text=True,check=True)
 return {int(t[1]) for l in r.stdout.splitlines() if len(t:=[x.strip() for x in l.split(',')])>=2 and t[0]==uuid}
def work(gpu,scenes):
 uuid=subprocess.check_output(['nvidia-smi','-i',str(gpu),'--query-gpu=uuid','--format=csv,noheader'],text=True).strip();env=dict(os.environ,CUDA_DEVICE_ORDER='PCI_BUS_ID',CUDA_VISIBLE_DEVICES=str(gpu),OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',PYTHONPATH=str(ROOT),LD_LIBRARY_PATH='/mnt/rfs/users/xiangliangyu/conda-envs/vggt-baseline/lib')
 for scene in scenes:
  for method in METHODS:
   for attempt in range(3):
    while apps(uuid):time.sleep(5)
    folder=OUT/scene/method/('attempt_'+str(attempt));folder.parent.mkdir(parents=True,exist_ok=True)
    cmd=[sys.executable,'-u','scripts/evaluate_reuse_cosine.py','--scene',scene,'--method',method,'--frames','128','--output-dir',str(folder),'--warmup','1','--repeats','3','--diagnostic']
    foreign=set()
    with (folder.parent/('attempt_'+str(attempt)+'.log')).open('w') as f:
     proc=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
     while proc.poll() is None:foreign|=apps(uuid)-{proc.pid};time.sleep(2)
    meta={'gpu':gpu,'uuid':uuid,'foreign_pids':sorted(foreign),'returncode':proc.returncode,'attempt':attempt,'poll_seconds':2};folder.mkdir(exist_ok=True,parents=True);(folder/'gpu_monitor.json').write_text(json.dumps(meta,indent=2)+'\n')
    if proc.returncode==0 and not foreign:
     (folder.parent/'selected.json').write_text(json.dumps(meta,indent=2)+'\n');break
    if not foreign:break
   print(scene,method,meta,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
 jobs=[pool.submit(work,i,SCENES[i::8]) for i in range(8)]
 for j in jobs:j.result()
(OUT/'completed.json').write_text(json.dumps({'all_terminal':True})+'\n')
