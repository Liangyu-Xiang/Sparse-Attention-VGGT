import subprocess,sys,json,time
from pathlib import Path
out=Path('/mnt/rfs/users/xiangliangyu/projects/Sparse-Attention-VGGT/outputs/zdrop_shared_rms_20261031')
for name,root,args in [('7scenes','/tmp/zdrop_eval_20261031',['7scenes']),('eth3d','/tmp/zdrop_eval_20261031',['eth3d']),('scannet50','/tmp/zdrop_scannet_20261031',[])]:
 print('START',name,flush=True)
 with (out/(name+'_launcher.log')).open('w') as f:
  proc=subprocess.run([sys.executable,'-u','scripts/run_eth3d_five.py',*args],cwd=root,stdout=f,stderr=subprocess.STDOUT)
 print('END',name,proc.returncode,flush=True)
 if proc.returncode!=0:
  (out/'queue_failed.json').write_text(json.dumps({'dataset':name,'returncode':proc.returncode}));sys.exit(proc.returncode)
(out/'queue_complete.json').write_text(json.dumps({'terminal':True})+'\n')
