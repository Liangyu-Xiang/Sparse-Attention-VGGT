"""Disjoint state roles and overlapping Key identities; unchanged M5c forward."""
import argparse,json,sys,hashlib
from pathlib import Path
from types import SimpleNamespace
import torch
import torch.nn.functional as F
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from scripts import evaluate_reuse_cosine as evaluator
from scripts.evaluate_attention_first_residual_value import save,write_quality
from scripts.quality_metrics import quality_record

def identities(selected,packed,old_ids,labels,reps):
 g=len(selected);p=len(labels);device=selected.device
 history=torch.zeros((g,p+1),device=device,dtype=torch.bool)
 history.scatter_(1,old_ids.long().masked_fill(old_ids<0,p),old_ids>=0)
 rep_in_history=history[:,reps.long()]
 safe=packed.long().clamp_min(0);valid=packed>=0
 rep_key=safe==reps[labels[safe]]
 hist_key=history.gather(1,safe)&valid
 state=selected.gather(1,labels[safe]);exact_state=state==10;explicit_history=(state>=2)&(state<=9)&~rep_key
 keys=dict(rep_and_history=(valid&rep_key&hist_key).sum(),rep_not_history=(valid&rep_key&~hist_key).sum(),history_not_rep=(valid&~rep_key&hist_key).sum(),neither_rep_nor_history=(valid&~rep_key&~hist_key).sum(),selected_patch_keys=valid.sum(),previous_history_keys=history[:,:p].sum(),retained_previous_history_keys=(valid&hist_key).sum(),exact_and_history=(valid&exact_state&hist_key).sum(),exact_not_history=(valid&exact_state&~hist_key).sum(),explicit_history_and_previous=(valid&explicit_history&hist_key).sum(),exact_rep_and_history=(valid&exact_state&rep_key&hist_key).sum())
 states=dict(rep_only_and_history=((selected==1)&rep_in_history).sum(),rep_only_not_history=((selected==1)&~rep_in_history).sum(),drop=(selected==0).sum(),history_only=((selected>=2)&(selected<=5)).sum(),history_plus_rep=((selected>=6)&(selected<=9)).sum(),exact=(selected==10).sum(),cluster_choices=selected.numel())
 return keys,states,history,rep_in_history

class Observer:
 def __init__(self):self.state=None;self.previous_values=None;self.rep_rows=[];self.window_rows=[];self.packed=None
 def update(self,fine,x,layer,original):
  previous_reps=fine.reps.clone();previous_labels=fine.labels.clone();original(fine,x,layer)
  row=dict(layer=layer,fine_clusters=fine.base_count,patch_tokens=len(x))
  if layer:
   stable=fine.reps==previous_reps
   old=self.previous_values[previous_reps[stable]];new=x[fine.reps[stable]]
   row.update(rep_id_unchanged_fraction=float(stable.float().mean()),membership_unchanged_fraction=float((fine.labels==previous_labels).float().mean()),stable_rep_value_cosine=float(F.cosine_similarity(old,new).mean()) if len(old) else None,
    stable_rep_value_relative_l2=float((new-old).norm()/old.norm().clamp_min(1e-30)) if len(old) else None)
  else:row.update(rep_id_unchanged_fraction=None,membership_unchanged_fraction=None,stable_rep_value_cosine=None,stable_rep_value_relative_l2=None)
  self.previous_values=x.detach().clone();self.rep_rows.append(row)
 def observe(self,errors,selected,hids,old_ids,labels,reps):
  keys,states,history,rep_hist=identities(selected,self.packed,old_ids,labels,reps)
  pi=self.pi;prior=self.prior;valid=hids[:,:,0]>=0;first=hids[:,:,0].long().clamp_min(0)
  ph=prior.gather(1,first);alpha=ph/pi.clamp_min(1e-30)
  gain=errors[:,:,1]-errors[:,:,2]
  better=valid&(gain>1e-6*pi.clamp_min(1e-30))
  counts=dict(history_candidate_clusters=valid.sum(),history_h1_better_than_rep=better.sum(),rep_selected_despite_strictly_better_h1=(better&(selected==1)).sum(),rep_is_history_candidates=rep_hist.sum())
  for threshold in (.5,.75,.9,.95):
   mask=valid&(alpha>=threshold)
   tag=f'nonrep_hist_mass_ge_{threshold}'
   counts[tag]=mask.sum();counts[tag+'_h1_better']=(mask&better).sum();counts[tag+'_rep_only_selected']=(mask&(selected==1)).sum()
  # Include a representative when searching the dominant historical Key.
  rep_mass=prior[:,reps.long()].masked_fill(~rep_hist,-1)
  first_mass=ph.masked_fill(~valid,-1)
  rep_wins=rep_mass>=first_mass;max_mass=torch.maximum(rep_mass,first_mass)
  key=torch.where(rep_wins,reps[None].expand_as(first),first)
  concentration=max_mass/pi.clamp_min(1e-30)
  emitted=torch.zeros_like(history);emitted.scatter_(1,self.packed.long().masked_fill(self.packed<0,len(labels)),self.packed>=0)
  included=emitted.gather(1,key.long())
  for threshold in (.5,.75,.9,.95):
   mask=(max_mass>=0)&(concentration>=threshold)
   tag=f'any_hist_mass_ge_{threshold}'
   counts[tag]=mask.sum();counts[tag+'_is_rep']=(mask&rep_wins).sum();counts[tag+'_key_selected']=(mask&included).sum()
  row={**keys,**states,**counts};row={key:int(value) if not torch.is_tensor(value) else int(value.item()) for key,value in row.items()}
  row.update(layer=self.state.previous_layer+1,groups=len(selected));self.window_rows.append(row)

def main():
 p=argparse.ArgumentParser();p.add_argument('--scene',required=True);p.add_argument('--method',choices=['rep_m5c','rep_m5c_fewer_clusters'],required=True);p.add_argument('--output-dir',type=Path,required=True);p.add_argument('--frames',type=int,default=128);args=p.parse_args()
 import saf3r.patch.reuse_residual_exploration as impl
 import saf3r.patch.reuse_cosine_distortion as cosine
 import saf3r.triton.reuse_compact as compact
 from saf3r.patch.fused_shared_av import FullCoverageValue
 observer=Observer();install=impl.install_reuse_residual_exploration;update=FullCoverageValue.update;loss=cosine.cosine_states;pack=compact.pack;diag=compact.diagnostics
 def installed(*a,**kw):observer.state=install(*a,**kw);return observer.state
 def updated(fine,x,layer):
  if fine is observer.state.fine:return observer.update(fine,x,layer,update)
  return update(fine,x,layer)
 def losses(pi,zvalues,reps,labels,population,hids,allowed,prior,*a,**kw):
  observer.pi=pi;observer.prior=prior;return loss(pi,zvalues,reps,labels,population,hids,allowed,prior,*a,**kw)
 def packed(*a,**kw):
  result=pack(*a,**kw);observer.packed=result[0];return result
 def diagnostics(*a,**kw):
  result=diag(*a,**kw);observer.observe(*a,**kw);return result
 impl.install_reuse_residual_exploration=installed;FullCoverageValue.update=updated;cosine.cosine_states=losses;compact.pack=packed;compact.diagnostics=diagnostics
 a=SimpleNamespace(dataset='7scenes',scene=args.scene,method=args.method,output_dir=args.output_dir,frames=args.frames,warmup=0,repeats=1,capture=False,diagnostic=True,timing_only=False,baseline=None)
 try:
  evaluator.run(a)
  totals=[]
  for layer in range(1,24):
   rows=[r for r in observer.window_rows if r['layer']==layer];assert sum(r['groups'] for r in rows)==observer.state.groups
   totals.append({key:sum(r[key] for r in rows) for key in rows[0] if key!='layer'}|dict(layer=layer))
  assert len(observer.rep_rows)==24
  save(args.output_dir/'key_identity_totals.json',totals);save(args.output_dir/'representative_updates.json',observer.rep_rows)
  save(args.output_dir/'diagnostic_complete.json',dict(complete=True,scene=args.scene,layers=24,identity_layers=23,quality_evaluated=False,seed_layer0='forced all Rep, no prior-layer history'))
  source=Path(__file__);(args.output_dir/source.name).write_bytes(source.read_bytes());save(args.output_dir/'observer_sha256.json',{source.name:hashlib.sha256(source.read_bytes()).hexdigest()})
  write_quality(args.output_dir,quality_record({},'Rep/history identity and update diagnostic only; pose/recon_unposed and paired warmed speed not evaluated.'))
 except BaseException as exc:
  if args.output_dir.exists():save(args.output_dir/'diagnostic_complete.json',dict(complete=False,error=str(exc)))
  raise
if __name__=='__main__':main()
