import os,time,subprocess,sys,json
from pathlib import Path
p=Path('/mnt/rfs/users/xiangliangyu/projects/Sparse-Attention-VGGT/outputs/combined_reuse_20261031');p.mkdir(parents=True,exist_ok=True)
while Path('/proc/1678173').exists():time.sleep(10)
for dataset,root,args in [('eth3d','/tmp/combined_reuse_eval_20261031',['eth3d']),('scannet50','/tmp/combined_scannet50_20261031',[])]:
 print('START',dataset,flush=True)
 with (p/(dataset+'_launcher.log')).open('w') as f:r=subprocess.run([sys.executable,'-u','scripts/run_eth3d_five.py',*args],cwd=root,stdout=f,stderr=subprocess.STDOUT)
 print('END',dataset,r.returncode,flush=True)
(p/'queue_complete.json').write_text(json.dumps({'terminal':True})+'\n')
