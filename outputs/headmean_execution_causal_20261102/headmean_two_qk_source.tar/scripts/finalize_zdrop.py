import json,csv,statistics,sys
from pathlib import Path
sys.path.insert(0,'/tmp/zdrop_eval_20261031')
from scripts.quality_metrics import quality_cells,LABELS
new=Path('/mnt/rfs/users/xiangliangyu/projects/Sparse-Attention-VGGT/outputs/zdrop_shared_rms_20261031');old=new.parent/'combined_reuse_20261031';method='rep_combined_l2_direction_adaptive';keys=['auc03','auc30','acc','comp','cd','f1'];rows=[];audit=[]
for ds,expected in [('7scenes',7),('eth3d',11),('scannet50',50)]:
 summary=json.loads((new/ds/'summary.json').read_text()); scenes=sorted({x['scene'] for x in summary['per_run']});assert len(scenes)==expected
 for scene in scenes:
  for meth in ['dense',method]:
   folder=new/ds/scene/meth; result=folder/'result.json'
   if result.exists():
    d=json.loads(result.read_text());q=d['quality'];(folder/'quality.json').write_text(json.dumps(q,indent=2)+'\n');speed=q.get('speedup_vs_vggt');v=f'{speed:.4f}x' if speed is not None else 'N/A: '+str(q.get('speedup_unavailable'));(folder/'quality.md').write_text('| '+' | '.join(LABELS+('Dense speedup',))+' |\n| '+' | '.join(['---:']*7)+' |\n| '+' | '.join(quality_cells(q)+[v])+' |\n\nCD=(ACC+Comp)/2, unsquared distances.\n')
  a=old/ds/scene/method;b=new/ds/scene/method
  if not (a/'result.json').exists() or not (b/'result.json').exists():audit.append({'dataset':ds,'scene':scene,'error':'missing result'});continue
  ra=json.loads((a/'result.json').read_text());rb=json.loads((b/'result.json').read_text());ia=json.loads((a/'input.json').read_text());ib=json.loads((b/'input.json').read_text());same={k:ia.get(k)==ib.get(k) for k in ('image_paths','frame_indices','shape')};ha=json.loads((a/'source_sha256.json').read_text());hb=json.loads((b/'source_sha256.json').read_text());diff=sorted(k for k in set(ha)|set(hb) if ha.get(k)!=hb.get(k));audit.append({'dataset':ds,'scene':scene,'same_inputs':same,'different_source_files':diff})
  if all(same.values()) and ra['quality']['complete'] and rb['quality']['complete']:
   row={'dataset':ds,'scene':scene}
   for k in keys:
    row['old_'+k]=ra['quality']['values'][k];row['new_'+k]=rb['quality']['values'][k];row['delta_'+k]=row['new_'+k]-row['old_'+k]
   rows.append(row)
(new/'audit.json').write_text(json.dumps(audit,indent=2)+'\n')
if rows:
 with (new/'paired_quality_per_scene.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
for ds,expected in [('7scenes',7),('eth3d',11),('scannet50',50)]:
 z=[x for x in rows if x['dataset']==ds];print(ds,'matched',len(z),'/',expected,flush=True)
 if len(z)==expected:
  for tag in ('old','new'):
   print(tag,{k:round(statistics.mean(x[tag+'_'+k] for x in z)*(100 if k in ('auc03','auc30','f1') else 1),5) for k in keys},flush=True)
print('audit exceptions',[(x['dataset'],x['scene'],x.get('error'),x.get('same_inputs')) for x in audit if x.get('error') or not all(x['same_inputs'].values())],flush=True)
