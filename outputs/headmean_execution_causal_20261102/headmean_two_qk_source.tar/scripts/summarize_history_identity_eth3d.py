import json,statistics,csv
from pathlib import Path
p=Path('/mnt/rfs/users/xiangliangyu/projects/Sparse-Attention-VGGT/outputs/eth3d_history_identity_20261031');scenes=['courtyard','electro','kicker','pipes','relief','delivery_area','facade','office','playground','relief_2','terrains'];methods=['rep_m5c','rep_m5c_fewer_clusters'];rows=[]
for s in scenes:
 for m in methods:
  data=json.loads((p/s/m/'key_identity_totals.json').read_text());assert len(data)==23
  def av(f):return statistics.mean(f(x) for x in data)
  for x in data:
   assert x['retained_previous_history_keys']==x['rep_and_history']+x['exact_and_history']-x['exact_rep_and_history']+x['explicit_history_and_previous'],(s,m,x['layer'])
  den=lambda x:max(x['selected_patch_keys'],1);prev=lambda x:max(x['previous_history_keys'],1);ret=lambda x:max(x['retained_previous_history_keys'],1)
  v={'scene':s,'method':m,'retained_previous_fraction':av(lambda x:x['retained_previous_history_keys']/prev(x)),'current_is_history_fraction':av(lambda x:x['retained_previous_history_keys']/den(x)),'rep_and_history_of_current':av(lambda x:x['rep_and_history']/den(x)),'exact_and_history_of_current':av(lambda x:x['exact_and_history']/den(x)),'explicit_history_of_current':av(lambda x:x['explicit_history_and_previous']/den(x)),'rep_exact_history_of_current':av(lambda x:x['exact_rep_and_history']/den(x)),'retained_as_rep_fraction':av(lambda x:x['rep_and_history']/ret(x)),'retained_as_exact_nonrep_fraction':av(lambda x:(x['exact_and_history']-x['exact_rep_and_history'])/ret(x)),'retained_as_explicit_history_fraction':av(lambda x:x['explicit_history_and_previous']/ret(x)),'selected_rep_is_history_fraction':av(lambda x:x['rep_and_history']/max(x['rep_and_history']+x['rep_not_history'],1)),'selected_exact_is_history_fraction':av(lambda x:x['exact_and_history']/max(x['exact_and_history']+x['exact_not_history'],1))}
  rows.append(v)
macro={m:{k:statistics.mean(x[k] for x in rows if x['method']==m) for k in rows[0] if k not in ('scene','method')} for m in methods}
(p/'summary.json').write_text(json.dumps({'scope':'11 ETH3D scenes, all query groups, layers 1-23, per-layer fractions averaged equally, then equal-scene macro; identity replay, not exact masks of quality run','macro':macro,'per_scene':rows},indent=2)+'\n')
with (p/'per_scene.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
lines=['# ETH3D previous-key identity intersections','', '11 scenes, all query groups, layers 1–23, equal-scene/equal-layer averages. Same method and inputs, separate replay; exact masks of the quality run were not saved. Diagnostic only: all six quality fields N/A, speed N/A (instrumentation, no paired Dense timing). Rep and Exact can overlap; all-key sets exclude special tokens.','', '| Method | Previous keys retained % | Current keys in previous bank % | Current keys: Rep ∩ History % | Current keys: Exact ∩ History % | Current keys: explicit History % | Current keys: Rep ∩ Exact ∩ History % |','|---|---:|---:|---:|---:|---:|---:|']
for m,v in macro.items():lines.append('| '+m+' | '+' | '.join(f'{100*v[k]:.3f}' for k in ('retained_previous_fraction','current_is_history_fraction','rep_and_history_of_current','exact_and_history_of_current','explicit_history_of_current','rep_exact_history_of_current'))+' |')
lines+=['','## Disjoint decomposition of retained historical keys','','Rep has priority in this partition; Exact excludes Rep, explicit History excludes Rep and Exact. Identity intersections checked in every scene and layer.','', '| Method | Rep (includes Rep∩Exact) % | Exact non-Rep % | Explicit History % |','|---|---:|---:|---:|']
for m,v in macro.items():lines.append('| '+m+' | '+' | '.join(f'{100*v[k]:.3f}' for k in ('retained_as_rep_fraction','retained_as_exact_nonrep_fraction','retained_as_explicit_history_fraction'))+' |')
(p/'report.md').write_text('\n'.join(lines)+'\n');print('\n'.join(lines))
