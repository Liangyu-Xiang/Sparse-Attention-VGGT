import sys,json
from pathlib import Path
import torch
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from saf3r.patch.fused_shared_av import FullCoverageValue
from saf3r.patch.value_clustering_gpu import centroid_nearest_gpu
from scripts import evaluate_reuse_cosine
p=Path(sys.argv[1]);p.mkdir(parents=True,exist_ok=True);old=FullCoverageValue.update
rows=[]
def update(self,x,layer):
 old(self,x,layer)
 if layer not in (0,1,5,8,11,17,23):return
 labels=self.labels.clone();reps=self.reps.clone();n=len(x);k=len(reps)
 for metric in ('l2','cosine'):
  z=x.float() if metric=='l2' else torch.nn.functional.normalize(x.float(),dim=-1,eps=1e-12)
  initial=((z-z[reps[labels]])**2).sum(-1).mean(); anchors=reps.clone();states=[]
  # Two feasible restarts: existing representatives and global kmeans++-like fixed random real points.
  for start in ('local','random'):
   generator=torch.Generator(device=x.device).manual_seed(20261030+layer)
   rr=reps.clone() if start=='local' else torch.randperm(n,device=x.device,generator=generator)[:k]
   for it in range(10):
    dist=torch.cdist(z,z[rr]).square();ll=dist.argmin(1);ll[rr]=torch.arange(k,device=x.device)
    rr=centroid_nearest_gpu(z,ll,rr)
   error=((z-z[rr[ll]])**2).sum(-1).mean();states.append((float(error),start))
  result=min(states);rows.append(dict(layer=layer,metric=metric,tokens=n,clusters=k,local_mean_squared=float(initial),global_mean_squared=result[0],global_restart=result[1],improvement_fraction=1-result[0]/max(float(initial),1e-30),reference='two deterministic full-domain real-member medoid Lloyd restarts, 10 iterations; approximate, not global optimum'))
 (p/'global_cluster_comparison.json').write_text(json.dumps(rows,indent=2)+'\n')
FullCoverageValue.update=update
sys.argv=['evaluate_reuse_cosine.py','--method','rep_m5c','--scene','pipes','--frames','2','--output-dir',str(p/'run'),'--warmup','0','--repeats','1','--diagnostic']
import runpy
runpy.run_module('scripts.evaluate_reuse_cosine',run_name='__main__')
