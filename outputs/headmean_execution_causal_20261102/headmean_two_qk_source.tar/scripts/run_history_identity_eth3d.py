import os,subprocess,concurrent.futures,time,json,sys
from pathlib import Path
ROOT=Path('/tmp/eth3d_drop_raw_history_20261031');OUT=Path('/mnt/rfs/users/xiangliangyu/projects/Sparse-Attention-VGGT/outputs/eth3d_history_identity_20261031');OUT.mkdir(parents=True,exist_ok=True)
SCENES=['courtyard','electro','kicker','pipes','relief','delivery_area','facade','office','playground','relief_2','terrains'];METHODS=['rep_m5c','rep_m5c_fewer_clusters']
def apps(uuid):
 r=subprocess.run(['nvidia-smi','--query-compute-apps=gpu_uuid,pid','--format=csv,noheader,nounits'],capture_output=True,text=True,check=True);return {int(t[1]) for l in r.stdout.splitlines() if len(t:=[x.strip() for x in l.split(',')])>=2 and t[0]==uuid}
def work(gpu,scenes):
 uuid=subprocess.check_output(['nvidia-smi','-i',str(gpu),'--query-gpu=uuid','--format=csv,noheader'],text=True).strip();env=dict(os.environ,CUDA_DEVICE_ORDER='PCI_BUS_ID',CUDA_VISIBLE_DEVICES=str(gpu),OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',PYTHONPATH=str(ROOT),LD_LIBRARY_PATH='/mnt/rfs/users/xiangliangyu/conda-envs/vggt-baseline/lib')
 for scene in scenes:
  for method in METHODS:
   while apps(uuid):time.sleep(5)
   folder=OUT/scene/method;folder.parent.mkdir(parents=True,exist_ok=True);cmd=[sys.executable,'-u','scripts/diagnose_m5c_rep_history.py','--scene',scene,'--method',method,'--frames','128','--output-dir',str(folder)]
   with (OUT/f'{scene}_{method}.log').open('w') as f:rc=subprocess.run(cmd,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
   print(scene,method,rc,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
 jobs=[pool.submit(work,i,SCENES[i::8]) for i in range(8)]
 for job in jobs:job.result()
(OUT/'runner_complete.json').write_text(json.dumps({'all_terminal':True})+'\n')
