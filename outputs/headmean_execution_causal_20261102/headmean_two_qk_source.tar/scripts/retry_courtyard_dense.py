import os,subprocess,time,json,sys
from pathlib import Path
ROOT=Path('/tmp/eth3d_drop_cluster_ablation_20261030');folder=Path('/mnt/rfs/users/xiangliangyu/projects/Sparse-Attention-VGGT/outputs/eth3d_drop_cluster_safe_20261030/timing_recheck/courtyard/dense');uuid=subprocess.check_output(['nvidia-smi','-i','0','--query-gpu=uuid','--format=csv,noheader'],text=True).strip()
def apps():
 r=subprocess.run(['nvidia-smi','--query-compute-apps=gpu_uuid,pid','--format=csv,noheader,nounits'],capture_output=True,text=True,check=True);return {int(t[1]) for l in r.stdout.splitlines() if len(t:=[x.strip() for x in l.split(',')])>=2 and t[0]==uuid}
env=dict(os.environ,CUDA_DEVICE_ORDER='PCI_BUS_ID',CUDA_VISIBLE_DEVICES='0',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',PYTHONPATH=str(ROOT),LD_LIBRARY_PATH='/mnt/rfs/users/xiangliangyu/conda-envs/vggt-baseline/lib')
for n in range(3,10):
 while apps():time.sleep(5)
 dest=folder/f'attempt_{n}';cmd=[sys.executable,'-u','scripts/evaluate_reuse_cosine.py','--scene','courtyard','--method','dense','--frames','128','--output-dir',str(dest),'--warmup','1','--repeats','3','--diagnostic'];foreign=set()
 with (folder/f'attempt_{n}.log').open('w') as f:
  child=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
  while child.poll() is None:foreign |= apps()-{child.pid};time.sleep(2)
 meta={'gpu':0,'uuid':uuid,'foreign_pids':sorted(foreign),'returncode':child.returncode,'attempt':n,'poll_seconds':2};dest.mkdir(exist_ok=True,parents=True);(dest/'gpu_monitor.json').write_text(json.dumps(meta,indent=2)+'\n');print(meta,flush=True)
 if not foreign and child.returncode==0:(folder/'selected.json').write_text(json.dumps(meta,indent=2)+'\n');break
