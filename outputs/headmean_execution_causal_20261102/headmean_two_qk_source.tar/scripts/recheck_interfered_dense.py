"""Retest only contaminated Dense timings after ScanNet jobs and audit finish."""
import os,sys,json,time,subprocess,importlib.util
from pathlib import Path
ROOT=Path('/tmp/combined_reuse_eval_20261031');P=Path('/mnt/rfs/users/xiangliangyu/projects/Sparse-Attention-VGGT/outputs/combined_reuse_20261031');sys.path.insert(0,str(ROOT));from scripts.quality_metrics import quality_cells,LABELS
while not (P/'scannet50'/'monitor_audit_complete.json').exists():time.sleep(20)
def apps(uuid):
 r=subprocess.run(['nvidia-smi','--query-compute-apps=gpu_uuid,pid','--format=csv,noheader,nounits'],capture_output=True,text=True,check=True);return {int(t[1]) for l in r.stdout.splitlines() if len(t:=[x.strip() for x in l.split(',')])>=2 and t[0]==uuid}
for dataset,scene,gpu in [('7scenes','chess',0),('eth3d','office',7)]:
 parent=P/dataset/scene;uuid=subprocess.check_output(['nvidia-smi','-i',str(gpu),'--query-gpu=uuid','--format=csv,noheader'],text=True).strip();env=dict(os.environ,CUDA_DEVICE_ORDER='PCI_BUS_ID',CUDA_VISIBLE_DEVICES=str(gpu),OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',PYTHONPATH=str(ROOT),LD_LIBRARY_PATH='/mnt/rfs/users/xiangliangyu/conda-envs/vggt-baseline/lib');clean=None
 for a in range(5):
  while apps(uuid):time.sleep(5)
  dest=P/'clean_dense_recheck'/dataset/scene/f'attempt_{a}';dest.parent.mkdir(parents=True,exist_ok=True);foreign=set();cmd=[sys.executable,'-u','scripts/evaluate_reuse_cosine.py','--dataset',dataset,'--scene',scene,'--method','dense','--frames','128','--output-dir',str(dest),'--warmup','1','--repeats','3','--diagnostic']
  with (dest.parent/f'attempt_{a}.log').open('w') as f:
   proc=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
   while proc.poll() is None:foreign|=apps(uuid)-{proc.pid};time.sleep(2)
  mon={'gpu':gpu,'uuid':uuid,'foreign_pids':sorted(foreign),'returncode':proc.returncode,'poll_seconds':2};dest.mkdir(exist_ok=True,parents=True);(dest/'gpu_monitor.json').write_text(json.dumps(mon,indent=2)+'\n')
  if proc.returncode==0 and not foreign:clean=dest;break
 if clean is None:print(dataset,scene,'no clean timing',flush=True);continue
 new=json.loads((clean/'forward.json').read_text());old=json.loads((parent/'dense'/'result.json').read_text());assert all(new[k]==old[k] for k in ('input','hardware','quality_protocol','source_sha256'));old['original_contaminated_timing']=old['timing'];old['timing']=new['timing'];old['clean_dense_timing_source']=str(clean);old['quality']['speedup_vs_vggt']=1.;old['quality']['speedup_unavailable']=None;(parent/'dense'/'result.json').write_text(json.dumps(old,indent=2)+'\n')
 for method in ['dense','saf3r','rep_m5c','rep_combined_l2_direction_adaptive']:
  f=parent/method/'result.json';r=json.loads(f.read_text());q=r['quality'];q['speedup_vs_vggt']=new['timing']['median_seconds']/r['timing']['median_seconds'];q['speedup_unavailable']=None;r['paired_clean_dense_timing_source']=str(clean);f.write_text(json.dumps(r,indent=2)+'\n');(f.parent/'quality.json').write_text(json.dumps(q,indent=2)+'\n');(f.parent/'quality.md').write_text('| '+' | '.join(LABELS+('Dense speedup',))+' |\n| '+' | '.join(['---:']*7)+' |\n| '+' | '.join(quality_cells(q)+[f"{q['speedup_vs_vggt']:.4f}x"])+' |\n\nCD=(ACC+Comp)/2, unsquared.\n')
 sys.argv=['runner',dataset];spec=importlib.util.spec_from_file_location('rerun_'+dataset,ROOT/'scripts/run_eth3d_five.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
 with mod.lock:mod.report()
 print('clean timing repaired',dataset,scene,flush=True)
(P/'clean_dense_recheck_complete.json').write_text(json.dumps({'terminal':True})+'\n')
