import os,sys,json,time,subprocess,statistics,threading
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
ROOT=Path('/tmp/zdrop_eval_20261031'); DATASET=sys.argv[1]; OUT=Path('/mnt/rfs/users/xiangliangyu/projects/Sparse-Attention-VGGT/outputs/zdrop_shared_rms_20261031')/DATASET
SCENES=(['courtyard','electro','kicker','pipes','relief','delivery_area','facade','office','playground','relief_2','terrains'] if DATASET=='eth3d' else ['chess','fire','heads','office','pumpkin','redkitchen','stairs'])
METHODS=['dense','rep_combined_l2_direction_adaptive']; KEYS=['auc03','auc30','acc','comp','cd','f1']; lock=threading.Lock()
def read(p):
 try:return json.loads(p.read_text())
 except (FileNotFoundError,ValueError):return None
def report():
 rows=[];complete={}; lines=['# '+DATASET+' adaptive L2 and shared-RMS vector-sum Drop evaluation','', 'DA3-Bench, uniformly sample up to 128 images; pose and recon_unposed. AUC/F1 percent, unsquared distances in metres; CD=(ACC+Comp)/2. See per-run protocol for threshold and voxel. SAF3R lazy first-correspondence Top-4 with ETH3D profile, not DINO paper Top-K.','', '| Scene | Method | Frames | AUC@3 % | AUC@30 % | ACC m | Comp m | CD m | F1 % | Warm median s | Peak GiB | Dense speedup |','|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
 for scene in SCENES:
  for method in METHODS:
   d=OUT/scene/method;r=read(d/'result.json');q=r['quality'] if r else read(d/'quality.json');status=read(d/'status.json') or {}; reason=status.get('error',status.get('stage','not started'))
   if r and q['complete']:complete[scene,method]=r
   vals=['N/A']*6;perf=['N/A']*3;frames='N/A'
   if q:
    vals=['N/A' if q['values'][k] is None else f"{q['values'][k]*(100 if k in ('auc03','auc30','f1') else 1):.4f}" for k in KEYS]
   if r:
    frames=str(r['frames']);perf=[f"{r['timing']['median_seconds']:.3f}",f"{statistics.median(z['peak_allocated_gib'] for z in r['timing']['samples']):.3f}",'N/A' if q.get('speedup_vs_vggt') is None else f"{q['speedup_vs_vggt']:.3f}x"]
   if not r:lines.append(f'<!-- {scene} {method}: {reason} -->')
   lines.append('| '+' | '.join([scene,method,frames]+vals+perf)+' |');rows.append({'scene':scene,'method':method,'status':status,'quality':q})
 macro={}
 for method in METHODS:
  rr=[complete.get((s,method)) for s in SCENES]
  if all(rr):
   macro[method]={k:statistics.mean(r['quality']['values'][k] for r in rr) for k in KEYS};macro[method]['mean_scene_median_seconds']=statistics.mean(r['timing']['median_seconds'] for r in rr);macro[method]['mean_scene_peak_gib']=statistics.mean(statistics.median(t['peak_allocated_gib'] for t in r['timing']['samples']) for r in rr)
 lines+=['','## Equal-scene macro (all scenes required)','', '| Method | Scenes | AUC@3 % | AUC@30 % | ACC m | Comp m | CD m | F1 % | Median mean s | Peak GiB | Dense speedup |','|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
 for m in METHODS:
  count=sum((s,m) in complete for s in SCENES);v=macro.get(m);vals=['N/A']*6;perf=['N/A']*3
  if v:
   vals=[f"{v[k]*(100 if k in ('auc03','auc30','f1') else 1):.4f}" for k in KEYS];speed=macro['dense']['mean_scene_median_seconds']/v['mean_scene_median_seconds'] if 'dense' in macro and all(complete[s,m]['quality'].get('speedup_vs_vggt') is not None for s in SCENES) else None;v['speedup']=speed;perf=[f"{v['mean_scene_median_seconds']:.3f}",f"{v['mean_scene_peak_gib']:.3f}",'N/A (GPU overlap)' if speed is None else f'{speed:.3f}x']
  lines.append('| '+' | '.join([m,f'{count}/{len(SCENES)}']+vals+perf)+' |')
 lines+=['','One warmup, three measured complete model forwards; per-scene paired Dense and same physical GPU. Frame counts can be below 128. GPU processes sampled every 2 seconds; overlapping paired timing is N/A, brief overlap between polls may be missed.','']
 (OUT/'report.md').write_text('\n'.join(lines));(OUT/'summary.json').write_text(json.dumps({'macro':macro,'completed':len(complete),'required':len(SCENES)*len(METHODS),'per_run':rows},indent=2)+'\n')
def gpu_apps(uuid):
 r=subprocess.run(['nvidia-smi','--query-compute-apps=gpu_uuid,pid','--format=csv,noheader,nounits'],capture_output=True,text=True,check=True)
 return {int(t[1]) for line in r.stdout.splitlines() if len(t:=[x.strip() for x in line.split(',')])>=2 and t[0]==uuid}
def worker(gpu,scenes):
 uuid=subprocess.check_output(['nvidia-smi','-i',str(gpu),'--query-gpu=uuid','--format=csv,noheader'],text=True).strip()
 for scene in scenes:
  for method in METHODS:
   dest=OUT/scene/method; baseline=OUT/scene/'dense'/'forward.json'
   if method!='dense' and not baseline.exists():
    dest.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(ROOT));from scripts.quality_metrics import quality_record,quality_markdown
    q=quality_record({},'Paired Dense forward unavailable');(dest/'quality.json').write_text(json.dumps(q,indent=2)+'\n');(dest/'quality.md').write_text(quality_markdown(q));(dest/'status.json').write_text(json.dumps({'stage':'failed','error':'Paired Dense forward unavailable'})+'\n');continue
   cmd=[sys.executable,'-u','scripts/evaluate_reuse_cosine.py','--dataset',DATASET,'--scene',scene,'--method',method,'--frames','128','--output-dir',str(dest)]
   if method!='dense':cmd+=['--baseline',str(baseline)]
   env=dict(os.environ,CUDA_DEVICE_ORDER='PCI_BUS_ID',CUDA_VISIBLE_DEVICES=str(gpu),OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',PYTHONUNBUFFERED='1',PYTHONPATH=str(ROOT),LD_LIBRARY_PATH='/mnt/rfs/users/xiangliangyu/conda-envs/vggt-baseline/lib')
   while gpu_apps(uuid):time.sleep(5)
   foreign=set()
   with (OUT/f'{scene}_{method}.log').open('w') as f:
    child=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
    while child.poll() is None:
     foreign |= gpu_apps(uuid)-{child.pid}
     time.sleep(2)
    rc=child.returncode
   monitor={'gpu':gpu,'uuid':uuid,'child_pid':child.pid,'foreign_pids':sorted(foreign),'poll_seconds':2,'returncode':rc}
   dest.mkdir(parents=True,exist_ok=True);(dest/'gpu_monitor.json').write_text(json.dumps(monitor,indent=2)+'\n')
   bp=OUT/scene/'dense'/'gpu_monitor.json';baseline_foreign=bool(json.loads(bp.read_text()).get('foreign_pids')) if bp.exists() else False
   if (foreign or baseline_foreign) and (dest/'result.json').exists():
    result=json.loads((dest/'result.json').read_text());result['quality']['speedup_vs_vggt']=None;result['quality']['speedup_unavailable']='Concurrent GPU process detected in method or paired Dense';(dest/'result.json').write_text(json.dumps(result,indent=2)+'\n')
   if not (dest/'status.json').exists():
    dest.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(ROOT));from scripts.quality_metrics import quality_record,quality_markdown
    reason=f'process exited {rc} before status initialization';q=quality_record({},reason);(dest/'quality.json').write_text(json.dumps(q,indent=2)+'\n');(dest/'quality.md').write_text(quality_markdown(q));(dest/'status.json').write_text(json.dumps({'stage':'failed','error':reason})+'\n')
   with lock:report()
if __name__=='__main__':
 OUT.mkdir(parents=True,exist_ok=True);report();groups=[SCENES[i::8] for i in range(8)]
 with ThreadPoolExecutor(max_workers=8) as pool:
  jobs=[pool.submit(worker,i,group) for i,group in enumerate(groups)]
  for j in jobs:j.result()
 with lock:report()
 (OUT/'completed.json').write_text(json.dumps({'all_terminal':True})+'\n')
