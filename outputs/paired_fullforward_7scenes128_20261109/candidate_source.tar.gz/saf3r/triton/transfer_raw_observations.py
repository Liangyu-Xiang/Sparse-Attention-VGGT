"""Export4/8/16 previous-support Query observations from existing formal AV QK.

No second selected QK. Additional probes reuse already computed Query rows.
Only raw logits/encoding centers are exported; no unused raw denominator.
"""
import torch,triton
import triton.language as tl

@triton.jit
def _bias(W,LOG,N:tl.constexpr,B:tl.constexpr):
 j=tl.program_id(0)*B+tl.arange(0,B);w=tl.load(W+j,j<N,1.)
 tl.store(LOG+j,tl.where(w>0,tl.log(w),-float('inf')),j<N)

@triton.jit
def _attention(Q,K,V,IDS,SPECIAL,BIAS,OUT,RAW,SHIFT,
 H:tl.constexpr,R:tl.constexpr,N:tl.constexpr,A:tl.constexpr,S:tl.constexpr,D:tl.constexpr,
 QH:tl.constexpr,KH:tl.constexpr,VH:tl.constexpr,OH:tl.constexpr,
 SCALE:tl.constexpr,PROBES:tl.constexpr,CAPTURE:tl.constexpr,FULL:tl.constexpr,
 BD:tl.constexpr,BM:tl.constexpr,BK:tl.constexpr,GS:tl.constexpr):
 t=tl.program_id(0);h=tl.program_id(1);g=t//(GS//BM);row=tl.arange(0,BM);rr=t*BM+row;dd=tl.arange(0,BD);kk=tl.arange(0,BK)
 q=tl.load(Q+h*QH+rr[:,None]*D+dd[None,:],(rr[:,None]<R)&(dd[None,:]<D),0.)
 maximum=tl.full((BM,),-float('inf'),tl.float32);den=tl.zeros((BM,),tl.float32);acc=tl.zeros((BM,BD),tl.float32)
 if CAPTURE:
  if FULL:
   lp=tl.arange(0,PROBES//(GS//BM));local=lp*(GS//PROBES)+GS//(2*PROBES)
   slot=(t%(GS//BM))*(PROBES//(GS//BM))+lp
  else:
   slot=tl.arange(0,PROBES);positions=tl.minimum(slot*(GS//PROBES)+GS//(2*PROBES),R-1);active=positions//BM==t;local=tl.minimum(tl.maximum(positions-t*BM,0),BM-1)
 for tile in range(tl.cdiv(S+A,BK)):
  at=tile*BK+kk;key=tl.load(IDS+g*A+at-S,(at>=S)&(at<S+A),-1);special=tl.load(SPECIAL+at,at<S,0);key=tl.where(at<S,special,key);valid=(at<S+A)&(key>=0)
  bias=tl.load(BIAS+g*A+at-S,(at>=S)&valid,0.)
  k=tl.load(K+h*KH+tl.maximum(key,0)[None,:]*D+dd[:,None],valid[None,:]&(dd[:,None]<D),0.)
  v=tl.load(V+h*VH+tl.maximum(key,0)[:,None]*D+dd[None,:],valid[:,None]&(dd[None,:]<D),0.)
  raw=tl.dot(q,k,allow_tf32=False)*SCALE;z=tl.where(valid[None,:],raw+bias[None,:],-float('inf'))
  mx=tl.maximum(maximum,tl.max(z,1));safe=tl.where(mx==-float('inf'),0.,mx);alpha=tl.exp(maximum-safe);p=tl.exp(z-safe[:,None])
  if CAPTURE:
   probe=tl.gather(raw,tl.broadcast_to(local[:,None],(PROBES//(GS//BM) if FULL else PROBES,BK)),0)
   raw_valid=tl.where(valid[None,:],probe,-float('inf'));center=tl.max(raw_valid,1);center=tl.where(center==-float('inf'),0.,center);encoded=raw_valid-center[:,None]
   if FULL:
    tl.store(RAW+((g*H+h)*PROBES+slot[:,None])*(S+A)+at[None,:],encoded,at[None,:]<S+A)
    tl.store(SHIFT+((g*H+h)*PROBES+slot)*tl.cdiv(S+A,BK)+tile,center)
   else:
    tl.store(RAW+((g*H+h)*PROBES+slot[:,None])*(S+A)+at[None,:],encoded,active[:,None]&(at[None,:]<S+A))
    tl.store(SHIFT+((g*H+h)*PROBES+slot)*tl.cdiv(S+A,BK)+tile,center,active)
  acc=acc*alpha[:,None]+tl.dot(p.to(v.dtype),v,allow_tf32=False);den=den*alpha+tl.sum(p,1);maximum=mx
 out=acc/den[:,None];tl.store(OUT+h*OH+rr[:,None]*D+dd[None,:],out,(rr[:,None]<R)&(dd[None,:]<D))


def attention(q,k,v,ids,specials,weights,scale,probes=8,capture=True,warps=4,stages=1):
 h,r,d=q.shape;g,a=ids.shape;s=len(specials);assert g==triton.cdiv(r,256) and probes in (4,8,16)
 bias=torch.empty_like(weights);_bias[(triton.cdiv(weights.numel(),256),)](weights,bias,weights.numel(),256,num_warps=4)
 out=torch.empty_like(q);raw=torch.empty(g,h,probes,s+a,device=q.device,dtype=torch.float16) if capture else out
 shifts=torch.empty(g,h,probes,triton.cdiv(s+a,128),device=q.device) if capture else out
 full_rows=r//256*256;segments=[]
 if full_rows:segments.append((0,full_rows,0,full_rows//256,True))
 if full_rows<r:segments.append((full_rows,r,full_rows//256,g,False))
 for first,end,beg,eg,full in segments:
  qq=q[:,first:end];oo=out[:,first:end]
  _attention[(triton.cdiv(end-first,64),h)](qq,k,v,ids[beg:eg],specials,bias[beg:eg],oo,raw[beg:eg] if capture else raw,shifts[beg:eg] if capture else shifts,h,end-first,k.shape[1],a,s,d,qq.stride(0),k.stride(0),v.stride(0),oo.stride(0),scale,probes,capture,full,triton.next_power_of_2(d),64,128,256,num_warps=warps,num_stages=stages)
 return out,dict(encoded=raw,shifts=shifts,block_keys=128,probes=probes)
