"""Fused implementation of the frozen moment-corrected fresh-history formula.

Reads inline encoded selected logits directly. Never materializes H*G*P*A
FP32 decoded arrays. Sorted unique packed Patch IDs are required.
"""
import torch,triton
import triton.language as tl

@triton.jit
def _seg(ra,sa,qa,ca,rb,sb,qb,cb):
 same=ra==rb
 return rb,tl.where(same,sa+sb,sb),tl.where(same,qa+qb,qb),tl.where(same,ca+cb,cb)

@triton.jit
def _stats(ENC,SHIFT,IDS,GRID,SUM,SQ,COUNT,TILE,
 H:tl.constexpr,G:tl.constexpr,P:tl.constexpr,A:tl.constexpr,S:tl.constexpr,R:tl.constexpr,TS:tl.constexpr,TA:tl.constexpr,B:tl.constexpr):
 t=tl.program_id(0);g=tl.program_id(1);hp=tl.program_id(2);h=hp//P;p=hp%P;j=t*B+tl.arange(0,B)
 key=tl.load(IDS+g*A+j,j<A,-1);valid=(j<A)&(key>=0);region=tl.load(GRID+tl.maximum(key,0),valid,0)
 z=tl.load(ENC+((g*H+h)*P+p)*(S+A)+S+j,j<A,0.).to(tl.float32)
 shift=tl.load(SHIFT+((g*H+h)*P+p)*TS+(S+j)//128,j<A,0.)
 z=tl.where(valid,z+shift,0.);r=tl.where(valid,region,-1)
 _,ss,qq,cc=tl.associative_scan((r,z,z*z,valid.to(tl.int32)),0,_seg)
 i=tl.arange(0,B);rn=tl.gather(r,tl.minimum(i+1,B-1),0);last=valid&((i==B-1)|(rn!=r))
 offset=((h*G+g)*P+p)*R+region
 tl.atomic_add(SUM+offset,ss,last,sem='relaxed');tl.atomic_add(SQ+offset,qq,last,sem='relaxed')
 if h==0 and p==0:tl.atomic_add(COUNT+g*R+region,cc,last,sem='relaxed')
 maximum=tl.max(tl.where(valid,z,-float('inf')),0);safe=tl.where(maximum==-float('inf'),0.,maximum)
 total=tl.sum(tl.exp(tl.where(valid,z-safe,-float('inf'))),0)
 value=maximum+tl.log(tl.maximum(total,1.e-30))
 tl.store(TILE+((h*G+g)*P+p)*TA+t,value)

@triton.jit
def _partition(MEAN,VAR,SIZE,SUM,SQ,COUNT,TILE,LZ,UP,BAD,
 H:tl.constexpr,G:tl.constexpr,P:tl.constexpr,R:tl.constexpr,TA:tl.constexpr,BR:tl.constexpr,BT:tl.constexpr):
 gp=tl.program_id(0);g=(gp//P)%G;r=tl.arange(0,BR);at=tl.arange(0,BT)
 n=tl.load(SIZE+r,r<R,0.);count=tl.load(COUNT+g*R+r,r<R,0);remaining=n-count
 mu=tl.load(MEAN+gp*R+r,r<R,0.);var=tl.load(VAR+gp*R+r,r<R,0.);summed=tl.load(SUM+gp*R+r,r<R,0.);sq=tl.load(SQ+gp*R+r,r<R,0.)
 denom=tl.maximum(remaining,1.);um=(n*mu-summed)/denom
 uv=tl.maximum((n*(mu*mu+var)-sq)/denom-um*um,0.)
 logu=tl.where((r<R)&(remaining>0),um+.5*uv+tl.log(denom),-float('inf'))
 known=tl.load(TILE+gp*TA+at,at<TA,-float('inf'))
 maximum=tl.maximum(tl.max(logu,0),tl.max(known,0));logz=maximum+tl.log(tl.sum(tl.exp(logu-maximum),0)+tl.sum(tl.exp(known-maximum),0))
 tl.store(LZ+gp,logz);tl.store(UP+gp*R+r,tl.exp(logu-logz)/denom,r<R)
 tl.store(BAD+gp,tl.sum(((remaining<0)&(r<R)).to(tl.int32),0)>0)

@triton.jit
def _base(UP,VALID,BASE,H:tl.constexpr,G:tl.constexpr,P:tl.constexpr,R:tl.constexpr,HP:tl.constexpr,BR:tl.constexpr):
 g=tl.program_id(0);r=tl.program_id(1)*BR+tl.arange(0,BR);hp=tl.arange(0,HP);h=hp//P;p=hp%P
 valid=(hp<H*P)&tl.load(VALID+g*P+p,hp<H*P,False)
 value=tl.load(UP+((h[:,None]*G+g)*P+p[:,None])*R+r[None,:],(hp[:,None]<H*P)&(r[None,:]<R),0.)
 result=tl.sum(tl.where(valid[:,None],value,0.),0)/tl.maximum(tl.sum(valid.to(tl.float32),0),1.)
 tl.store(BASE+g*R+r,result,r<R)

@triton.jit
def _fill(BASE,GRID,POST,N:tl.constexpr,R:tl.constexpr,B:tl.constexpr):
 g=tl.program_id(0);j=tl.program_id(1)*B+tl.arange(0,B);r=tl.load(GRID+j,j<N,0);x=tl.load(BASE+g*R+r,j<N,0.);tl.store(POST+g*N+j,x,j<N)

@triton.jit
def _observed(ENC,SHIFT,LZ,VALID,IDS,POST,H:tl.constexpr,G:tl.constexpr,P:tl.constexpr,N:tl.constexpr,A:tl.constexpr,S:tl.constexpr,TS:tl.constexpr,HP:tl.constexpr,B:tl.constexpr):
 g=tl.program_id(0);j=tl.program_id(1)*B+tl.arange(0,B);hp=tl.arange(0,HP);h=hp//P;p=hp%P
 key=tl.load(IDS+g*A+j,j<A,-1);valid=(j<A)&(key>=0)
 z=tl.load(ENC+((g*H+h[:,None])*P+p[:,None])*(S+A)+S+j[None,:],(hp[:,None]<H*P)&(j[None,:]<A),0.).to(tl.float32)
 shift=tl.load(SHIFT+((g*H+h[:,None])*P+p[:,None])*TS+(S+j[None,:])//128,(hp[:,None]<H*P)&(j[None,:]<A),0.)
 logz=tl.load(LZ+(h*G+g)*P+p,hp<H*P,0.)
 ok=(hp<H*P)&tl.load(VALID+g*P+p,hp<H*P,False)
 response=tl.exp(z+shift-logz[:,None]);out=tl.sum(tl.where(ok[:,None],response,0.),0)/tl.maximum(tl.sum(ok.to(tl.float32),0),1.)
 tl.store(POST+g*N+key,out,valid)

@triton.jit
def _normalize(POST,OUT,N:tl.constexpr,R:tl.constexpr,SIZE:tl.constexpr,B:tl.constexpr):
 g=tl.program_id(0);r=tl.program_id(1);j=r*SIZE+tl.arange(0,B);valid=tl.arange(0,B)<SIZE
 value=tl.load(POST+g*N+j,valid,0.);total=tl.sum(value,0)
 phi=tl.where(total>0,value/tl.maximum(total,1.e-30),1./SIZE);phi=tl.where(valid,phi,0.)
 correction=tl.sum(phi,0);tl.store(OUT+g*N+j,phi/tl.maximum(correction,1.e-30),valid)


def update(mean,variance,grid,sizes,ids,evidence,eligible,specials,block_size):
 h,g,p,r=mean.shape;n=len(grid);a=ids.shape[1];assert n==r*block_size
 enc=evidence['encoded'];shift=evidence['shifts'];assert enc.shape==(g,h,p,specials+a) and evidence['block_keys']==128
 ta=triton.cdiv(a,256);ts=shift.shape[-1]
 sums=torch.zeros_like(mean);sq=torch.zeros_like(mean);count=torch.zeros(g,r,device=mean.device,dtype=torch.int32)
 tiles=torch.empty(h*g*p,ta,device=mean.device);logz=torch.empty(h*g*p,device=mean.device);up=torch.empty_like(mean);bad=torch.empty(h*g*p,device=mean.device,dtype=torch.bool)
 _stats[(ta,g,h*p)](enc,shift,ids,grid,sums,sq,count,tiles,h,g,p,a,specials,r,ts,ta,256,num_warps=4,enable_fp_fusion=False)
 _partition[(h*g*p,)](mean,variance,sizes,sums,sq,count,tiles,logz,up,bad,h,g,p,r,ta,triton.next_power_of_2(r),triton.next_power_of_2(ta),num_warps=4,enable_fp_fusion=False)
 base=torch.empty(g,r,device=mean.device)
 _base[(g,triton.cdiv(r,16))](up,eligible,base,h,g,p,r,triton.next_power_of_2(h*p),16,num_warps=4)
 posterior=torch.empty(g,n,device=mean.device);out=torch.empty_like(posterior)
 _fill[(g,triton.cdiv(n,256))](base,grid,posterior,n,r,256,num_warps=4)
 _observed[(g,triton.cdiv(a,32))](enc,shift,logz,eligible,ids,posterior,h,g,p,n,a,specials,ts,triton.next_power_of_2(h*p),32,num_warps=4,enable_fp_fusion=False)
 _normalize[(g,r)](posterior,out,n,r,block_size,triton.next_power_of_2(block_size),num_warps=4,enable_fp_fusion=False)
 return out,~bad.any()
