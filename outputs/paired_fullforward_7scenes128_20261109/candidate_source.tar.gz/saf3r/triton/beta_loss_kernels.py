"""Same A distortion/support/budget with a fully observed current per-key prior."""
import torch,triton
import triton.language as tl

@triton.jit
def _base(P,MEM,NORM,DR,POP,PI,E,COST,OBJ,N:tl.constexpr,F:tl.constexpr,W:tl.constexpr,C:tl.constexpr,POWER:tl.constexpr):
 g=tl.program_id(0);c=tl.program_id(1)*C+tl.arange(0,C);m=tl.arange(0,W)
 member=tl.load(MEM+c[:,None]*W+m[None,:],c[:,None]<F,-1);valid=(c[:,None]<F)&(member>=0);safe=tl.maximum(member,0)
 p=tl.load(P+g*N+safe,valid,0.);norm=tl.load(NORM+safe,valid,0.);dist=tl.load(DR+safe,valid,0.)
 loss=p*p*N if POWER==2. else tl.sqrt(p/N) if POWER==.5 else p
 mass=tl.sum(p,1);drop=tl.sum(loss*norm,1);rep=tl.sum(loss*dist,1);pop=tl.load(POP+c,c<F,0.);off=(g*F+c)*4
 tl.store(PI+g*F+c,mass,c<F)
 for s in tl.static_range(4):
  error=drop if s==0 else rep if s==1 else float('inf') if s==2 else 0.
  cost=0. if s==0 or s==2 else 1. if s==1 else pop
  tl.store(E+off+s,error,c<F);tl.store(COST+off+s,cost,c<F);tl.store(OBJ+off+s,error-rep,c<F)

@triton.jit
def _historical(IDS,P,LABEL,DR,QUAL,KR,HM,N:tl.constexpr,F:tl.constexpr,A:tl.constexpr,B:tl.constexpr,POWER:tl.constexpr):
 g=tl.program_id(0);i=tl.program_id(1)*B+tl.arange(0,B);key=tl.load(IDS+g*A+i,i<A,-1);valid=(i<A)&(key>=0);safe=tl.maximum(key,0)
 valid=valid&tl.load(QUAL+g*N+safe,valid,False);c=tl.load(LABEL+safe,valid,0);p=tl.load(P+g*N+safe,valid,0.);d=tl.load(DR+safe,valid,0.)
 loss=p*p*N if POWER==2. else tl.sqrt(p/N) if POWER==.5 else p
 tl.atomic_add(KR+g*F+c,loss*d,valid,sem='relaxed');tl.atomic_add(HM+g*F+c,p,valid,sem='relaxed')
