"""Current QK for previous actual sparse ids and sampled queries only."""
import torch,triton
import triton.language as tl

@triton.jit
def _raw(Q,K,IDS,OUT,G:tl.constexpr,P:tl.constexpr,A:tl.constexpr,D:tl.constexpr,QH:tl.constexpr,KH:tl.constexpr,SCALE:tl.constexpr,BD:tl.constexpr,BK:tl.constexpr):
 g=tl.program_id(0);h=tl.program_id(1);j=tl.program_id(2)*BK+tl.arange(0,BK);p=tl.arange(0,16);d=tl.arange(0,BD)
 ids=tl.load(IDS+g*A+j,j<A,-1);valid=(j<A)&(ids>=0)
 q=tl.load(Q+h*QH+(g*P+p[:,None])*D+d[None,:],(p[:,None]<P)&(d[None,:]<D),0.)
 k=tl.load(K+h*KH+tl.maximum(ids,0)[None,:]*D+d[:,None],valid[None,:]&(d[:,None]<D),0.)
 value=tl.dot(q,k,allow_tf32=False)*SCALE
 tl.store(OUT+((h*G+g)*P+p[:,None])*A+j[None,:],tl.where(valid[None,:],value,-float('inf')),(p[:,None]<P)&(j[None,:]<A))

def logits(q,k,ids,scale):
 h,g,p,d=q.shape;assert p<=16 and q.is_contiguous() and ids.is_contiguous()
 a=ids.shape[1];out=torch.empty((h,g,p,a),device=q.device,dtype=torch.float32)
 _raw[(g,h,triton.cdiv(a,128))](q,k,ids,out,g,p,a,d,q.stride(0),k.stride(0),scale,triton.next_power_of_2(d),128,num_warps=4)
 return out
