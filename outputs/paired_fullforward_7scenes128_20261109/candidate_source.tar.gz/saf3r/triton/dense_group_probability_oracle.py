"""Diagnostic exact current-QKV dense probability, averaged over ordinary Q/head.

Two full QK passes: online row LSE, then probabilities reduced into group rows.
No HxQxK probability bank is materialized. This is not a sparse estimator.
"""
import torch,triton
import triton.language as tl
from .current_probe_probability import _lse

@triton.jit
def _reduce(Q,K,Z,MASK,COUNTS,OUT,M:tl.constexpr,N:tl.constexpr,H:tl.constexpr,D:tl.constexpr,
            QH:tl.constexpr,KH:tl.constexpr,SCALE:tl.constexpr,BM:tl.constexpr,BK:tl.constexpr,BD:tl.constexpr):
    tile=tl.program_id(0);kt=tl.program_id(1);head=tl.program_id(2)
    row=tile*BM+tl.arange(0,BM);col=kt*BK+tl.arange(0,BK);dd=tl.arange(0,BD)
    q=tl.load(Q+head*QH+row[:,None]*D+dd[None,:],(row[:,None]<M)&(dd[None,:]<D),0.)
    k=tl.load(K+head*KH+col[None,:]*D+dd[:,None],(col[None,:]<N)&(dd[:,None]<D),0.)
    z=tl.load(Z+head*M+row,row<M,0.)
    ordinary=tl.load(MASK+row,row<M,False)
    raw=tl.dot(q,k,allow_tf32=False)*SCALE
    prob=tl.where(ordinary[:,None]&(col[None,:]<N),tl.exp(raw-z[:,None]),0.)
    group=tile//(256//BM);count=tl.load(COUNTS+group)
    result=tl.sum(prob,0)/(count*H)
    tl.atomic_add(OUT+group*N+col,result,col<N,sem='relaxed')

def probability(q,ordinary_k,query_mask,query_counts,scale):
    h,m,d=q.shape;n=ordinary_k.shape[1];g=len(query_counts)
    assert triton.cdiv(m,256)==g and q.dtype==ordinary_k.dtype
    z=torch.empty(h,m,device=q.device,dtype=torch.float32)
    out=torch.zeros(g,n,device=q.device,dtype=torch.float32)
    _lse[(triton.cdiv(m,64),h)](q,ordinary_k,z,m,n,d,q.stride(0),ordinary_k.stride(0),scale,64,128,triton.next_power_of_2(d),num_warps=4,num_stages=2)
    _reduce[(triton.cdiv(m,64),triton.cdiv(n,128),h)](q,ordinary_k,z,query_mask,query_counts,out,m,n,h,d,q.stride(0),ordinary_k.stride(0),scale,64,128,triton.next_power_of_2(d),num_warps=4,num_stages=2)
    return out
