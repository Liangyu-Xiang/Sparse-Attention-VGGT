"""Arithmetic mean of executed exp(QK), before per-head normalization/mean.

The per-head coarse partition fixes an exponential gauge only. Unknown keys
are approximated by the coarse observation; never inserted in the cache.
"""
import torch
from .beta_unified_importance import estimate

def observe(mean,grid,sizes,ids,raw):
    mean=mean[:,:,0];raw=raw[:,:,0]
    valid=ids>=0;safe=ids.clamp_min(0).long();block=grid[safe];g=len(ids)
    count=mean.new_zeros(g,len(sizes)).scatter_add_(1,block,valid.float());missing=(sizes[None]-count).clamp_min(0)
    shift=(mean+sizes.log()[None,None]).logsumexp(-1)
    unknown=((mean-shift[...,None]).exp()*missing[None]).sum(-1)
    observed=raw.masked_fill(~valid[None],0.)
    return (observed/(observed.sum(-1)+unknown).clamp_min(1e-30)[...,None]).mean(0).masked_fill(~valid,0.).contiguous()
