"""Offline-only previous-layer full Dense conditional; never a deployable cache."""
import torch


def within_block(probability, grid, sizes):
    """Normalize head/probe-averaged patch probability within each fixed block."""
    groups, n = probability.shape
    regions = len(sizes)
    if n % regions or not torch.all(sizes == n // regions):
        raise ValueError('This diagnostic requires balanced equal contiguous blocks')
    mass = probability.double().reshape(groups, regions, -1).sum(-1).to(probability.dtype)
    conditional = probability / mass[:, grid].clamp_min(1e-30)
    return torch.where((mass == 0)[:, grid], 1 / sizes[grid][None], conditional)
