"""Finite history transfer/correction models; no new fine current ordinary QK."""
import torch
from .one_layer_edge_history import mean_valid

MODELS={
 'phase1':dict(response='gauss',cov=False,mass=False,transport=False,power=1.,risk=.5),
 'rep_shape':dict(response='rep',cov=False,mass=False,transport=False,power=1.,risk=.5),
 'rep_shape_cov':dict(response='rep',cov=True,mass=True,transport=False,power=1.,risk=.5),
 'rep_global':dict(response='rep',cov=False,mass=False,transport=True,power=1.,risk=.5),
 'rep_global_cov':dict(response='rep',cov=True,mass=True,transport=True,power=1.,risk=.5),
 'rep_global_cov_sqrt':dict(response='rep',cov=True,mass=True,transport=True,power=.5,risk=.5),
 'rep_global_cov_gain1':dict(response='rep',cov=True,mass=True,transport=True,power=1.,risk=1.),
 'gauss_shape_cov':dict(response='gauss',cov=True,mass=True,transport=False,power=1.,risk=.5),
 'gauss_global_cov':dict(response='gauss',cov=True,mass=True,transport=True,power=1.,risk=.5),
}


def predict(current,previous,posterior,grid,sizes,transport=False,power=1.):
 if previous is None:
  return current[:,grid]/sizes[grid][None],torch.zeros_like(current)
 beta=(2*current.sqrt()*previous.sqrt()/(current+previous).clamp_min(1e-30)).clamp(0,1)
 if transport:
  # Global normalization only: retain independently estimated historical block mass.
  log_transfer=posterior.clamp_min(1e-30).log()+power*(current.clamp_min(1e-30).log()-previous.clamp_min(1e-30).log())[:,grid]
  history=log_transfer.softmax(-1)
  out=beta[:,grid]*history+(1-beta[:,grid])*current[:,grid]/sizes[grid][None]
  return out/out.sum(1,keepdim=True).clamp_min(1e-30),beta
 mass=posterior.reshape(len(posterior),len(sizes),-1).sum(-1)
 phi=posterior/mass[:,grid].clamp_min(1e-30)
 phi=torch.where((mass==0)[:,grid],1/sizes[grid][None],phi)
 return current[:,grid]*(beta[:,grid]*phi+(1-beta[:,grid])/sizes[grid][None]),beta


def fresh_posterior(mean,variance,grid,sizes,ids,raw,eligible,labels,reps,population,response='rep'):
 """Only current executed observations and current statistics enter new history.

Rep variant copies an already executed representative response to unobserved
members. It introduces no new representatives or extra sampled QK.
"""
 h,g,p,r=mean.shape;n=len(grid);a=ids.shape[1];valid=ids>=0;safe=ids.clamp_min(0).long();raw=raw.masked_fill(~valid[None,:,None],-torch.inf)
 if response=='rep':
  # Rare Value clusters cross a frame/block boundary; use coarse fallback
  # for those clusters rather than transplanting a representative across blocks.
  mismatch=(grid[reps[labels]]!=grid).to(torch.int32)
  crossing=torch.zeros(len(reps),device=ids.device,dtype=torch.int32).scatter_reduce_(0,labels.long(),mismatch,reduce='amax',include_self=True)>0
  slots=torch.full((g,n+1),-1,device=ids.device,dtype=torch.long).scatter_(1,safe.masked_fill(~valid,n),torch.arange(a,device=ids.device)[None].expand(g,-1))[:,:n]
  rep_slots=slots[:,reps];has=(rep_slots>=0)&~crossing[None]
  observed_rep=raw.gather(-1,rep_slots.clamp_min(0)[None,:,None].expand(h,-1,p,-1))
  count=torch.zeros(g,len(reps),device=ids.device).scatter_add_(1,labels[safe].long(),valid.float())
  unknown=population[None]-count
  used=(unknown*has).float()
  selected_by_block=torch.zeros(g,r,device=ids.device).scatter_add_(1,grid[safe],valid.float())
  used_by_block=torch.zeros(g,r,device=ids.device).scatter_add_(1,grid[reps][None].expand(g,-1),used)
  fallback_count=sizes[None]-selected_by_block-used_by_block
  if (fallback_count<0).any():raise ValueError('Invalid representative partition counts')
  logrep=(observed_rep+unknown.clamp_min(1).log()[None,:,None]).masked_fill((~has|(unknown==0))[None,:,None],-torch.inf)
  fallback=mean+.5*variance
  logfallback=(fallback+fallback_count.clamp_min(1).log()[None,:,None]).masked_fill((fallback_count==0)[None,:,None],-torch.inf)
  logz=torch.logaddexp(raw.logsumexp(-1),torch.logaddexp(logrep.logsumexp(-1),logfallback.logsumexp(-1)))
  rep_prob=mean_valid((observed_rep-logz[...,None]).exp(),eligible)
  fallback_prob=mean_valid((fallback-logz[...,None]).exp(),eligible)
  base=torch.where(has[:,labels],rep_prob[:,labels],fallback_prob[:,grid])
 else:
  region=grid[safe];idx=region[None,:,None].expand_as(raw);known=raw.masked_fill(~valid[None,:,None],0.)
  count=torch.zeros(g,r,device=ids.device).scatter_add_(1,region,valid.float());remaining=sizes[None]-count
  summed=torch.zeros_like(mean).scatter_add_(3,idx,known);sq=torch.zeros_like(mean).scatter_add_(3,idx,known.square())
  mu=(mean*sizes[None,None,None]-summed)/remaining.clamp_min(1)[None,:,None]
  uv=((sizes[None,None,None]*(mean.square()+variance)-sq)/remaining.clamp_min(1)[None,:,None]-mu.square()).clamp_min(0)
  logu=(mu+.5*uv+remaining.clamp_min(1).log()[None,:,None]).masked_fill((remaining==0)[None,:,None],-torch.inf)
  logz=torch.logaddexp(raw.logsumexp(-1),logu.logsumexp(-1))
  base=(mean_valid((logu-logz[...,None]).exp(),eligible)/remaining.clamp_min(1))[:,grid]
 selected=mean_valid((raw-logz[...,None]).exp(),eligible).masked_fill(~valid,0.)
 out=torch.cat((base,base.new_zeros(g,1)),1).scatter_(1,safe.masked_fill(~valid,n),selected)[:,:n]
 return out/out.sum(1,keepdim=True).clamp_min(1e-30)
