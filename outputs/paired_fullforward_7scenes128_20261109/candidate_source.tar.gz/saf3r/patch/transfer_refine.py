"""Small transfer/correction variants. No new states, dense probes or stale cache."""
import torch,triton
import triton.language as tl

VARIANTS={
 'risk025':dict(risk=.25,moment=False,temper=False),
 'risk050':dict(risk=.5,moment=False,temper=False),
 'risk075':dict(risk=.75,moment=False,temper=False),
 'moment':dict(risk=1.,moment=True,temper=False),
 'moment_risk050':dict(risk=.5,moment=True,temper=False),
 'temper050':dict(risk=1.,moment=False,temper=True),
 'temper050_risk050':dict(risk=.5,moment=False,temper=True),
}


def corrected_fresh(mean_logits,grid,sizes,ids,selected_logits,probe_valid,logit_variance=None,temper=False):
    from .one_layer_edge_history import mean_valid
    h,g,p,r=mean_logits.shape;n=len(grid);valid=ids>=0;safe=ids.clamp_min(0).long();index=grid[safe];idx=index[None,:,None].expand_as(selected_logits)
    count=torch.zeros(g,r,device=ids.device).scatter_add_(1,index,valid.float());remaining=sizes[None]-count
    raw=selected_logits.masked_fill(~valid[None,:,None],-torch.inf);finite_raw=raw.masked_fill(~valid[None,:,None],0.)
    summed=torch.zeros_like(mean_logits).scatter_add_(3,idx,finite_raw)
    mu=(mean_logits*sizes[None,None,None]-summed)/remaining.clamp_min(1)[None,:,None]
    log_remaining=mu+remaining.clamp_min(1).log()[None,:,None]
    if logit_variance is not None:
        sqsum=torch.zeros_like(mean_logits).scatter_add_(3,idx,finite_raw.square())
        second=(sizes[None,None,None]*(mean_logits.square()+logit_variance)-sqsum)/remaining.clamp_min(1)[None,:,None]
        var=(second-mu.square()).clamp_min(0.)
        log_remaining=log_remaining+.5*var
    log_remaining=log_remaining.masked_fill((remaining==0)[None,:,None],-torch.inf)
    logz=torch.logaddexp(raw.logsumexp(-1),log_remaining.logsumexp(-1))
    known=mean_valid((raw-logz[...,None]).exp(),probe_valid).masked_fill(~valid,0.)
    unknown=mean_valid((log_remaining-logz[...,None]).exp(),probe_valid)
    uniform=(unknown/remaining.clamp_min(1))[:,grid]
    posterior=torch.cat((uniform,uniform.new_zeros(g,1)),1).scatter_(1,safe.masked_fill(~valid,n),known)[:,:n]
    mass=torch.zeros(g,r,device=ids.device).scatter_add_(1,grid[None].expand(g,-1),posterior)
    phi=torch.where((mass==0)[:,grid],1/sizes[grid][None],posterior/mass[:,grid].clamp_min(1e-30))
    if temper:phi=phi.sqrt()
    sums=torch.zeros(g,r,device=ids.device).scatter_add_(1,grid[None].expand(g,-1),phi)
    return phi/sums[:,grid].clamp_min(1e-30),(remaining>=0).all()


@triton.jit
def _risk_historical(IDS,P,LABEL,DR,QUAL,KR,HM,N:tl.constexpr,F:tl.constexpr,A:tl.constexpr,B:tl.constexpr,GAIN:tl.constexpr):
    g=tl.program_id(0);i=tl.program_id(1)*B+tl.arange(0,B);key=tl.load(IDS+g*A+i,i<A,-1);valid=(i<A)&(key>=0);safe=tl.maximum(key,0)
    valid=valid&tl.load(QUAL+g*N+safe,valid,False);c=tl.load(LABEL+safe,valid,0);p=tl.load(P+g*N+safe,valid,0.);d=tl.load(DR+safe,valid,0.)
    tl.atomic_add(KR+g*F+c,p*d*GAIN,valid,sem='relaxed');tl.atomic_add(HM+g*F+c,p,valid,sem='relaxed')


class RiskKernel:
    def __init__(self,gain):self.gain=gain
    def __getitem__(self,grid):
        def run(*args,**kwargs):return _risk_historical[grid](*args,GAIN=self.gain,**kwargs)
        return run
