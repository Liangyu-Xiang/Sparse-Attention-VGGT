"""Same four-state losses;shrink uncertain prior compensation toward population."""
import torch,triton
import triton.language as tl
from .current_probe_states import _base,_historical

@triton.jit
def _weights(IDS,LABEL,REP,SEL,PRIOR,PI,HMASS,SEEN,POP,AMOUNT,OUT,N:tl.constexpr,F:tl.constexpr,A:tl.constexpr,GAMMA:tl.constexpr,B:tl.constexpr):
 g=tl.program_id(0);j=tl.program_id(1)*B+tl.arange(0,B);key=tl.load(IDS+g*A+j,j<A,-1);valid=(j<A)&(key>=0);safe=tl.maximum(key,0)
 c=tl.load(LABEL+safe,valid,0);rep=tl.load(REP+c,valid,0);state=tl.load(SEL+g*F+c,valid,0);pop=tl.load(POP+c,valid,1.);amount=tl.load(AMOUNT+g*F+c,valid,0.)
 population=tl.where(state==1,pop,tl.maximum(pop-amount+1.,1.));weight=population
 if GAMMA!=0.:
  own=tl.load(PRIOR+g*N+rep,valid,1.);total=tl.load(PI+g*F+c,valid,0.);hm=tl.load(HMASS+g*F+c,valid,0.);seen=tl.load(SEEN+g*F+c,valid,False)
  residual=total-hm+tl.where(seen,own,0.);mass=tl.where(state==1,total,residual);ratio=tl.maximum(1.,mass/tl.maximum(own,1.e-30));scaled=ratio/population
  if GAMMA==.25:weight=population*tl.sqrt(tl.sqrt(scaled))
  elif GAMMA==.5:weight=tl.sqrt(population*ratio)
  elif GAMMA==1.:weight=ratio
  else:weight=population*tl.exp(GAMMA*tl.log(scaled))
 weight=tl.where((key==rep)&((state==1)|(state==5)),weight,1.)
 tl.store(OUT+g*A+j,tl.where(valid,weight,0.),j<A)

def select(prior,pi,old_ids,allowed,z,reps,labels,population,geometry,cap,iterations):
 from . import reuse_inference_ops as rule
 from .rep_history_loss import _repair
 from saf3r.triton.reuse_compact import budget
 g,n=prior.shape;f=len(reps);w=geometry['probe_member_width'];errors=torch.empty(g,f,4,device=prior.device);costs=torch.empty_like(errors);objective=torch.empty_like(errors)
 _base[(g,triton.cdiv(f,4))](prior,geometry['members'],geometry['norm2'],geometry['rep_distance'],population,pi,errors,costs,objective,n,f,w,4,num_warps=4,enable_fp_fusion=False)
 context=rule.gate(prior,pi,population,old_ids,labels,reps);context['remove_rep']=torch.zeros_like(context['remove_rep']);kr=torch.zeros_like(pi);hm=torch.zeros_like(pi)
 _historical[(g,triton.cdiv(old_ids.shape[1],256))](old_ids,prior,labels,geometry['rep_distance'],context['qualified'],kr,hm,n,f,old_ids.shape[1],256,num_warps=4,enable_fp_fusion=False)
 amount=torch.empty_like(context['eligible_count']);_repair[(g,triton.cdiv(f,256))](errors,costs,objective,pi,kr,kr,context['eligible_count'],context['observed_rep'],reps,population,context['qualified'],amount,n,f,256,1,num_warps=4,enable_fp_fusion=False);context['eligible_count']=amount
 selected,_=budget(objective,costs,errors[:,:,0].amax(1)+1e-12,cap,iterations);selected=rule.decode(selected);ids,real,record=rule.pack(selected,None,reps,labels,population,cap,context);weights=torch.empty(ids.shape,device=ids.device)
 _weights[(g,triton.cdiv(cap,256))](ids,labels,reps,selected,prior,pi,hm,context['observed_rep'],population,amount,weights,n,f,cap,geometry['compensation_gamma'],256,num_warps=4,enable_fp_fusion=False)
 context['mass_error']=torch.zeros(g,device=prior.device);record.update(rule.diagnostics(errors,selected,None,old_ids,labels,reps,context));record['history_cap_discarded']=torch.zeros(g,device=prior.device)
 return ids,real,weights,record
