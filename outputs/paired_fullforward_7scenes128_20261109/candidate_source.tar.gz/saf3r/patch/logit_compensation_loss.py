"""Penalty for predicted mass mismatch under existing sqrt compensation."""
import torch,triton
import triton.language as tl
from .current_probe_states import _base,_historical

@triton.jit
def _penalty(E,OBJ,P,PI,POP,REP,AMOUNT,HM,SEEN,NORM,N:tl.constexpr,F:tl.constexpr,LAMBDA:tl.constexpr,B:tl.constexpr):
 g=tl.program_id(0);c=tl.program_id(1)*B+tl.arange(0,B);valid=c<F;off=(g*F+c)*4
 mass=tl.load(PI+g*F+c,valid,0.);pop=tl.load(POP+c,valid,1.);rep=tl.load(REP+c,valid,0);own=tl.load(P+g*N+rep,valid,0.)
 norm=tl.load(NORM+c,valid,0.);amount=tl.load(AMOUNT+g*F+c,valid,0);hm=tl.load(HM+g*F+c,valid,0.);seen=tl.load(SEEN+g*F+c,valid,False)
 rm=tl.sqrt(tl.maximum(pop*own*mass,0.));rp=(rm-mass)*(rm-mass)/tl.maximum(mass,1.e-30)*norm
 left=tl.maximum(mass-hm+tl.where(seen,own,0.),own);hmass=tl.sqrt(tl.maximum((pop-amount+1.)*own*left,0.));hp=(hmass-left)*(hmass-left)/tl.maximum(left,1.e-30)*norm
 oldrep=tl.load(E+off+1,valid,0.);newrep=oldrep+LAMBDA*rp
 for slot in tl.static_range(4):
  value=tl.load(E+off+slot,valid,0.)
  if slot==1:value=newrep
  if slot==2:value=value+LAMBDA*hp
  tl.store(E+off+slot,value,valid);tl.store(OBJ+off+slot,value-newrep,valid)

def select_capture(prior,old,reps,labels,pop,geo,cap,z,lam):
 from . import reuse_inference_ops as rule
 from .rep_history_loss import _repair,_weights_A
 from .rep_history_prior_weights import weights_A
 from saf3r.triton.reuse_compact import budget
 g,n=prior.shape;f=len(reps);pi=torch.empty(g,f,device=prior.device);errors=torch.empty(g,f,4,device=prior.device);costs=torch.empty_like(errors);obj=torch.empty_like(errors)
 _base[(g,triton.cdiv(f,4))](prior,geo['members'],geo['norm2'],geo['rep_distance'],pop,pi,errors,costs,obj,n,f,geo['probe_member_width'],4,num_warps=4,enable_fp_fusion=False)
 context=rule.gate(prior,pi,pop,old,labels,reps);context['remove_rep']=torch.zeros_like(context['remove_rep']);kr=torch.zeros_like(pi);hm=torch.zeros_like(pi)
 _historical[(g,triton.cdiv(old.shape[1],256))](old,prior,labels,geo['rep_distance'],context['qualified'],kr,hm,n,f,old.shape[1],256,num_warps=4,enable_fp_fusion=False)
 amount=torch.empty_like(context['eligible_count'])
 _repair[(g,triton.cdiv(f,256))](errors,costs,obj,pi,kr,kr,context['eligible_count'],context['observed_rep'],reps,pop,context['qualified'],amount,n,f,256,1,num_warps=4,enable_fp_fusion=False);context['eligible_count']=amount
 if lam:
  cnorm=(z[reps]-z.mean(0)).square().sum(-1).contiguous()
  _penalty[(g,triton.cdiv(f,256))](errors,obj,prior,pi,pop,reps,amount,hm,context['observed_rep'],cnorm,n,f,lam,256,num_warps=4,enable_fp_fusion=False)
 selected,_=budget(obj,costs,errors[:,:,0].amax(1)+1e-12,cap,16);selected=rule.decode(selected);ids,valid,record=rule.pack(selected,None,reps,labels,pop,cap,context);weights=torch.empty_like(ids,dtype=torch.float32)
 _weights_A[(g,triton.cdiv(cap,256))](ids,labels,reps,selected,pop,amount,weights,n,f,cap,256,num_warps=4)
 if context['pack_error'].any():raise RuntimeError('Support/budget failed')
 return dict(prior=prior,pi=pi,errors=errors,costs=costs,selected=selected,ids=ids,valid=valid,weights=weights,context=context)
