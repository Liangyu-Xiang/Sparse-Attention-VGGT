"""Fixed cross-head transport of previous actual logit residuals;no new QK."""
import torch
from .previous_logit_delta import correction,observe
from .logit_state_loss_models import estimate as baseline_estimate
from .group_logit_transport_coefficients import TRANSPORT
from .one_layer_edge_history import mean_valid
VARIANTS=['baseline','matrix_centered','matrix_uncentered','scalar_uncentered']

def estimate(mean,coarse,previous_C,previous_mean,ids,delta,grid,sizes,eligible,variant,layer):
 if variant=='baseline' or delta is None:return baseline_estimate(mean,coarse,previous_C,previous_mean,ids,delta,grid,sizes,eligible,'cumulant050')
 h,g,p,r=mean.shape;n=len(grid);valid=ids>=0;safe=ids.clamp_min(0).long();block=grid[safe];ix=block[None,:,None].expand(h,-1,p,-1)
 if variant=='matrix_centered':
  work=correction(delta,ids,grid,mean,previous_mean,torch.zeros_like(coarse),'centered_direct');mode='centered'
 else:work=delta;mode='uncentered'
 if variant=='scalar_uncentered':change=.5*work
 else:change=(work.new_tensor(TRANSPORT[mode][layer])@work.reshape(h,-1)).reshape_as(work)
 if variant=='matrix_centered':
  count=torch.zeros(g,r,device=ids.device).scatter_add_(1,block,valid.float());var=torch.zeros_like(mean).scatter_add_(3,ix,change.square().masked_fill(~valid[None,:,None],0.))/count.clamp_min(1)[None,:,None];change=change-.25*var.gather(3,ix)
 scores=mean[...,grid].clone();updated=mean.gather(3,ix)+change;tomb=safe.masked_fill(~valid,n)[None,:,None].expand(h,-1,p,-1)
 scores=torch.cat((scores,scores.new_zeros(h,g,p,1)),-1).scatter_(3,tomb,updated.masked_fill(~valid[None,:,None],0.))[...,:n]
 return mean_valid(scores.softmax(-1),eligible).contiguous(),torch.zeros_like(coarse)
