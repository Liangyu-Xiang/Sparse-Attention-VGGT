"""Unnormalised patch-only importance with persistent relative multipliers.

No anchors, decay, mixing, block redistribution, or Dense-oracle inputs.
Q/K must already contain the model's head-specific normalisation and RoPE.
"""
from __future__ import annotations
import torch


def fixed_spatial_blocks(n: int, patches_per_frame: int, block: int, device):
    if n % patches_per_frame or block < 1:
        raise ValueError('Expected complete fixed frames and a positive block size')
    pos = torch.arange(n, device=device)
    per_frame = (patches_per_frame + block - 1) // block
    grid = (pos // patches_per_frame) * per_frame + (pos % patches_per_frame) // block
    sizes = torch.bincount(grid).float()
    return grid, sizes


def observe_blocks(q, patch_keys, grid, sizes, scale):
    """q[head,group,probe,dim]; independent head/probe reference normalizers."""
    h, n, d = patch_keys.shape
    pooled = torch.zeros(h, len(sizes), d, device=patch_keys.device, dtype=torch.float32)
    pooled.index_add_(1, grid, patch_keys.float())
    pooled /= sizes[None, :, None]
    score = torch.einsum('hgpd,hrd->hgpr', q.float(), pooled) * scale
    log_denominator = torch.logsumexp(score + sizes.log()[None, None, None], -1)
    uniform = (score - log_denominator[..., None]).exp().mean((0, 2))
    return uniform, log_denominator


def predict(uniform, grid, multipliers):
    return uniform[:, grid] * multipliers


def observed_weights(raw_selected_logits, log_denominator, valid):
    # No selected-support softmax or population-compensated logits.
    weights = (raw_selected_logits - log_denominator[..., None]).exp().mean((0, 2))
    return weights.masked_fill(~valid, 0.)


def update(multipliers, uniform, grid, selected_ids, raw_selected_logits,
           log_denominator, layer, last_observed=None, epsilon=1e-30):
    """Overwrite only genuinely observed keys; leave every other multiplier intact."""
    valid = selected_ids >= 0
    safe = selected_ids.clamp_min(0).long()
    weights = observed_weights(raw_selected_logits, log_denominator, valid)
    base = uniform[:, grid].gather(1, safe)
    ratios = weights / (base + epsilon)
    out = multipliers.clone()
    age = None if last_observed is None else last_observed.clone()
    for group in range(len(out)):
        index = safe[group, valid[group]]
        if len(index) != len(index.unique()):
            raise ValueError('Repeated support keys must be deduplicated before update')
        out[group, index] = ratios[group, valid[group]]
        if age is not None:
            age[group, index] = layer
    return out, age
