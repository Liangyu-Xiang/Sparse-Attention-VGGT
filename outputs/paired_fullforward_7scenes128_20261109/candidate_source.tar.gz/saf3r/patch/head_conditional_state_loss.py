"""Head-conditional predicted-logit losses using already available Value vectors."""
import torch,triton
from .previous_logit_delta import correction,observe
from .current_probe_states import _base,_historical
VARIANTS=['baseline','full_marginal','full_joint50','full_joint100','full_unknown50','full_unknown100']

def estimate(mean,coarse,previous_C,previous_mean,ids,delta,grid,sizes,eligible):
 h,g,p,r=mean.shape;assert p==1;n=len(grid);scores=mean[...,grid].clone()
 if delta is not None:
  valid=ids>=0;safe=ids.clamp_min(0).long();block=grid[safe];ix=block[None,:,None].expand(h,-1,p,-1);count=torch.zeros(g,r,device=ids.device).scatter_add_(1,block,valid.float())
  change=correction(delta,ids,grid,mean,previous_mean,torch.zeros_like(coarse),'centered050');var=torch.zeros_like(mean).scatter_add_(3,ix,change.square().masked_fill(~valid[None,:,None],0.))/count.clamp_min(1)[None,:,None];change=change-.25*var.gather(3,ix)
  updated=mean.gather(3,ix)+change;tomb=safe.masked_fill(~valid,n)[None,:,None].expand(h,-1,p,-1)
  scores=torch.cat((scores,scores.new_zeros(h,g,p,1)),-1).scatter_(3,tomb,updated.masked_fill(~valid[None,:,None],0.))[...,:n]
 ph=scores.softmax(-1)[:,:,0];return ph.mean(0).contiguous(),torch.zeros_like(coarse),ph

def losses(prior,ph,v,labels,reps,qualified,old,variant):
 h,g,n=ph.shape;f=len(reps);norm=v.square().sum(-1);scale=norm.sum(0).mean().clamp_min(1e-12);norm=norm/scale;dist=(v-v[:,reps[labels]]).square().sum(-1)/scale
 def agg(a):return torch.zeros(h,g,f,device=ph.device).scatter_add_(2,labels[None,None].expand_as(a).long(),a).sum(0)
 drop=agg(prior[None]*norm[:,None]);rep=agg(prior[None]*dist[:,None]);hist=agg(prior[None]*dist[:,None]*(~qualified)[None])
 if variant!='full_marginal':
  eta=.5 if variant.endswith('50') else 1.
  if 'unknown' in variant:
   known=torch.zeros(g,n+1,device=ph.device,dtype=torch.bool);valid=old>=0;known.scatter_(1,old.clamp_min(0).long().masked_fill(~valid,n),valid);unknown=(~known[:,:n])[None]
   dp=(ph-prior[None])*unknown;dc=agg(dp*norm[:,None]);rc=agg(dp*dist[:,None]);drop=(drop+eta*dc).clamp_min(0);rep=(rep+eta*rc).clamp_min(0);hist=(hist+eta*rc).clamp_min(0)
  else:
   drop=(1-eta)*drop+eta*agg(ph*norm[:,None]);rep=(1-eta)*rep+eta*agg(ph*dist[:,None]);hist=(1-eta)*hist+eta*agg(ph*dist[:,None]*(~qualified)[None])
 return torch.stack((drop,rep,hist,torch.zeros_like(rep)),-1)

def select_capture(prior,old,reps,labels,pop,geo,cap,v,ph,variant):
 from . import reuse_inference_ops as rule
 from .rep_history_loss import _repair,_weights_A
 from saf3r.triton.reuse_compact import budget
 g,n=prior.shape;f=len(reps);pi=torch.empty(g,f,device=prior.device);errors=torch.empty(g,f,4,device=prior.device);costs=torch.empty_like(errors);obj=torch.empty_like(errors)
 _base[(g,triton.cdiv(f,4))](prior,geo['members'],geo['norm2'],geo['rep_distance'],pop,pi,errors,costs,obj,n,f,geo['probe_member_width'],4,num_warps=4,enable_fp_fusion=False)
 context=rule.gate(prior,pi,pop,old,labels,reps);context['remove_rep']=torch.zeros_like(context['remove_rep']);kr=torch.zeros_like(pi);hm=torch.zeros_like(pi)
 _historical[(g,triton.cdiv(old.shape[1],256))](old,prior,labels,geo['rep_distance'],context['qualified'],kr,hm,n,f,old.shape[1],256,num_warps=4,enable_fp_fusion=False)
 amount=torch.empty_like(context['eligible_count']);_repair[(g,triton.cdiv(f,256))](errors,costs,obj,pi,kr,kr,context['eligible_count'],context['observed_rep'],reps,pop,context['qualified'],amount,n,f,256,1,num_warps=4,enable_fp_fusion=False);context['eligible_count']=amount
 if variant!='baseline':errors=losses(prior,ph,v,labels,reps,context['qualified'],old,variant);errors[:,:,2].masked_fill_(amount==0,float('inf'));obj=errors-errors[:,:,1:2]
 selected,_=budget(obj,costs,errors[:,:,0].amax(1)+1e-12,cap,16);selected=rule.decode(selected);ids,valid,record=rule.pack(selected,None,reps,labels,pop,cap,context);weights=torch.empty_like(ids,dtype=torch.float32)
 _weights_A[(g,triton.cdiv(cap,256))](ids,labels,reps,selected,pop,amount,weights,n,f,cap,256,num_warps=4)
 if context['pack_error'].any():raise RuntimeError('Support/budget failed')
 return dict(prior=prior,pi=pi,errors=errors,costs=costs,selected=selected,ids=ids,valid=valid,weights=weights,context=context)
