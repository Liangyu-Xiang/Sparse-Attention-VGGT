"""Uniform conditional prior from head-averaged current block probability mass."""

def per_key_prior(block_mass,grid,sizes):
    return (block_mass[:,grid]/sizes[grid][None]).contiguous()
