"""Current correction uses ONLY explicitly authorized previous executed edges.

No full current ordinary-Key QK scan. Optional low-rank feature residual is a
statistical correction learned from those validated edges, not exact QK.
"""
import torch
from .one_layer_edge_history import mean_valid


def current_proxy(mean,var,grid,sizes,ids,raw,eligible,labels,reps,population,distance):
 h,g,p,r=mean.shape;n=len(grid);a=ids.shape[1];f=len(reps);valid=ids>=0;safe=ids.clamp_min(0).long();c=labels[safe].long()
 dist=distance[safe].masked_fill(~valid,torch.inf)
 best=torch.full((g,f),torch.inf,device=ids.device).scatter_reduce_(1,c,dist,reduce='amin',include_self=True)
 rank=torch.arange(a,device=ids.device)[None].expand(g,-1)
 chosen=valid&(dist==best.gather(1,c))
 slot=torch.full((g,f),a,device=ids.device,dtype=torch.long).scatter_reduce_(1,c,rank.masked_fill(~chosen,a),reduce='amin',include_self=True)
 mismatch=(grid[reps[labels]]!=grid).int();cross=torch.zeros(f,device=ids.device,dtype=torch.int32).scatter_reduce_(0,labels.long(),mismatch,reduce='amax',include_self=True)>0
 has=(slot<a)&~cross[None]
 raw=raw.masked_fill(~valid[None,:,None],-torch.inf)
 proxy=raw.gather(-1,slot.clamp_max(a-1)[None,:,None].expand(h,-1,p,-1))
 count=torch.zeros(g,f,device=ids.device).scatter_add_(1,c,valid.float());unknown=population[None]-count
 by_block=torch.zeros(g,r,device=ids.device).scatter_add_(1,grid[safe],valid.float())
 covered=torch.zeros(g,r,device=ids.device).scatter_add_(1,grid[reps][None].expand(g,-1),unknown*has)
 fallback_count=sizes[None]-by_block-covered
 if (fallback_count<0).any():raise ValueError('Invalid sparse-correction partition counts')
 lr=(proxy+unknown.clamp_min(1).log()[None,:,None]).masked_fill((~has|(unknown==0))[None,:,None],-torch.inf)
 fallback=mean+.5*var
 lf=(fallback+fallback_count.clamp_min(1).log()[None,:,None]).masked_fill((fallback_count==0)[None,:,None],-torch.inf)
 logz=torch.logaddexp(raw.logsumexp(-1),torch.logaddexp(lr.logsumexp(-1),lf.logsumexp(-1)))
 known=mean_valid((raw-logz[...,None]).exp(),eligible).masked_fill(~valid,0.)
 pp=mean_valid((proxy-logz[...,None]).exp(),eligible);fb=mean_valid((fallback-logz[...,None]).exp(),eligible)
 base=torch.where(has[:,labels],pp[:,labels],fb[:,grid])
 out=torch.cat((base,base.new_zeros(g,1)),1).scatter_(1,safe.masked_fill(~valid,n),known)[:,:n]
 return out/out.sum(1,keepdim=True).clamp_min(1e-30),known,logz


def statistics(transferred,known,ids,grid,r):
 valid=ids>=0;safe=ids.clamp_min(0).long();region=grid[safe]
 x=transferred.gather(1,safe).clamp_min(1e-30).log();y=known.clamp_min(1e-30).log()
 def agg(value):return torch.zeros(len(ids),r,device=ids.device).scatter_add_(1,region,value.masked_fill(~valid,0.))
 count=agg(torch.ones_like(x));mx=agg(x)/count.clamp_min(1);my=agg(y)/count.clamp_min(1)
 vx=(agg(x*x)/count.clamp_min(1)-mx*mx).clamp_min(0);vy=(agg(y*y)/count.clamp_min(1)-my*my).clamp_min(0);cov=agg(x*y)/count.clamp_min(1)-mx*my
 slope=(cov/vx.clamp_min(1e-12)).clamp(0,1);slope=torch.where(count>=2,slope,torch.ones_like(slope))
 reliability=(cov.clamp_min(0).square()/(vx*vy).clamp_min(1e-12)).clamp(0,1);reliability=torch.where(count>=2,reliability,torch.zeros_like(reliability))
 return slope,reliability


def cluster_correct(transferred,current,known,ids,labels,grid,coarse,sizes,mode='ratio'):
 g,n=transferred.shape;valid=ids>=0;safe=ids.clamp_min(0).long();f=int(labels.max())+1;r=len(sizes)
 if mode=='proxy_blend':out=.75*current+.25*transferred
 else:
  slope,reliability=statistics(transferred,known,ids,grid,r)
  logbase=(coarse[:,grid]/sizes[grid][None]).clamp_min(1e-30).log()
  logshape=transferred.clamp_min(1e-30).log()
  if mode in ['slope','reliability']:logshape=logbase+slope[:,grid]*(logshape-logbase)
  shape=logshape.exp();c=labels[safe].long()
  actual=torch.zeros(g,f,device=ids.device).scatter_add_(1,c,known*valid)
  expected=torch.zeros(g,f,device=ids.device).scatter_add_(1,c,shape.gather(1,safe)*valid)
  ratio=torch.where(expected>0,actual/expected.clamp_min(1e-30),torch.ones_like(actual))
  out=shape*ratio[:,labels]
  out=out/out.sum(1,keepdim=True).clamp_min(1e-30)
  if mode=='reliability':out=reliability[:,grid]*out+(1-reliability[:,grid])*current
 # Actual current validation always replaces inferred weights on observed edges.
 out=torch.cat((out,out.new_zeros(g,1)),1).scatter_(1,safe.masked_fill(~valid,n),known)[:,:n]
 return out/out.sum(1,keepdim=True).clamp_min(1e-30)


def ridge_correct(transferred,known,ids,grid,sizes,features,regularization=.1):
 g,n=transferred.shape;r=len(sizes);d=features.shape[1];valid=ids>=0;safe=ids.clamp_min(0).long();region=grid[safe]
 # Current Key sketch is query independent. Only observed residuals fit coefficients.
 x=features.reshape(r,-1,d);x=(x-x.mean(1,keepdim=True))/x.square().mean((1,2),keepdim=True).clamp_min(1e-8).sqrt();x=x.reshape(n,d)
 counts=torch.zeros(g,r,device=ids.device,dtype=torch.long).scatter_add_(1,region,valid.long());width=int(counts.max().clamp_min(1))
 starts=counts.cumsum(1)-counts;rank=torch.arange(ids.shape[1],device=ids.device)[None]-starts.gather(1,region);slot=(region*width+rank).masked_fill(~valid,r*width)
 xx=torch.cat((x[safe],torch.ones(g,ids.shape[1],1,device=ids.device)),-1)*valid[...,None]
 yy=(known.clamp_min(1e-30).log()-transferred.gather(1,safe).clamp_min(1e-30).log()).masked_fill(~valid,0.)
 xp=torch.zeros(g,r*width+1,d+1,device=ids.device).scatter_(1,slot[...,None].expand(-1,-1,d+1),xx)[:,:r*width].reshape(g*r,width,d+1)
 yp=torch.zeros(g,r*width+1,device=ids.device).scatter_(1,slot,yy)[:,:r*width].reshape(g*r,width,1)
 gram=xp.transpose(1,2)@xp;target=xp.transpose(1,2)@yp
 diag=torch.eye(d+1,device=ids.device)[None].expand(g*r,-1,-1).clone();diag[:,-1,-1]=0
 gram=gram+regularization*counts.reshape(-1,1,1).clamp_min(1)*diag
 empty=counts.reshape(-1)==0;gram[empty]=torch.eye(d+1,device=ids.device);target[empty]=0
 coef=torch.linalg.solve(gram,target).reshape(g,r,d+1)
 residual=torch.einsum('rnd,grd->grn',x.reshape(r,-1,d),coef[:,:,:d])+coef[:,:,d,None]
 lower=torch.full((g,r),torch.inf,device=ids.device).scatter_reduce_(1,region,yy.masked_fill(~valid,torch.inf),reduce='amin',include_self=True)
 upper=torch.full((g,r),-torch.inf,device=ids.device).scatter_reduce_(1,region,yy.masked_fill(~valid,-torch.inf),reduce='amax',include_self=True)
 lower=lower.masked_fill(counts==0,0.);upper=upper.masked_fill(counts==0,0.)
 residual=residual.clamp(min=lower[...,None],max=upper[...,None]).reshape(g,n)
 logw=transferred.clamp_min(1e-30).log()+residual
 logw=torch.cat((logw,logw.new_zeros(g,1)),1).scatter_(1,safe.masked_fill(~valid,n),known.clamp_min(1e-30).log())[:,:n]
 return logw.softmax(-1)
