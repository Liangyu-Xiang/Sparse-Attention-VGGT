"""Frozen small head alignment plus existing block centering and shrink."""
import torch
from .one_layer_edge_history import mean_valid
from .previous_logit_delta import observe
from .logit_head_alignment import ALIGNMENT
VARIANTS=['align_top1','align_top2','align_top2_scale']

def estimate(mean,coarse,previous_coarse,previous_mean,ids,delta,grid,sizes,eligible,variant,layer):
 h,g,p,r=mean.shape;n=len(grid)
 if delta is None:return mean_valid(mean[...,grid].softmax(-1),eligible).contiguous(),torch.zeros_like(coarse)
 aligned=not (variant in ['align_mid_baseline','align_mid_soft'] and not 6<=layer<=17)
 if aligned:
  mapping=torch.tensor(ALIGNMENT['maps'][layer],device=mean.device,dtype=torch.long)
  shifted=delta[mapping[:,0]] if variant=='align_top1' else delta[mapping].mean(1)
 else:shifted=delta
 valid=ids>=0;safe=ids.clamp_min(0).long();block=grid[safe];ix=block[None,:,None].expand(h,-1,p,-1);count=torch.zeros(g,r,device=ids.device).scatter_add_(1,block,valid.float());total=torch.zeros(h,g,p,r,device=ids.device).scatter_add_(3,ix,shifted.masked_fill(~valid[None,:,None],0.));m=(total/count.clamp_min(1)[None,:,None]).gather(3,ix)
 if not aligned:a=.5 if variant=='align_mid_baseline' else (.25 if layer<6 else .1)
 else:
  a=torch.tensor(ALIGNMENT['scales'][layer],device=mean.device)[:,None,None,None] if variant in ['align_top2_scale','align_mid_baseline','align_mid_soft','align_all_soft'] else .5
  if variant=='align_all_soft':a=a*(.5 if layer<6 else 1. if layer<18 else .2)
 change=a*(shifted-m)
 scores=mean[...,grid].clone();values=mean.gather(3,ix)+change;tombstone=safe.masked_fill(~valid,n)[None,:,None].expand(h,-1,p,-1);scores=torch.cat((scores,scores.new_zeros(h,g,p,1)),-1).scatter_(3,tombstone,values.masked_fill(~valid[None,:,None],0.))[...,:n]
 return mean_valid(scores.softmax(-1),eligible).contiguous(),torch.zeros_like(coarse)
