"""Two existing Value-loss scalars as a frozen logit prior;actual-only history."""
import torch
from .logit_value_bias_coefficients import COEFFICIENTS
from .previous_logit_delta import estimate as baseline_estimate,observe as baseline_observe,correction
from .one_layer_edge_history import mean_valid
VARIANTS=['baseline','value_global','value_stage','value_layer','value_global_half','value_stage_half']

def bias(z,labels,reps,grid,sizes,layer,variant):
 if variant=='baseline':return z.new_zeros(len(z))
 mode=variant.split('_')[1];coef=COEFFICIENTS[mode][layer];x=torch.stack((z.square().sum(-1),(z-z[reps[labels]]).square().sum(-1)),-1)
 center=torch.zeros(len(sizes),2,device=z.device).index_add_(0,grid,x)/sizes[:,None]
 result=(x-center[grid])@x.new_tensor(coef)
 return result*(.5 if variant.endswith('_half') else 1.)

def estimate(mean,coarse,previous_C,previous_mean,ids,delta,grid,sizes,eligible,variant,key_bias):
 if variant=='baseline':return baseline_estimate(mean,coarse,previous_C,previous_mean,ids,delta,grid,sizes,eligible,'centered050')
 h,g,p,r=mean.shape;n=len(grid);scores=mean[...,grid]+key_bias[None,None,None]
 if delta is not None:
  valid=ids>=0;safe=ids.clamp_min(0).long();ix=grid[safe][None,:,None].expand(h,-1,p,-1)
  change=correction(delta,ids,grid,mean,previous_mean,torch.zeros_like(coarse),'centered050')
  updated=mean.gather(3,ix)+key_bias[safe][None,:,None]+change
  tomb=safe.masked_fill(~valid,n)[None,:,None].expand(h,-1,p,-1)
  scores=torch.cat((scores,scores.new_zeros(h,g,p,1)),-1).scatter_(3,tomb,updated.masked_fill(~valid[None,:,None],0.))[...,:n]
 return mean_valid(scores.softmax(-1),eligible).contiguous(),torch.zeros_like(coarse)

def observe(mean,grid,ids,selected,key_bias):
 raw=baseline_observe(mean,grid,ids,selected);valid=ids>=0;return (raw-key_bias[ids.clamp_min(0).long()][None,:,None]).masked_fill(~valid[None,:,None],0.).contiguous()
