"""Only previous actual support has cached history; unseen keys stay coarse uniform.

Observed raw logits use the SAME layer's coarse block-only normalizer for scale.
This is an approximation,not Dense or selected-support softmax probability.
"""
import torch
from .one_layer_edge_history import mean_valid

def estimate(current,previous,ids,observed,grid,sizes):
 g,r=current.shape;n=len(grid);base=current[:,grid]/sizes[grid][None]
 if previous is None:
  return base.contiguous(),torch.zeros_like(current)
 assert ids is not None and observed.shape==ids.shape
 beta=(2*current.sqrt()*previous.sqrt()/(current+previous).clamp_min(1e-30)).clamp(0,1)
 valid=ids>=0;safe=ids.clamp_min(0).long();block=grid[safe]
 change=(current/previous.clamp_min(1e-30)).gather(1,block)
 b=beta.gather(1,block);u=base.gather(1,safe)
 known=b*observed*change+(1-b)*u
 # No global fine probability normalization;state losses consume these weights.
 out=torch.cat((base,base.new_zeros(g,1)),1).scatter_(1,safe.masked_fill(~valid,n),known.masked_fill(~valid,0.))[:,:n]
 return out.contiguous(),beta

def observe(mean_logits,sizes,ids,raw,eligible):
 # Coarse denominator requires only Query x mean(Key block),not unknown edge QK.
 logz=(mean_logits+sizes.log()[None,None,None]).logsumexp(-1)
 weights=mean_valid((raw-logz[...,None]).exp(),eligible).masked_fill(ids<0,0.)
 return weights.contiguous()
