"""Use aligned coarse logits to estimate current-to-previous response slope."""
import torch
from .previous_logit_delta import correction,observe
from .logit_state_loss_models import estimate as baseline_estimate
from .one_layer_edge_history import mean_valid
VARIANTS=['baseline','slope_centered','corr_centered','slope_moment','corr_moment']

def estimate(mean,coarse,previous_C,previous_mean,ids,delta,grid,sizes,eligible,variant):
 if variant=='baseline' or delta is None:return baseline_estimate(mean,coarse,previous_C,previous_mean,ids,delta,grid,sizes,eligible,'cumulant050')
 h,g,p,r=mean.shape;n=len(grid);x=previous_mean-previous_mean.mean(-1,keepdim=True);y=mean-mean.mean(-1,keepdim=True);cov=(x*y).mean(-1);vx=x.square().mean(-1);vy=y.square().mean(-1)
 if variant.startswith('slope'):a=.5*(cov/(vx+1e-6)).clamp(0,1)
 else:a=.5*(cov/((vx*vy).sqrt()+1e-6)).clamp(0,1)
 valid=ids>=0;safe=ids.clamp_min(0).long();block=grid[safe];ix=block[None,:,None].expand(h,-1,p,-1);count=torch.zeros(g,r,device=ids.device).scatter_add_(1,block,valid.float())
 if variant.endswith('centered'):
  work=correction(delta,ids,grid,mean,previous_mean,torch.zeros_like(coarse),'centered_direct');change=a[...,None]*work;var=torch.zeros_like(mean).scatter_add_(3,ix,change.square().masked_fill(~valid[None,:,None],0.))/count.clamp_min(1)[None,:,None];change=change-.25*var.gather(3,ix);scores=mean[...,grid].clone()
 else:
  change=a[...,None]*delta;total=torch.zeros_like(mean).scatter_add_(3,ix,change.masked_fill(~valid[None,:,None],0.));remaining=sizes[None]-count;offset=-total/remaining.clamp_min(1)[None,:,None];scores=(mean+offset)[...,grid].clone()
 updated=mean.gather(3,ix)+change;tomb=safe.masked_fill(~valid,n)[None,:,None].expand(h,-1,p,-1)
 scores=torch.cat((scores,scores.new_zeros(h,g,p,1)),-1).scatter_(3,tomb,updated.masked_fill(~valid[None,:,None],0.))[...,:n]
 return mean_valid(scores.softmax(-1),eligible).contiguous(),a.mean((0,2))[:,None].expand(-1,r).contiguous()
