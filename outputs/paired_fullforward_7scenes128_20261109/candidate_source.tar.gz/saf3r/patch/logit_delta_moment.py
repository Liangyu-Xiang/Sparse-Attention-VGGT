"""Block first-moment consistency using previous actual-support residuals only.

Unknown keys remain uniform within each block and have no historical cache.
Their single common offset balances estimated known offsets,so the estimated
ALL-key block mean exactly equals current coarse meanKey logit.
"""
import torch
from .one_layer_edge_history import mean_valid
from .previous_logit_delta import observe
VARIANTS=['balanced010','balanced025','balanced050','balanced_stage','balanced_layer']

def estimate(mean,coarse,previous_coarse,previous_mean,ids,delta,grid,sizes,eligible,variant,layer):
 h,g,p,r=mean.shape;n=len(grid)
 if delta is None:return mean_valid(mean[...,grid].softmax(-1),eligible).contiguous(),torch.zeros_like(coarse)
 if variant=='balanced_stage':a=.25 if layer<6 else .5 if layer<18 else .1;b=.5*a
 elif variant=='balanced_layer':
  from .logit_transition_coefficients import COEFFICIENTS
  a=.5 if 6<=layer<=17 else COEFFICIENTS['fit_layer_plain_scalar'][layer][0];b=.5*a
 else:a=.5;b={'balanced010':.1,'balanced025':.25,'balanced050':.5}[variant]
 valid=ids>=0;safe=ids.clamp_min(0).long();block=grid[safe];index=block[None,:,None].expand(h,-1,p,-1);count=torch.zeros(g,r,device=ids.device).scatter_add_(1,block,valid.float());remaining=sizes[None]-count
 total=torch.zeros(h,g,p,r,device=ids.device).scatter_add_(3,index,delta.masked_fill(~valid[None,:,None],0.));m=total/count.clamp_min(1)[None,:,None];mean_shift=b*m;mean_shift=mean_shift.masked_fill((remaining==0)[None,:,None],0.)
 unknown=-mean_shift*(count/remaining.clamp_min(1))[None,:,None]
 scores=(mean+unknown)[...,grid].clone();known=a*(delta-m.gather(3,index))+mean_shift.gather(3,index);values=mean.gather(3,index)+known
 tombstone=safe.masked_fill(~valid,n)[None,:,None].expand(h,-1,p,-1)
 scores=torch.cat((scores,scores.new_zeros(h,g,p,1)),-1).scatter_(3,tombstone,values.masked_fill(~valid[None,:,None],0.))[...,:n]
 return mean_valid(scores.softmax(-1),eligible).contiguous(),torch.zeros_like(coarse)
