"""Normalize each head and contiguous64Query statistic before averaging.

Routing and budgets still use256Query groups; no individual-QK probes.
"""
import torch
from .beta_unified_importance import estimate
from .one_layer_edge_history import mean_valid

def observe(mean,grid,sizes,ids,raw,counts):
 valid=ids>=0;safe=ids.clamp_min(0).long();block=grid[safe];g=len(ids)
 seen=mean.new_zeros(g,len(sizes)).scatter_add_(1,block,valid.float());missing=(sizes[None]-seen).clamp_min(0)
 shift=(mean+sizes.log()[None,None,None]).logsumexp(-1)
 unknown=((mean-shift[...,None]).exp()*missing[None,:,None]).sum(-1)
 observed=raw.masked_fill(~valid[None,:,None],0.)
 hp=observed/(observed.sum(-1)+unknown).clamp_min(1e-30)[...,None]
 return mean_valid(hp,counts).masked_fill(~valid,0.).contiguous()
