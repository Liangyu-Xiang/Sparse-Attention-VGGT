"""Current block mass + historical conditional; selected-aware reference partition.

Patch-only inputs. No oracle probabilities, anchors, mixing, temperature changes,
clipping, or second selected QK. Probability mass redistribution is intentional.
"""
from __future__ import annotations
import torch


def block_sum(x, grid, regions):
    return torch.zeros(x.shape[0], regions, device=x.device, dtype=x.dtype).scatter_add_(1, grid[None].expand_as(x), x)


def observe(q, patch_keys, grid, sizes, scale):
    h, n, d = patch_keys.shape
    pooled = torch.zeros(h, len(sizes), d, device=patch_keys.device, dtype=torch.float32)
    pooled.index_add_(1, grid, patch_keys.float())
    pooled /= sizes[None, :, None]
    score = torch.einsum('hgpd,hrd->hgpr', q.float(), pooled) * scale
    log_total = torch.logsumexp(score + sizes.log()[None, None, None], -1)
    mass = (score + sizes.log()[None, None, None] - log_total[..., None]).exp().mean((0, 2))
    return {'mean_logits': score, 'coarse_mass': mass, 'log_denominator': log_total}


def initial_conditional(groups, grid, sizes):
    return (1. / sizes[grid])[None].expand(groups, -1).clone()


def predict(observation, grid, conditional):
    # Current coarse mass controls scale; history controls within-block shape.
    return observation['coarse_mass'][:, grid] * conditional


def assimilate(conditional, observation, grid, sizes, selected_ids, selected_logits):
    valid = selected_ids >= 0
    safe = selected_ids.clamp_min(0).long()
    regions = len(sizes)
    g, n = conditional.shape
    score = observation['mean_logits']
    h, sg, probes, r = score.shape
    if sg != g or r != regions:
        raise ValueError('Observation/cache layout mismatch')
    selected_regions = grid[safe]
    index = selected_regions[None, :, None].expand_as(selected_logits)
    count = torch.zeros(g, r, device=conditional.device).scatter_add_(1, selected_regions, valid.float())
    remaining = sizes[None] - count
    if (remaining < 0).any():
        raise ValueError('Duplicate or invalid selected support')
    raw = selected_logits.masked_fill(~valid[None, :, None], -torch.inf)
    selected_logit_sum = torch.zeros_like(score).scatter_add_(3, index, raw.masked_fill(~valid[None, :, None], 0.))
    mean_remaining = (sizes[None, None, None] * score - selected_logit_sum) / remaining.clamp_min(1)[None, :, None]
    log_unobserved = mean_remaining + remaining.clamp_min(1).log()[None, :, None]
    log_unobserved = log_unobserved.masked_fill((remaining == 0)[None, :, None], -torch.inf)
    maxima = torch.full_like(score, -torch.inf).scatter_reduce_(3, index, raw, reduce='amax', include_self=True)
    safe_max = maxima.masked_fill(~torch.isfinite(maxima), 0.)
    centered = raw - safe_max.gather(3, index)
    exp_sum = torch.zeros_like(score).scatter_add_(3, index, centered.exp())
    log_selected = (exp_sum.clamp_min(1e-30).log() + safe_max).masked_fill((count == 0)[None, :, None], -torch.inf)
    log_total = torch.logsumexp(torch.logaddexp(log_selected, log_unobserved), -1)
    observed = (raw - log_total[..., None]).exp().mean((0, 2)).masked_fill(~valid, 0.)
    unobserved_mass = (log_unobserved - log_total[..., None]).exp().mean((0, 2))
    tombstone_ids = safe.masked_fill(~valid, n)
    observed_mask = torch.zeros(g, n + 1, device=conditional.device, dtype=torch.bool).scatter_(1, tombstone_ids, valid)[:, :n]
    history_remaining = conditional.masked_fill(observed_mask, 0.)
    history_remaining_mass = block_sum(history_remaining, grid, r)
    # A zero historical conditional on the whole residual set has no defined
    # relative shape. Use uniform only for that mathematical zero-mass case.
    fallback = (history_remaining_mass == 0) & (remaining > 0)
    distributed = history_remaining * (unobserved_mass / history_remaining_mass.clamp_min(1e-30))[:, grid]
    uniform_remaining = (unobserved_mass / remaining.clamp_min(1))[:, grid]
    distributed = torch.where(fallback[:, grid] & ~observed_mask, uniform_remaining, distributed)
    posterior = torch.cat((distributed, torch.zeros(g, 1, device=conditional.device)), 1).scatter_(1, tombstone_ids, observed)[:, :n]
    posterior_mass = block_sum(posterior, grid, r)
    next_conditional = posterior / posterior_mass[:, grid].clamp_min(1e-30)
    zero_blocks = posterior_mass == 0
    next_conditional = torch.where(zero_blocks[:, grid], (1. / sizes[grid])[None], next_conditional)
    return dict(conditional=next_conditional, posterior=posterior, block_mass=posterior_mass,
                log_denominator=log_total, observed_mass=observed.sum(1), unobserved_mass=unobserved_mass.sum(1),
                residual_history_zero_fallback_blocks=fallback.sum(1), zero_posterior_blocks=zero_blocks.sum(1))
