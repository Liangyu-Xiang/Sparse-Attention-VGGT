"""Historical relative logits and output/normalizer-aware state scoring.

Fixed-QKV prototype. No geometric truth, anchors, head-logit averaging, or
retention changes. Group-state moments use the SAME support and compensation
that will be executed. All predicted accept decisions are oracle-free.
"""
import math
import torch


def observe(q,k,grid,sizes,scale):
 h,n,d=k.shape
 pooled=torch.zeros(h,len(sizes),d,device=k.device).index_add_(1,grid,k.float())/sizes[None,:,None]
 return torch.einsum('hgpd,hrd->hgpr',q.float(),pooled)*scale


def estimate(mean_logits,grid,residual):
 return mean_logits[...,grid]+residual


def update_residual(residual,mean_logits,grid,ids,raw):
 valid=ids>=0;safe=ids.clamp_min(0).long();index=grid[safe][None,:,None].expand_as(raw)
 delta=raw-mean_logits.gather(-1,index)
 out=residual.clone()
 for g in range(ids.shape[0]):
  selected=safe[g,valid[g]]
  out[:,g].scatter_(2,selected[None,None].expand(out.shape[0],out.shape[2],-1),delta[:,g][:,:,valid[g]])
 return out


def projection_values(v,output_weight,dimension=16,seed=113):
 h,n,d=v.shape;generator=torch.Generator().manual_seed(seed)
 random=(torch.randint(0,2,(dimension,output_weight.shape[0]),generator=generator).float()*2-1)/math.sqrt(dimension)
 combined=random.to(v.device)@output_weight.float()
 return torch.einsum('hnd,shd->hns',v.float(),combined.reshape(dimension,h,d)),random.to(v.device)


def context(prior,pi,population,labels,reps,qualified,has_history):
 # qualified is the original gate BEFORE its History-A Rep insertion.
 g,n=prior.shape;f=len(reps);isrep=torch.arange(n,device=prior.device)==reps[labels]
 nonrep=qualified&~isrep[None]
 hm=torch.zeros(g,f,device=prior.device).scatter_add_(1,labels[None].expand(g,-1),prior*nonrep)
 amount=torch.zeros(g,f,device=prior.device).scatter_add_(1,labels[None].expand(g,-1),nonrep.float())+1
 own=prior[:,reps]
 ar=(pi/own.clamp_min(1e-30)).clamp_min(1.)
 ah=((pi-hm)/own.clamp_min(1e-30)).clamp_min(1.)
 cost=torch.stack((torch.zeros_like(pi),torch.ones_like(pi),amount,population[None].expand_as(pi)),-1)
 return dict(nonrep=nonrep,history_valid=has_history,alpha_rep=ar,alpha_history=ah,cost=cost)


def infer_states(ids,labels,population):
 g,a=ids.shape;valid=ids>=0;safe=ids.clamp_min(0).long();counts=torch.zeros(g,len(population),device=ids.device).scatter_add_(1,labels[safe],valid.float())
 return torch.where(counts==0,0,torch.where(counts==1,1,torch.where(counts==population[None],3,2))).long()


def pack(states,ctx,labels,reps,cap):
 g,f=states.shape;n=len(labels);idx=torch.arange(n,device=states.device);rep=idx==reps[labels];state=states[:,labels]
 flags=(state==3)|((state==1)&rep[None])|((state==2)&(ctx['nonrep']|rep[None]))
 ids=torch.full((g,cap),-1,device=states.device,dtype=torch.int32);weights=torch.zeros(g,cap,device=states.device)
 for group in range(g):
  selected=idx[flags[group]];count=len(selected)
  if count>cap:raise ValueError('State assignment exceeds unchanged real-Key budget')
  ids[group,:count]=selected.int();c=labels[selected];s=states[group,c];a=torch.where(s==1,ctx['alpha_rep'][group,c],ctx['alpha_history'][group,c]);weights[group,:count]=torch.where(rep[selected]&((s==1)|(s==2)),a,1.)
 return ids,weights


def _moments(a,values,labels,clusters,mask=None,chunk=4096):
 h,p,n=a.shape;k=values.shape[-1];mass=torch.zeros(h,p,clusters,device=a.device);number=torch.zeros(h,p,clusters,k,device=a.device)
 for start in range(0,n,chunk):
  end=min(start+chunk,n);weight=a[:,:,start:end]
  if mask is not None:weight=weight*mask[None,None,start:end]
  index=labels[start:end];mass.index_add_(2,index,weight)
  number.index_add_(2,index,weight[...,None]*values[:,None,start:end])
 return mass,number


def tables(a,values,labels,reps,population,ctx,group):
 # a[H,P,N] is scaled by the common PATCH+SPECIAL estimated partition.
 f=len(reps);m,n=_moments(a,values,labels,f);hm,hn=_moments(a,values,labels,f,ctx['nonrep'][group])
 mr=a[:,:,reps];nr=mr[...,None]*values[:,None,reps];ar=ctx['alpha_rep'][group][None,None];ah=ctx['alpha_history'][group][None,None]
 masses=torch.stack((torch.zeros_like(m),mr*ar,hm+mr*ah,m),3)
 nums=torch.stack((torch.zeros_like(n),nr*ar[...,None],hn+nr*ah[...,None],n),3)
 return masses,nums


def totals(mass,number,states,sp_mass,sp_number):
 h,p,f,s=mass.shape;index=states[None,None,:,None].expand(h,p,-1,1)
 selected_mass=mass.gather(3,index).squeeze(3).double()
 selected_number=number.gather(3,index[...,None].expand(h,p,f,1,number.shape[-1])).squeeze(3).double()
 return sp_mass.double()+selected_mass.sum(2),sp_number.double()+selected_number.sum(2)


def combine_heads(value,projector=None):
 if projector is None:return value.sum(0)
 shape=value.shape;order=tuple(range(1,value.ndim-1))+(0,value.ndim-1)
 combined=value.permute(order).reshape(*shape[1:-1],shape[0]*shape[-1])
 return torch.nn.functional.linear(combined.float(),projector.float())


def predicted_output(mass,number,states,sp_mass,sp_number,projector=None):
 m,n=totals(mass,number,states,sp_mass,sp_number)
 return combine_heads(n/m.clamp_min(1e-300)[...,None],projector)


def objective(mass,number,states,sp_mass,sp_number,target,projector=None):
 return (predicted_output(mass,number,states,sp_mass,sp_number,projector)-target).square().sum(-1).mean()


def single_change_scores(mass,number,states,sp_mass,sp_number,target,history_valid,projector=None):
 # Exclusive prefix/suffix sums avoid 1 - dominant_mass cancellation.
 h,p,f,s=mass.shape;k=number.shape[-1];index=states[None,None,:,None].expand(h,p,-1,1)
 cm=mass.gather(3,index).squeeze(3).double();cn=number.gather(3,index[...,None].expand(h,p,f,1,k)).squeeze(3).double()
 prefix_m=cm.cumsum(2)-cm;suffix_m=cm.flip(2).cumsum(2).flip(2)-cm
 prefix_n=cn.cumsum(2)-cn;suffix_n=cn.flip(2).cumsum(2).flip(2)-cn
 # Shifted cumsums, rather than subtraction, for exact exclusion of a dominant bin.
 prefix_m=torch.cat((torch.zeros_like(cm[:,:,:1]),cm[:,:,:-1].cumsum(2)),2)
 suffix_m=torch.cat((cm[:,:,1:].flip(2).cumsum(2).flip(2),torch.zeros_like(cm[:,:,:1])),2)
 prefix_n=torch.cat((torch.zeros_like(cn[:,:,:1]),cn[:,:,:-1].cumsum(2)),2)
 suffix_n=torch.cat((cn[:,:,1:].flip(2).cumsum(2).flip(2),torch.zeros_like(cn[:,:,:1])),2)
 other_m=sp_mass.double()[:,:,None]+prefix_m+suffix_m;other_n=sp_number.double()[:,:,None,:]+prefix_n+suffix_n
 result=torch.empty(f,s,device=mass.device)
 for start in range(0,f,256):
  end=min(start+256,f);m=other_m[:,:,start:end,None]+mass[:,:,start:end].double();n=other_n[:,:,start:end,None,:]+number[:,:,start:end].double();y=combine_heads(n/m.clamp_min(1e-300)[...,None],projector)
  error=(y-target[:,None,None]).square().sum(-1).mean(0);result[start:end]=error.float()
 result[:,2]=result[:,2].masked_fill(~history_valid,torch.inf)
 return result


def optimize(mass,number,initial,sp_mass,sp_number,costs,history_valid,cap,passes=2,projector=None):
 from saf3r.triton.reuse_compact import budget
 f=len(initial);exact=torch.full_like(initial,3);target=predicted_output(mass,number,exact,sp_mass,sp_number,projector)
 current=initial.clone();loss=objective(mass,number,current,sp_mass,sp_number,target,projector);initial_loss=float(loss);accepted=0
 # Round0 scores state changes around dense-proxy; later rounds use current config.
 for round_id in range(passes+1):
  base=exact if round_id==0 else current
  scores=single_change_scores(mass,number,base,sp_mass,sp_number,target,history_valid,projector)
  low=scores.amin(-1,keepdim=True);errors=scores-low;finite=errors.masked_fill(~torch.isfinite(errors),0.)
  candidate,total=budget(errors[None].contiguous(),costs[None].contiguous(),finite.amax().reshape(1)+1e-12,cap,16)
  candidate=candidate[0];candidate_loss=objective(mass,number,candidate,sp_mass,sp_number,target,projector)
  if int(total[0])<=cap and candidate_loss<loss:
   current=candidate;loss=candidate_loss;accepted+=1
  elif round_id>0:
   # Feasible single-coordinate improvement is exact for this proxy, not oracle-scored.
   free=cap-int(costs.gather(1,current[:,None]).sum());change=costs-costs.gather(1,current[:,None]);feasible=change<=free
   available=scores.masked_fill(~feasible,torch.inf);flat=int(available.argmin());c,s=flat//4,flat%4
   if available[c,s]<loss:
    trial=current.clone();trial[c]=s;trial_loss=objective(mass,number,trial,sp_mass,sp_number,target,projector)
    if trial_loss<loss:current=trial;loss=trial_loss;accepted+=1
 return current,dict(predicted_initial_error=initial_loss,predicted_final_error=float(loss),accepted_proxy_updates=accepted)


def current_support_estimate(mean_logits,grid,sizes,ids,known_logits,logit_variance=None):
 """Known current logits + exact first-moment-consistent residual mean.

History contributes support identity only; no stale unobserved delta values.
"""
 h,g,p,r=mean_logits.shape;n=len(grid);valid=ids>=0;safe=ids.clamp_min(0).long();regions=grid[safe];index=regions[None,:,None].expand_as(known_logits)
 count=torch.zeros(g,r,device=mean_logits.device).scatter_add_(1,regions,valid.float());remaining=sizes[None]-count
 total=torch.zeros_like(mean_logits).scatter_add_(3,index,known_logits.masked_fill(~valid[None,:,None],0.))
 residual=(sizes[None,None,None]*mean_logits-total)/remaining.clamp_min(1)[None,:,None]
 if logit_variance is not None:
  second=torch.zeros_like(mean_logits).scatter_add_(3,index,known_logits.masked_fill(~valid[None,:,None],0.).square())
  residual_second=(sizes[None,None,None]*(logit_variance+mean_logits.square())-second)/remaining.clamp_min(1)[None,:,None]
  variance=(residual_second-residual.square()).clamp_min(0.)
  residual=residual+.5*variance
 estimated=residual[...,grid].clone()
 for group in range(g):
  selected=safe[group,valid[group]]
  estimated[:,group].scatter_(2,selected[None,None].expand(h,p,-1),known_logits[:,group][:,:,valid[group]])
 return estimated


def diagonal_logit_variance(q,k,grid,sizes,scale):
 h,n,d=k.shape;r=len(sizes)
 mean=torch.zeros(h,r,d,device=k.device).index_add_(1,grid,k.float())/sizes[None,:,None]
 second=torch.zeros_like(mean).index_add_(1,grid,k.float().square())/sizes[None,:,None]
 variance=(second-mean.square()).clamp_min(0.)
 return torch.einsum('hgpd,hrd->hgpr',q.float().square(),variance)*scale**2
