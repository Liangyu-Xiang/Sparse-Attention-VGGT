"""Same relative importance,without unnecessary common row normalization.

Head-wise observation normalization is retained. Four-state losses are linear
in weights and execution compensation uses ratios,so a positive common scale
for a Query group changes neither decisions nor AV compensation mathematically.
"""
import torch
from . import beta_unified_importance as parameters
from .beta_fast_importance import observe,observe_raw,observe_subgroup

def estimate(mean,coarse,previous,ids,history,grid,sizes,layer):
 g,r=coarse.shape;n=len(grid);uniform=coarse[:,grid]/sizes[grid]
 if previous is None:return uniform.contiguous(),torch.zeros_like(coarse)
 valid=ids>=0;safe=ids.clamp_min(0).long();block=grid[safe];tiny=torch.finfo(coarse.dtype).tiny
 beta=(torch.minimum(coarse,previous)/torch.maximum(coarse,previous).clamp_min(tiny)).clamp_min(0).pow(parameters.TAU)
 oldbase=previous.gather(1,block)/sizes[block]
 residual=(history/oldbase.clamp_min(1e-30)).clamp_min(1e-30).log()
 values=uniform.gather(1,safe)*torch.exp(parameters.ALPHA*beta.gather(1,block)*residual)
 index=safe.masked_fill(~valid,n)
 weights=torch.cat((uniform,uniform.new_zeros(g,1)),1).scatter_(1,index,values.masked_fill(~valid,0.))[:,:n]
 return weights.contiguous(),beta
