"""Pure block-only beta history prior: no feature anchors or outer mixing."""
import torch


def prior(current_mass, previous_mass, conditional, grid, sizes):
    if previous_mass is None:
        beta = torch.zeros_like(current_mass)
    else:
        # Separate square roots avoid underflow of tiny probability products.
        beta = 2 * current_mass.sqrt() * previous_mass.sqrt() / (current_mass + previous_mass).clamp_min(1e-30)
        beta = beta.clamp(0., 1.)  # Roundoff guard; no tunable coefficient.
    effective = beta[:, grid] * conditional + (1 - beta[:, grid]) / sizes[grid][None]
    return current_mass[:, grid] * effective, effective, beta


def conditional_mass_update(prior,grid,sizes,ids,raw_selected_logits):
 """Current selected conditional shape at a prior-derived total selected mass.

No absolute exp(logit)/coarse-Z estimate, no anchors or Dense bootstrap.
"""
 valid=ids>=0;g,n=prior.shape;safe=ids.clamp_min(0).long();mass=(prior.gather(1,safe)*valid).sum(1)
 scores=raw_selected_logits.masked_fill(~valid[None,:,None],-torch.inf).clone()
 empty=~valid.any(1)
 if empty.any():scores[:,empty,:,0]=0.
 conditional=scores.softmax(-1).mean((0,2)).masked_fill(~valid,0.)
 observed=conditional*mass[:,None]
 out=torch.cat((prior,torch.zeros(g,1,device=prior.device)),1).scatter_(1,safe.masked_fill(~valid,n),observed)[:,:n]
 regions=len(sizes)
 if n%regions==0:block_mass=out.reshape(g,regions,-1).sum(-1)
 else:block_mass=torch.zeros(g,regions,device=prior.device).scatter_add_(1,grid[None].expand(g,-1),out)
 phi=out/block_mass[:,grid].clamp_min(1e-30);zero=block_mass==0
 phi=torch.where(zero[:,grid],1/sizes[grid][None],phi)
 return dict(posterior=out,conditional=phi,block_mass=block_mass,observed_mass=mass,unobserved_mass=1-mass,
             residual_history_zero_fallback_blocks=torch.zeros(g,device=prior.device),zero_posterior_blocks=zero.sum(1))
