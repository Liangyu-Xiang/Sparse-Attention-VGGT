"""Observed-support relative probabilities,scaled by coarse expected support mass.

Only actual selected raw logits enter softmax;no unknown fine logits or filled
history. Coarse support mass is an explicit approximation,not Dense truth.
"""
import torch
from .one_layer_edge_history import mean_valid
from .minimal_sparse_history import estimate

def observe(mean_logits,sizes,ids,raw,eligible,coarse,grid):
 valid=ids>=0;safe=ids.clamp_min(0).long()
 conditional=mean_valid(raw.softmax(-1),eligible).masked_fill(~valid,0.)
 uniform=coarse[:,grid]/sizes[grid][None]
 support_mass=uniform.gather(1,safe).masked_fill(~valid,0.).sum(1)
 return (conditional*support_mass[:,None]).contiguous()
