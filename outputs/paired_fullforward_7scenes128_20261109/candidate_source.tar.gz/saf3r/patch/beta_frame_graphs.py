"""Execution-only CUDA graphs for fixed-shape local VGGT blocks.

One shared graph pool; every input refreshed, every output cloned before reuse.
Sparse routing, history, budgets and model formulas are untouched.
"""
from types import MethodType
import torch

class FrameGraphs:
 def __init__(self):
  self.pool=torch.cuda.graph_pool_handle();self.inputs=None;self.entries={};self.checks=[];self.hits=0
 def call(self,module,x,pos):
  if module.training or torch.is_grad_enabled():return module._frame_graph_original(x,pos)
  if self.inputs is None:
   self.inputs=(torch.empty_like(x),None if pos is None else torch.empty_like(pos));self.output=torch.empty_like(x)
  sx,sp=self.inputs
  if sx.shape!=x.shape or sx.dtype!=x.dtype or (sp is None)!=(pos is None):raise ValueError('Frame graph shape changed; reinstall required')
  sx.copy_(x)
  if sp is not None:sp.copy_(pos)
  key=id(module)
  if key not in self.entries:
   with torch.autocast('cuda',dtype=torch.get_autocast_dtype('cuda'),enabled=torch.is_autocast_enabled('cuda'),cache_enabled=False):
    reference=module._frame_graph_original(sx,sp)
    graph=torch.cuda.CUDAGraph()
    with torch.cuda.graph(graph,pool=self.pool):
     temporary=module._frame_graph_original(sx,sp);self.output.copy_(temporary);del temporary
    output=self.output
   graph.replay()
   relative=float((output.float()-reference.float()).norm()/reference.float().norm().clamp_min(1e-30))
   maximum=float((output-reference).abs().max())
   if relative>1e-5:raise RuntimeError(f'Local graph mismatch {relative}')
   self.checks.append(dict(block=module._frame_graph_index,relative_L2=relative,max_difference=maximum));self.entries[key]=graph
  else:self.entries[key].replay();self.hits+=1
  return self.output.clone()

def install(model):
 state=FrameGraphs()
 for i,block in enumerate(model.aggregator.frame_blocks):
  block._frame_graph_original=block.forward;block._frame_graph_index=i
  def forward(module,x,pos=None):return state.call(module,x,pos)
  block.forward=MethodType(forward,block)
 model._frame_graphs=state
 return state
