"""Group-mean logit models with two existing Value scalar biases."""
import torch
from .logit_value_bias import bias as base_bias,observe
from .previous_logit_delta import estimate as base_estimate,correction
from .logit_state_loss_models import estimate as cumulant_estimate
from .one_layer_edge_history import mean_valid
VARIANTS=['alpha025','alpha050','alpha075','alpha100']
def bias(z,labels,reps,grid,sizes,layer,variant):
 return base_bias(z,labels,reps,grid,sizes,layer,'value_layer_half')
def estimate(mean,coarse,previous_C,previous_mean,ids,delta,grid,sizes,eligible,variant,key_bias):
 if variant=='baseline':return base_estimate(mean,coarse,previous_C,previous_mean,ids,delta,grid,sizes,eligible,'centered050')
 if variant=='baseline_cumulant':return cumulant_estimate(mean,coarse,previous_C,previous_mean,ids,delta,grid,sizes,eligible,'cumulant050')
 h,g,p,r=mean.shape;n=len(grid);scores=mean[...,grid]+key_bias[None,None,None]
 if delta is not None:
  valid=ids>=0;safe=ids.clamp_min(0).long();block=grid[safe];ix=block[None,:,None].expand(h,-1,p,-1)
  change=correction(delta,ids,grid,mean,previous_mean,torch.zeros_like(coarse),'centered050')*({'alpha025':.25,'alpha050':.5,'alpha075':.75,'alpha100':1.}[variant]/.5)
  if variant.endswith('_cumulant'):
   count=torch.zeros(g,r,device=ids.device).scatter_add_(1,block,valid.float())
   var=torch.zeros_like(mean).scatter_add_(3,ix,change.square().masked_fill(~valid[None,:,None],0.))/count.clamp_min(1)[None,:,None];change=change-.25*var.gather(3,ix)
  updated=mean.gather(3,ix)+key_bias[safe][None,:,None]+change;tomb=safe.masked_fill(~valid,n)[None,:,None].expand(h,-1,p,-1)
  scores=torch.cat((scores,scores.new_zeros(h,g,p,1)),-1).scatter_(3,tomb,updated.masked_fill(~valid[None,:,None],0.))[...,:n]
 return mean_valid(scores.softmax(-1),eligible).contiguous(),torch.zeros_like(coarse)
