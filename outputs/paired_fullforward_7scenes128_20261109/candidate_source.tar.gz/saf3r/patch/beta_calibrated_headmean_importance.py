"""Normalize per-head relative responses before pooling; never align heads."""
import torch


def observe(mean,grid,sizes,ids,raw,coarse):
    raw=raw[:,:,0];mean=mean[:,:,0];kind="calibrated"
    h,g,a=raw.shape;r=len(sizes);n=len(grid);valid=ids>=0;safe=ids.clamp_min(0).long();block=grid[safe]
    index=block[None].expand(h,-1,-1)
    delta=(raw-mean.gather(2,index)).masked_fill(~valid[None],0.)
    if kind=='calibrated':
        count=raw.new_zeros(g,r).scatter_add_(1,block,valid.float())
        average=raw.new_zeros(h,g,r).scatter_add_(2,index,delta)/count.clamp_min(1)[None]
        x=(.5*(delta-average.gather(2,index))).masked_fill(~valid[None],0.)
        variance=raw.new_zeros(h,g,r).scatter_add_(2,index,x.square())/count.clamp_min(1)[None]
        score=x-.25*variance.gather(2,index)
    score=score.masked_fill(~valid[None],-torch.inf)
    missing=n-valid.sum(1)
    denominator=torch.logaddexp(score.logsumexp(-1),missing.clamp_min(1).float().log()[None].masked_fill(missing[None]==0,-torch.inf))
    relative_probability=(score-denominator[...,None]).exp().mean(0).masked_fill(~valid,0.)
    # This is a coarse-gauge importance weight, NOT Dense probability. Uniform
    # relative response is1; only scalar headmean response crosses layers.
    previous_uniform=coarse.gather(1,block)/sizes[block]
    return (n*relative_probability*previous_uniform).masked_fill(~valid,0.).contiguous()


def estimate(mean,coarse,previous,ids,history,grid,sizes):
    g,r=coarse.shape;n=len(grid);uniform=coarse[:,grid]/sizes[grid]
    if previous is None:return uniform.contiguous(),torch.zeros_like(coarse)
    valid=ids>=0;safe=ids.clamp_min(0).long();block=grid[safe]
    tiny=torch.finfo(coarse.dtype).tiny
    beta=(-(coarse.clamp_min(tiny).log()-previous.clamp_min(tiny).log()).abs()).exp()
    b=beta.gather(1,block)
    relative=history/(previous.gather(1,block)/sizes[block]).clamp_min(1e-30)
    lift=((1-b)+b*relative).masked_fill(~valid,0.)
    count=coarse.new_zeros(g,r).scatter_add_(1,block,valid.float())
    effective=sizes[None]-count+coarse.new_zeros(g,r).scatter_add_(1,block,lift)
    mass=(mean[:,:,0]+effective.clamp_min(1e-30).log()[None]).softmax(-1)
    base=(mass/effective.clamp_min(1e-30)[None]).mean(0)
    out=base[:,grid];index=safe.masked_fill(~valid,n)
    prior=torch.cat((out,out.new_zeros(g,1)),1).scatter_(1,index,(base.gather(1,block)*lift).masked_fill(~valid,0.))[:,:n]
    return prior.contiguous(),beta
