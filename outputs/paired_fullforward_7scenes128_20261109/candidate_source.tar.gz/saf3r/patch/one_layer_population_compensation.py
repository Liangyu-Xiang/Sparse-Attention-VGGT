"""Same one-layer history and state losses; population residual AV compensation.

Chosen only from previously saved RGB fixed-support output diagnostics, never
from target pose/reconstruction truth. Exact/nonrepresentative edges keep1.
"""
import torch


def population_weights(ids, labels, reps, population):
    valid=ids>=0;safe=ids.clamp_min(0).long();cluster=labels[safe].long()
    count=torch.zeros((len(ids),len(reps)),device=ids.device,dtype=torch.float32)
    count.scatter_add_(1,cluster,valid.float())
    residual=population[cluster]-count.gather(1,cluster)+1.
    result=torch.where(safe==reps[cluster],residual,1.)
    return result.masked_fill(~valid,0.).contiguous()


def install():
    from . import one_layer_edge_history as base
    from . import reuse_window_graph,current_probe_reuse
    base.install();original_select=reuse_window_graph.select
    def select(state,layer,prior,pi,old_ids,allowed,z,reps,labels,population,geometry,uniform=None,**kwargs):
        # This flag changes only the weight kernel in current_probe_states;
        # probability, losses, gates, dual allocation and packing are identical.
        execution_geometry=dict(geometry,rep_history_execution='population')
        ids,valid,weights,record=original_select(state,layer,prior,pi,old_ids,allowed,z,reps,labels,population,execution_geometry,uniform=uniform,**kwargs)
        if getattr(state,'_population_validate',False):
            expected=population_weights(ids,labels,reps,population)
            if not torch.equal(weights,expected):raise RuntimeError('Population kernel differs from independent packed-support reference')
            state._population_validated_windows=getattr(state,'_population_validated_windows',0)+1
        return ids,valid,weights,record
    def forward(module,x,pos):
        result=base.forward(module,x,pos)
        module.state.records[-1].update(execution_compensation='population_residual',state_selector_compensation_model='unchanged prior_residual state loss',changed_component='AV representative compensation only')
        return result
    reuse_window_graph.select=select;current_probe_reuse.forward=forward
