"""Small algebraic refinements of strictly previous-layer observed logit deltas.
No extra QK,anchors,Key statistics,learned calibration or older historical values.
"""
import math
import torch
from .one_layer_edge_history import mean_valid
from .previous_logit_delta import observe
VARIANTS=['shared050','blend050','partial_mean','positive025','negative025','bounded2','bounded4','mid_center050','mid_shared050','mid_blend050','mid_positive025','mid_partial_mean','band3_16_center050','band3_16_blend050','band3_16_positive025','band3_16_negative025','band3_16_partial_mean','band2_16_center050','band4_16_center050']

def corrected(delta,ids,grid,regions,mode,layer=None):
 h,g,p,a=delta.shape;valid=ids>=0;safe=ids.clamp_min(0).long();block=grid[safe];index=block[None,:,None].expand(h,-1,p,-1)
 count=torch.zeros(g,regions,device=ids.device).scatter_add_(1,block,valid.float())
 total=torch.zeros(h,g,p,regions,device=ids.device).scatter_add_(3,index,delta.masked_fill(~valid[None,:,None],0.))
 m=(total/count.clamp_min(1)[None,:,None]).gather(3,index);x=delta-m
 if mode.startswith('soft_'):
  from .logit_transition_coefficients import COEFFICIENTS
  if mode=='soft_stage':a=.5 if 6<=layer<=17 else COEFFICIENTS['fit_stage_plain_scalar'][layer][0]
  elif mode=='soft_stage025':a=.5 if 6<=layer<=17 else (.25 if layer<6 else .1)
  elif mode=='soft_layer':a=.5 if 6<=layer<=17 else COEFFICIENTS['fit_layer_plain_scalar'][layer][0]
  else:raise ValueError(mode)
  out=a*x
 elif mode.startswith('fit_'):
  from .logit_transition_coefficients import COEFFICIENTS
  a,b=COEFFICIENTS[mode][layer];out=a*x+b*m
 elif mode.startswith('querymean'):out=.5*x.mean(2,keepdim=True).expand_as(x)
 elif mode=='queryblend050':out=.25*x+.25*x.mean(2,keepdim=True)
 elif mode=='bothmean050':out=.5*x.mean((0,2),keepdim=True).expand_as(x)
 elif mode=='bothblend050':out=.25*x+.25*x.mean((0,2),keepdim=True)
 elif mode in ['querylme050','bothlme050']:
  dims=(2,) if mode=='querylme050' else (0,2)
  denominator=math.prod(delta.shape[i] for i in dims)
  pooled=torch.logsumexp(delta,dim=dims,keepdim=True)-math.log(denominator)
  pooled=pooled.expand_as(delta)
  psum=torch.zeros(h,g,p,regions,device=ids.device).scatter_add_(3,index,pooled.masked_fill(~valid[None,:,None],0.))
  pm=(psum/count.clamp_min(1)[None,:,None]).gather(3,index);out=.5*(pooled-pm)
 elif mode=='center050':out=.5*x
 elif mode=='shared050':out=.5*x.mean(0,keepdim=True).expand_as(x)
 elif mode=='blend050':out=.25*x+.25*x.mean(0,keepdim=True)
 elif mode=='partial_mean':out=.5*x+.25*m
 elif mode=='positive025':out=torch.where(x>=0,.25*x,.5*x)
 elif mode=='negative025':out=torch.where(x>=0,.5*x,.25*x)
 elif mode.startswith('bounded'):
  tau=float(mode[7:]);out=.5*x/(1+x.abs()/tau)
 else:raise ValueError(mode)
 return out.masked_fill(~valid[None,:,None],0.)

def estimate(mean,coarse,previous_coarse,previous_mean,ids,delta,grid,sizes,eligible,variant,layer):
 g=len(coarse);n=len(grid)
 # Fixed stage gate based only on layer index;coarse uniform computes no fine QK.
 if variant.startswith('band'):
  prefix,stop,mode=variant.split('_',2);first=int(prefix[4:]);active=first<=layer<=int(stop)
 else:
  mode=variant[4:] if variant.startswith('mid_') else variant;active=not variant.startswith('mid_') or 6<=layer<=17
 if delta is None or not active:
  # Preserve the original estimator's FP32 softmax path,including first layer.
  return mean_valid(mean[...,grid].softmax(-1),eligible).contiguous(),torch.zeros_like(coarse)
 h,_,p,r=mean.shape;valid=ids>=0;safe=ids.clamp_min(0).long()
 change=corrected(delta,ids,grid,r,mode,layer)
 scores=mean[...,grid].clone();values=mean.gather(3,grid[safe][None,:,None].expand(h,-1,p,-1))+change
 tombstone=safe.masked_fill(~valid,n)[None,:,None].expand(h,-1,p,-1)
 scores=torch.cat((scores,scores.new_zeros(h,g,p,1)),-1).scatter_(3,tombstone,values.masked_fill(~valid[None,:,None],0.))[...,:n]
 return mean_valid(scores.softmax(-1),eligible).contiguous(),torch.zeros_like(coarse)
