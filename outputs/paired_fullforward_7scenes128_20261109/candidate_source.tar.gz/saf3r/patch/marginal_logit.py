"""Head-mean marginal logweights,not a transferred sparse-softmax probability."""
import torch
from .previous_logit_delta import correction,observe as raw_observe

def estimate(mean,coarse,previous_C,previous_mean,ids,delta,grid,sizes,eligible,theta,key_bias):
 logweight=coarse[:,grid].clamp_min(1e-30).log()-sizes[grid].log()[None]+key_bias[None]
 if delta is not None:
  # Cache has1 head:actual group-mean raw residual,headaveraged after AV.
  assert delta.shape[0]==delta.shape[2]==1
  centered=correction(delta,ids,grid,mean,previous_mean,torch.zeros_like(coarse),'centered_direct')[0,:,0]
  valid=ids>=0;safe=ids.clamp_min(0).long();n=len(grid);tomb=safe.masked_fill(~valid,n)
  logweight=torch.cat((logweight,logweight.new_zeros(len(ids),1)),1).scatter_add_(1,tomb,(theta[0]*centered).masked_fill(~valid,0.))[:,:n]
 # Rowwise positive scaling leaves state errors/budget and compensation ratios invariant.
 prior=(logweight-logweight.amax(1,keepdim=True)).exp().contiguous()
 return prior,torch.full_like(coarse,float(theta[0]))

def observe(mean,grid,ids,raw,key_bias):
 valid=ids>=0;safe=ids.clamp_min(0).long()
 return (raw_observe(mean,grid,ids,raw).mean(0,keepdim=True)-key_bias[safe][None,:,None]).masked_fill(~valid[None,:,None],0.).contiguous()
