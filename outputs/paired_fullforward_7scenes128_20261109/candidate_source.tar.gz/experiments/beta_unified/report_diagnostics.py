"""Six unavailable task scores for every offline/kernel experiment, with reasons."""
import csv,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'outputs/beta_unified_20261108';KEYS=['auc03','auc30','acc','comp','cd','f1']
def main():
 rows=[]
 for family in ['offline','moment_offline','single_offline']:
  f=OUT/family/'part0';files=list(f.glob('layer*.csv'))
  if not files:continue
  with files[0].open() as file:names=sorted({r['method'] for r in csv.DictReader(file)})
  for name in names:rows.append(dict(run=family+'/'+name,**{k:None for k in KEYS},reason='Offline fixedQKV/AV diagnostic only;pose/recon_unposed not run',dense_speedup=None,speedup_reason='No paired warmed full-forward Dense timing',scope=f'{len(files)}/23 transitions;ScanNet10 fixed trajectory;not a dataset quality run'))
 for family in ['kernel_tune','kernel_tune2','partial_tune']:
  p=OUT/family/'run/kernel_tuning.json'
  if not p.exists():continue
  for i,v in enumerate(json.loads(p.read_text())['rows']):rows.append(dict(run=family+f'/tile{i}',**{k:None for k in KEYS},reason='Kernel-only launch/precision test;no pose/recon_unposed quality',dense_speedup=None,speedup_reason='Kernel timing is not full-forward speedup',scope=str({k:v.get(k) for k in ['bm','bk','warps','stages','median_ms','valid']})))
 for family in ['graph_check','moment_check','profile','profile_candidate','window128','window256','frame_graphs','frame_graphs_retry','single_profile']:
  rows.append(dict(run=family,**{k:None for k in KEYS},reason='Engineering/correctness diagnostic only;not a complete pose/recon_unposed quality run',dense_speedup=None,speedup_reason='No paired full-forward Dense timing',scope='See quality.json,logs,monitor and profile files;failed attempts retain concrete traceback'))
 (OUT/'diagnostic_quality.json').write_text(json.dumps(rows,indent=2))
 with (OUT/'diagnostic_quality.csv').open('w') as file:
  w=csv.DictWriter(file,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 (OUT/'diagnostic_quality.txt').write_text('All six task metrics and Dense speedup are N/A for these diagnostic runs. AUC/F1 fractions;ACC/Comp/CD metres;CD=(ACC+Comp)/2 unsquared. No reconstruction threshold/downsampling or SAF3R profile applies to fixedQKV/kernel-only checks.\n'+'\n'.join(r['run']+' : '+r['reason']+'; '+r['scope'] for r in rows)+'\n')
if __name__=='__main__':main()
