"""Inventory offline and engineering runs without inventing task metrics."""
import csv,json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'outputs/beta_unified_20261108'
KEYS=['auc03','auc30','acc','comp','cd','f1']

def main():
    rows=[]
    excluded={'eth_quality','moment_eth_quality','comp_eth_quality','subgroup_eth_quality',
              'fast_eth_quality','final7_quality','fastvggt','fastvggt_retry','fastvggt_report'}
    for family in sorted(OUT.iterdir()):
        if not family.is_dir() or family.name in excluded:continue
        methods=set()
        for pattern in ['summary.csv','per_stage.csv','part*/layer*.csv']:
            files=list(family.glob(pattern))
            for path in files[:1]:
                for row in csv.DictReader(path.open()):
                    if row.get('method'):methods.add(row['method'])
        failure=[]
        for p in family.rglob('failure.json'):
            failure.append(json.loads(p.read_text()).get('error','See failure traceback'))
        reason='Offline fixed-QKV or engineering diagnostic; pose and recon_unposed were not evaluated'
        if failure:reason+='; failed attempt: '+'; '.join(failure)
        for name in sorted(methods) or ['run']:
            rows.append(dict(run=family.name+'/'+name,**{k:None for k in KEYS},
                complete_quality=False,reason=reason,dense_speedup=None,
                speedup_reason='No paired warmed full-forward Dense timing; kernel times are not end-to-end speedups',
                scope='See original raw per-layer/per-group tables, profile, logs and monitor; not a dataset quality evaluation'))
        for p in family.rglob('kernel_tuning.json'):
            for i,case in enumerate(json.loads(p.read_text()).get('rows',[])):
                rows.append(dict(run=family.name+f'/kernel_tile_{i}',**{k:None for k in KEYS},
                    complete_quality=False,reason='Kernel-only tile timing/correctness check; no pose or recon_unposed evaluation',
                    dense_speedup=None,speedup_reason='Kernel timing is not end-to-end speedup',
                    scope=json.dumps(case,sort_keys=True)))
    # Import-time attempts can fail before the evaluator creates its run folder.
    for family in ['fastvggt','fastvggt_retry','profile']:
        folder=OUT/family
        for p in folder.rglob('*.log'):
            text=p.read_text(errors='replace')
            if 'Traceback (most recent call last)' not in text:continue
            tail=text.splitlines()[-1] if text.splitlines() else 'See log'
            rows.append(dict(run=str(p.relative_to(OUT)),**{k:None for k in KEYS},complete_quality=False,
                reason='Failed attempt before completion: '+tail,dense_speedup=None,
                speedup_reason='Failed run has no paired warmed Dense timing',scope='Failure log retained; successful retry is a separate run'))
    (OUT/'diagnostic_quality.json').write_text(json.dumps(rows,indent=2)+'\n')
    with (OUT/'diagnostic_quality.csv').open('w') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    (OUT/'diagnostic_quality.txt').write_text(
        'Every diagnostic has all six task fields unavailable for a concrete reason. '
        'AUC/F1 fractions; ACC/Comp/CD metres; CD=(ACC+Comp)/2 unsquared. '
        'Reconstruction threshold/downsampling and SAF3R profile do not apply to offline/kernel runs.\n'+
        '\n'.join(f"{r['run']}: all six=N/A; {r['reason']}" for r in rows)+'\n')
    print('Diagnostic inventory:',len(rows))

if __name__=='__main__':main()
