"""Bounded/log and arithmetic history correction;one confidence across layers."""
import math,torch

def estimate(mean,coarse,previous,ids,history,grid,sizes,layer,kind):
 g=coarse.shape[0];n=len(grid);u=coarse[:,grid]/sizes[grid]
 if previous is None:return u.contiguous(),torch.zeros_like(coarse)
 valid=ids>=0;safe=ids.clamp_min(0).long();block=grid[safe];oldbase=previous.gather(1,block)/sizes[block]
 ratio=(history/oldbase.clamp_min(1e-30)).clamp_min(1e-30)
 beta=(torch.minimum(coarse,previous)/torch.maximum(coarse,previous).clamp_min(1e-30)).sqrt()
 b=beta.gather(1,block)
 if kind.startswith('linear'):
  gain=.25 if kind=='linear025' else .5
  lift=1.+gain*b*(ratio-1.)
 else:
  cap=4. if kind=='clip4' else 16.
  lift=torch.exp(b*ratio.log().clamp(-math.log(cap),math.log(cap)))
 values=u.gather(1,safe)*lift
 prior=torch.cat((u,u.new_zeros(g,1)),1).scatter_(1,safe.masked_fill(~valid,n),values.masked_fill(~valid,0.))[:,:n]
 return (prior/prior.sum(1,keepdim=True)).contiguous(),beta
