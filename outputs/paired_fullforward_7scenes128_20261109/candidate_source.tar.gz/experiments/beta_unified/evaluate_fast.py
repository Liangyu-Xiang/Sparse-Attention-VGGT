"""Frozen global-logshrink method: 7Scenes128 pose/reconstruction/full-forward timing."""
import argparse,gc,hashlib,json,sys,time,traceback,types
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT/'external/fastvggt_6526e275'),str(ROOT),str(ROOT/'evaluation')]
# Select repository namespaces without importing optional unrelated models.
m=types.ModuleType('benchmarks');m.__path__=[str(ROOT/'evaluation/benchmarks')];sys.modules['benchmarks']=m
import saf3r
m=types.ModuleType('saf3r.patch');m.__path__=[str(ROOT/'saf3r/patch')];sys.modules['saf3r.patch']=m;saf3r.patch=m
from scripts.quality_metrics import quality_record,quality_markdown

def save(path,value):
 path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(path)

def quality(out,q):
 save(out/'quality.json',q);(out/'quality.md').write_text(quality_markdown(q))

def run(a):
 import numpy as np,torch,yaml,open3d as o3d
 from addict import Dict
 from saf3r.utils.model_utils import build_model
 from saf3r.utils.data_utils import load_images
 from saf3r.models.official_vggt.utils.pose_enc import pose_encoding_to_extri_intri
 from saf3r.patch.reuse_residual_exploration import ReuseExploreConfig,install_reuse_residual_exploration
 from vggt.models.aggregator import Aggregator as FastAggregator
 from benchmarks.da3.bench.registries import MV_REGISTRY
 from benchmarks.da3.da3bench_utils import sample_frames
 from evaluate_da3bench import load_scene_data,evaluate
 out=a.output;out.mkdir(parents=True,exist_ok=False);quality(out,quality_record({},'Run in progress'))
 torch.set_num_threads(2);torch.manual_seed(0);np.random.seed(0);o3d.utility.random.seed(0);torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
 expected=json.loads(a.expected_input.read_text());dataset=MV_REGISTRY.get('7scenes')()
 positions,scene=sample_frames(dataset.get_data(a.scene),a.scene,128,sample_mode='uniform',seed=0)
 assert scene.image_files==expected['image_paths'] and positions==expected['frame_indices']
 cfg=Dict(yaml.safe_load((ROOT/'configs/evaluation/eval_saf3r_vggt.yaml').read_text())['model']);cfg.pop('patch_module');cfg.pop('sparse_config_path');cfg.ckpt_path=expected['checkpoint']
 model=build_model(cfg,'cpu').eval();model.aggregator=FastAggregator(merging=0,merge_ratio=.9,vis_attn_map=False);model.aggregator.register_forward_hook(lambda module,args,result:([f.float() for f in result[0]],result[1]));model.load_state_dict(torch.load(cfg.ckpt_path,map_location='cpu'),strict=True);model=model.cuda().eval();images=load_images(model,'vggt',scene.image_files).cuda()
 for module in model.aggregator.modules():
  if hasattr(module,'patch_width') and hasattr(module,'patch_height'):module.patch_width=images.shape[-1]//14;module.patch_height=images.shape[-2]//14
 assert list(images.shape)==expected['shape'] and len(images)==128
 sha=hashlib.sha256(Path(cfg.ckpt_path).read_bytes()).hexdigest();assert sha==expected['checkpoint_sha256']
 config=dict(upstream_commit='6526e275a29572653a034762bb3c6c9ce280ff55',merging=0,merge_ratio=.9,heads='matched local FP32 heads;feature BF16 toFP32 conversion included in forward',profile='official FastAggregator, native matching/merging/unmerging;no SAF3R')
 save(out/'input.json',expected);save(out/'config.json',config)
 processed_image_sha256=hashlib.sha256(images.cpu().numpy().tobytes()).hexdigest()
 save(out/'status.json',dict(stage='full_forward',scene=a.scene))
 samples=[];raw=None
 for iteration in range(4):
  del raw;raw=None;torch.cuda.synchronize();torch.cuda.reset_peak_memory_stats();begin=time.perf_counter()
  with torch.inference_mode(),torch.autocast('cuda',dtype=torch.bfloat16):raw=model(images)
  torch.cuda.synchronize();samples.append(dict(seconds=time.perf_counter()-begin,peak_allocated_GiB=torch.cuda.max_memory_allocated()/2**30,peak_reserved_GiB=torch.cuda.max_memory_reserved()/2**30))
  print('FORWARD',a.scene,iteration,samples[-1],flush=True)
 assert torch.isfinite(raw['pose_enc']).all() and torch.isfinite(raw['depth']).all()
 ext,intr=pose_encoding_to_extri_intri(raw['pose_enc'],images.shape[-2:])
 pred=Dict(extrinsics=ext.squeeze().float().cpu().numpy(),intrinsics=intr.squeeze().float().cpu().numpy(),depth=raw['depth'].squeeze().float().cpu().numpy(),conf=raw['depth_conf'].squeeze().float().cpu().numpy(),processed_images=raw['images'].squeeze().permute(0,2,3,1).cpu().numpy())
 timing=dict(warmup=1,repeats=3,median_seconds=float(np.median([s['seconds'] for s in samples[1:]])),cold_samples=samples[:1],samples=samples[1:],scope='Complete FastVGGT forward,including native matching/merge/unmerge,feature casts and identical camera/depth/point heads')
 common=dict(processed_image_sha256=processed_image_sha256,changed_component='Official unmodified FastAggregator replaces Dense aggregator; identical checkpoint,heads and preprocessing',method='FastVGGT_merging0_ratio090',scene=a.scene,dataset='7scenes',frames=len(images),input=expected,config=config,timing=timing,quality_protocol=dict(tasks=['pose','recon_unposed'],sampling='uniform',seed=0,f1_threshold_m=dataset.eval_threshold,downsample_m=dataset.down_sample,cd_definition='(ACC+Comp)/2 unsquared metres',reconstruction='unposed',alignment_fusion='Unchanged repository evaluate_da3bench unposed implementation',SAF3R_TopK_profile='N/A:not SAF3R',voxel_length_m=dataset.voxel_length,sdf_trunc_m=dataset.sdf_trunc,mesh_sample_points=dataset.sampling_number,max_depth=dataset.max_depth,AUC_F1_units='fractions',distance_units='metres'),hardware=dict(gpu=torch.cuda.get_device_name(),torch=torch.__version__,cuda=torch.version.cuda,physical_GPU=__import__('os').environ.get('CUDA_VISIBLE_DEVICES')),speedup_vs_dense=None,speedup_reason='Unchanged Dense not rerun; no paired contemporaneous warmed full-forward timing')
 save(out/'forward.json',common)
 del raw;raw=None
 # Numerical/fixed-support RGB checks are separate from quality/timing.
 del model,images,raw;gc.collect();torch.cuda.empty_cache()
 save(out/'status.json',dict(stage='quality',scene=a.scene))
 metrics={};errors={}
 try:
  _,gt=load_scene_data(dataset,'7scenes',a.scene,128,'uniform',seed=0)
  for task in ['pose','recon_unposed']:
   try:
    np.random.seed(0);o3d.utility.random.seed(0);metrics.update(evaluate(dataset,gt,pred,[task]))
   except Exception as exc:errors[task]=f'{type(exc).__name__}: {exc}'
 except Exception as exc:errors['ground_truth']=f'{type(exc).__name__}: {exc}'
 q=quality_record(metrics,'; '.join(f'{k}: {v}' for k,v in errors.items()) or 'Task unavailable')
 if q['complete']:assert abs(q['values']['cd']-(q['values']['acc']+q['values']['comp'])/2)<1e-6
 quality(out,q);save(out/'result.json',dict(common,quality=q,metrics=metrics,quality_errors=errors));save(out/'status.json',dict(stage='complete' if q['complete'] else 'quality_incomplete'))
 print('QUALITY',a.scene,q,flush=True)

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--variant',choices=['centered050'],default='centered050');p.add_argument('--scene',required=True);p.add_argument('--expected-input',type=Path,required=True);p.add_argument('--config',type=Path);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
 try:run(a)
 except BaseException as exc:
  if a.output.exists():quality(a.output,quality_record({},f'{type(exc).__name__}: {exc}'));save(a.output/'failure.json',dict(error=str(exc),traceback=traceback.format_exc()))
  raise
