"""Check common-scale invariance of all four states and AV compensation."""
import sys,json,types
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
import torch,saf3r
m=types.ModuleType('saf3r.patch');m.__path__=[str(ROOT/'saf3r/patch')];sys.modules['saf3r.patch']=m;saf3r.patch=m
from saf3r.patch.beta_weight_importance import estimate
from saf3r.patch.beta_unified_importance import estimate as normalized
from saf3r.patch.history_transfer_states import select
from experiments.beta_unified.moment_cache import cache
from scripts.quality_metrics import quality_record
out=ROOT/'outputs/beta_unified_20261108/weight_scale_check';out.mkdir(exist_ok=True);rows=[];torch.set_num_threads(2);torch.backends.cuda.matmul.allow_tf32=False
with torch.inference_mode():
 for layer in [1,12,22]:
  a=torch.load(ROOT/f'outputs/logit_transfer_failure_20261108/capture/layer{layer:02d}.pt',mmap=True,weights_only=True);prev=torch.load(ROOT/f'outputs/logit_transfer_failure_20261108/capture/layer{layer-1:02d}.pt',mmap=True,weights_only=True)
  grid=a['grid'].cuda();sizes=a['sizes'].cuda();old=a['source_old'].cuda();observed=cache(prev);args=(a['source_mean'].cuda(),a['source_coarse'].cuda(),prev['source_coarse'].cuda(),old,observed,grid,sizes,layer)
  weights,b=estimate(*args);prior,b2=normalized(*args);torch.testing.assert_close(weights/weights.sum(1,keepdim=True),prior,rtol=1e-6,atol=1e-8);torch.testing.assert_close(b,b2)
  g,n=prior.shape;labels=a['labels'].cuda();reps=a['reps'].cuda();pop=a['population'].cuda();f=len(reps);geo=dict(probe_member_width=a['members'].shape[1],members=a['members'].cuda(),norm2=a['norm2'].cuda(),rep_distance=a['rep_distance'].cuda());allowed=torch.ones(g,1,device='cuda',dtype=torch.bool);z=torch.empty(n,0,device='cuda')
  reference=select(prior,torch.empty(g,f,device='cuda'),old,allowed,z,reps,labels,pop,geo,a['patch_cap'],16);got=select(weights,torch.empty(g,f,device='cuda'),old,allowed,z,reps,labels,pop,geo,a['patch_cap'],16)
  assert torch.equal(reference[0],got[0]),f'Common-scale mask mismatch atlayer{layer}'
  torch.testing.assert_close(got[2],reference[2],rtol=5e-5,atol=5e-6)
  rows.append(dict(layer=layer,ids_identical=True,max_compensation_difference=float((got[2]-reference[2]).abs().max()),row_sum_min=float(weights.sum(1).min()),row_sum_max=float(weights.sum(1).max())))
  print(rows[-1],flush=True)
(out/'result.json').write_text(json.dumps(dict(complete=True,checks=rows,quality=quality_record({},'Fixed-QKV invariance diagnostic;no pose/recon_unposed or paired Dense full-forward timings')),indent=2))
