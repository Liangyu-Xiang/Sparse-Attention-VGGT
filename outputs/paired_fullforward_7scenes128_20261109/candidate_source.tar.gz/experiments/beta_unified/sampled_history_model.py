"""Four existing rows, coarse keys only; per-head/query normalization then mean."""
import torch

def observation(a):
 q=a['q_full'].cuda();h,g,queries,d=q.shape;k=a['k'].cuda();patch=a['patches'].cuda();grid=a['grid'].cuda();sizes=a['sizes'].cuda();mask=a['query_valid'].cuda();r=len(sizes);n=k.shape[1]
 offsets=torch.tensor([32,96,160,224],device='cuda');base=torch.arange(g,device='cuda')[:,None]*256;globalpos=(base+offsets[None]).clamp_max(n-1);pos=globalpos-base
 bad=~mask.gather(1,pos);globalpos=torch.where(bad,(globalpos+5).clamp_max(n-1),globalpos);pos=globalpos-base
 eligible=torch.ones_like(pos,dtype=torch.bool);eligible[:,1:]=pos[:,1:]!=pos[:,:-1];assert mask.gather(1,pos).all()
 qp=q[:,torch.arange(g,device='cuda')[:,None],pos].float()
 mean=a['source_mean'].cuda();coarse=a['source_coarse'].cuda()
 ids=a['source_ids'].cuda();valid=ids>=0;safe=ids.clamp_min(0).long();raw=torch.einsum('hgpd,hgad->hgpa',qp,k[:,patch[safe]].float())*a['scale']
 block=grid[safe];count=mean.new_zeros(g,r).scatter_add_(1,block,valid.float());missing=(sizes[None]-count).clamp_min(0)
 unknown=(mean+missing.clamp_min(1).log()[None,:,None]).masked_fill(missing[None,:,None]==0,-torch.inf).logsumexp(-1)
 observed=raw.masked_fill(~valid[None,:,None],-torch.inf);den=torch.logaddexp(observed.logsumexp(-1),unknown)
 hp=(observed-den[...,None]).exp().mean(0)
 cache=(hp*eligible[:,:,None]).sum(1)/eligible.sum(1)[:,None]
 return dict(mean=mean,coarse=coarse.contiguous(),cache=cache.contiguous())
