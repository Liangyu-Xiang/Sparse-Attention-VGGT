"""Headmean mixtures onexistingfixedQKV;separate mask andcompensation effects."""
import sys,json,time,argparse,types
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
import torch,numpy as np,pandas as pd,saf3r
m=types.ModuleType('saf3r.patch');m.__path__=[str(ROOT/'saf3r/patch')];sys.modules['saf3r.patch']=m;saf3r.patch=m
from experiments.head_mean_history.models import cache_importance,mix,candidate
from experiments.beta_unified.model import estimate
from experiments.transfer_refine.selector import select_capture
from experiments.history_rank_diagnostic.metrics import compare,stage,top_indices
from saf3r.patch.rep_history_prior_weights import reference as prior_weights
from saf3r.triton.group_mean_logit_attention import attention
SOURCE=ROOT/'outputs/logit_transfer_failure_20261108';OUT=ROOT/'outputs/beta_unified_20261108/offline'
CONFIDENCE=['stage','0.25_0.5','0.5_0.5','0.75_0.5','0.5_1.0','0.5_2.0','0.75_1.0','1.0_0.5']
SPEC=[(x,'global') for x in CONFIDENCE]
NAMES=['C0_cumulant','O0_true_probability','U0_uniform']+['unified_'+x for x in CONFIDENCE]

def main(part):
 torch.set_num_threads(2);torch.backends.cuda.matmul.allow_tf32=False;dest=OUT/f'part{part}';dest.mkdir(exist_ok=False);start=time.monotonic();done=[]
 for layer in range(1,24):
  if (layer-1)%1!=part:continue
  a=torch.load(SOURCE/'capture'/f'layer{layer:02d}.pt',mmap=True,weights_only=True);prev=torch.load(SOURCE/'capture'/f'layer{layer-1:02d}.pt',mmap=True,weights_only=True)
  f=np.load(SOURCE/'features'/f'layer{layer:02d}.npz');pf=np.load(SOURCE/'features'/f'layer{layer-1:02d}.npz');ptrue=torch.from_numpy(f['P_head'].mean(0)).cuda();p_prev=torch.from_numpy(pf['P_head'].mean(0)).cuda()
  old=a['source_old'].cuda();validold=old>=0;safeold=old.clamp_min(0).long();grid=a['grid'].cuda();sizes=a['sizes'].cuda();coarse=a['source_coarse'].cuda();q=(coarse[:,grid]/sizes[grid]).contiguous();g,n=q.shape
  assert torch.equal(old,prev['source_ids'].cuda())
  cached=np.load(ROOT/f'outputs/beta_refine_20261108/part{(layer-1)%3}/raw{layer:02d}.npz');cache=torch.from_numpy(cached['history_complement']).cuda()
  estimate.layer=layer
  priors=[a['source_prior'].cuda(),ptrue,q]+[estimate(a['source_mean'].cuda()[:,:,0],coarse,prev['source_coarse'].cuda(),old,cache,grid,sizes,confidence,norm) for confidence,norm in SPEC]
  assert all(torch.isfinite(p).all() and (p>=0).all() and (p.sum(1)>0).all() for p in priors)
  legacy=np.load(SOURCE/f'part{(layer-1)%3}'/f'E_raw_layer{layer:02d}.npz');legacy_rows=pd.read_csv(SOURCE/f'part{(layer-1)%3}'/f'E_layer{layer:02d}.csv')
  labels=a['labels'].cuda();reps=a['reps'].cuda();pop=a['population'].cuda();geo=dict(probe_member_width=a['members'].shape[1],members=a['members'].cuda(),norm2=a['norm2'].cuda(),rep_distance=a['rep_distance'].cuda());cap=a['patch_cap'];F=len(reps)
  def mask(ids):
   valid=ids>=0;return torch.zeros(g,n+1,device='cuda',dtype=torch.bool).scatter_(1,ids.masked_fill(~valid,n).long(),valid)[:,:n]
  def population_weights(ids,states,support):
   valid=ids>=0;safe=ids.clamp_min(0).long();cl=labels[safe];sel=states.gather(1,cl);rep=reps[cl];count=torch.zeros(g,F,device='cuda').scatter_add_(1,labels[None].expand(g,-1),support.float()).gather(1,cl)
   return torch.where(valid,torch.where(sel==1,pop[cl],torch.where((sel==5)&(safe==rep),pop[cl]-count+1.,1.)),0.)
  def comp(ch,prior):
   pi=torch.zeros(g,F,device='cuda').scatter_add_(1,labels[None].expand(g,-1),prior)
   w=prior_weights(ch['ids'],labels,reps,ch['selected'],prior,pi,ch['support'])
   return (ch['population']*w).sqrt()
  selected=[];cached_indices={0:0,1:4,2:9}
  previous_raw=np.load(ROOT/f'outputs/head_mean_history_20261108/part{(layer-1)%3}/raw{layer:02d}.npz')
  previous_rows=pd.read_csv(ROOT/f'outputs/head_mean_history_20261108/part{(layer-1)%3}/layer{layer:02d}.csv')
  previous_names=previous_raw['methods']
  for mi,p in enumerate(priors):
   if mi in cached_indices:ch=dict(ids=torch.from_numpy(previous_raw['ids'][cached_indices[mi]]).cuda(),selected=torch.from_numpy(previous_raw['states'][cached_indices[mi]]).cuda())
   else:ch=select_capture(p,old,reps,labels,pop,geo,cap)
   ch['support']=mask(ch['ids']);ch['population']=population_weights(ch['ids'],ch['selected'],ch['support']);selected.append(ch)
  qb=a['q_full'].cuda();h,_,queries,d=qb.shape;qb=qb.reshape(h,g*queries,d).contiguous();k=a['k'].cuda();v=a['v'].cuda();qm=a['query_valid'].cuda();counts=qm.sum(1).float();special=a['specials'].cuda().int();patch=a['patches'].cuda()
  from torch.nn.attention import sdpa_kernel,SDPBackend
  with sdpa_kernel(SDPBackend.FLASH_ATTENTION):dense=torch.nn.functional.scaled_dot_product_attention(qb[None],k[None],v[None],scale=a['scale'])[0]
  dense=dense.float().reshape(h,g,queries,d);wo=a['projection_weight'].cuda().float();bias=None if a['projection_bias'] is None else a['projection_bias'].cuda().float()
  def project(o):return torch.nn.functional.linear(o.permute(1,2,0,3).reshape(g,queries,-1),wo,bias)
  target=project(dense);den=(target.square()*qm[...,None]).sum((1,2))
  assert np.allclose(den.cpu().numpy(),legacy_rows[legacy_rows.method=='E3_cumulant050'].sort_values('query_group').dense_output_squared.to_numpy(),rtol=1e-6)
  def output(ch,w):
   ids=ch['ids'];actual=patch[ids.clamp_min(0)].masked_fill(ids<0,-1).int().contiguous();o,_=attention(qb,k,v,actual,special,w,a['scale'],qm.reshape(-1),counts,False,4,1)
   error=((project(o.float().reshape(h,g,queries,d))-target).square()*qm[...,None]).sum((1,2));return error
  base=selected[0];rows=[];blockrows=[];a_rows=[];fulls=[];maskonly=[];componly=[];weights=[]
  for mi,(name,p,ch) in enumerate(zip(NAMES,priors,selected)):
   w=comp(ch,p);weights.append(w)
   if mi in cached_indices:
    values=previous_rows[previous_rows.method==previous_names[cached_indices[mi]]].sort_values('query_group')
    full=torch.tensor(values.output_full.to_numpy()**2,device='cuda')*den
    mo=torch.tensor(values.output_mask_only.to_numpy()**2,device='cuda')*den
    co=torch.tensor(values.output_comp_only.to_numpy()**2,device='cuda')*den
   else:
    full=output(ch,w);mo=output(ch,comp(ch,priors[0]));co=output(base,comp(base,p))
   cc=output(ch,comp(ch,q)) if mi>=3 else torch.full_like(full,float("nan"))
   fulls.append(full);maskonly.append(mo);componly.append(co)
   rawpn=p.cpu().numpy();pn=rawpn/rawpn.sum(1,keepdims=True);tn=ptrue.cpu().numpy();oldnp=old.cpu().numpy();cn=coarse.cpu().numpy();gridnp=grid.cpu().numpy();sf=ch['support'];state_at_key=ch['selected'][:,labels]
   for group in range(g):
    s=oldnp[group];s=s[s>=0].astype(int);u=np.ones(n,bool);u[s]=False;pg=pn[group].astype(float);tg=tn[group].astype(float)
    rr=compare(pg[s],tg[s],s);rr['historical_spearman']=rr.pop('spearman');rr['historical_kendall']=rr.pop('kendall_tau_b')
    ix=top_indices(tg[s],.1,s);is_kept=sf[group,s].cpu().numpy();true_mass=tg[s].sum();old_top=top_indices(p_prev[group,s].cpu().numpy(),.1,s)
    row=dict(output_coarse_comp=float((cc[group]/den[group]).sqrt()),coarse_comp_error_squared=float(cc[group]),raw_weight_sum=float(rawpn[group].sum()),raw_historical_mass=float(rawpn[group,s].sum()),raw_global_L1=float(abs(rawpn[group]-tg).sum()),layer=layer,stage=stage(layer),method=name,query_group=group,**rr,global_TV=float(.5*np.abs(pg-tg).sum()),known_L1=float(np.abs(pg[s]-tg[s]).sum()),unknown_L1=float(np.abs(pg[u]-tg[u]).sum()),output_full=float((full[group]/den[group]).sqrt()),output_mask_only=float((mo[group]/den[group]).sqrt()),output_comp_only=float((co[group]/den[group]).sqrt()),dense_output_squared=float(den[group]),output_error_squared=float(full[group]),selected_keys=int(sf[group].sum()),selected_true_mass=float((ptrue[group]*sf[group]).sum()),mask_jaccard_vs_trueP=float((sf[group]&selected[1]['support'][group]).sum()/(sf[group]|selected[1]['support'][group]).sum().clamp_min(1)),mask_jaccard_vs_cumulant=float((sf[group]&base['support'][group]).sum()/(sf[group]|base['support'][group]).sum().clamp_min(1)),historical_reused_key_fraction=float(is_kept.mean()),historical_reused_true_mass_fraction=float(tg[s][is_kept].sum()/true_mass),true_top10_history_reused_fraction=float(is_kept[ix].mean()),true_top10_history_reused_mass_fraction=float(tg[s[ix]][is_kept[ix]].sum()/tg[s[ix]].sum()),previous_top10_history_reused_current_mass=float(tg[s[old_top]][is_kept[old_top]].sum()/true_mass))
    stable=np.intersect1d(ix,old_top);stable_keys=s[stable]
    row.update(stable_top10_count=len(stable),stable_top10_underestimated_factor2=float((pg[stable_keys]<.5*tg[stable_keys]).mean()) if len(stable) else np.nan,stable_top10_selected_mass_fraction=float(tg[stable_keys][is_kept[stable]].sum()/tg[stable_keys].sum()) if len(stable) else np.nan,stable_top10_pred_true_median_ratio=float(np.median(pg[stable_keys]/tg[stable_keys])) if len(stable) else np.nan)
    for code in [0,1,5,10]:row[f'state_{code}_fraction']=float((ch['selected'][group]==code).float().mean())
    row['history_state_selected_edge_count']=int((sf[group]&(state_at_key[group]==5)).sum())
    for block in range(len(a['sizes'])):
     sb=s[gridnp[s]==block];ub=np.flatnonzero((gridnp==block)&u)
     if len(sb) and len(ub):blockrows.append(dict(layer=layer,method=name,query_group=group,key_group=block,known_count=len(sb),unknown_count=len(ub),pred_S=float(pg[sb].sum()),true_S=float(tg[sb].sum()),pred_U=float(pg[ub].sum()),true_U=float(tg[ub].sum()),pred_H_U_ratio=float(pg[sb].sum()/max(pg[ub].sum(),1e-30)),true_H_U_ratio=float(tg[sb].sum()/max(tg[ub].sum(),1e-30)),true_H_above_U_wrong_below_U_fraction=float((pg[sb[tg[sb]>tg[ub].mean()]]<=pg[ub].mean()).mean()) if (tg[sb]>tg[ub].mean()).any() else np.nan))
    rows.append(row)
  pd.DataFrame(rows).to_csv(dest/f'layer{layer:02d}.csv',index=False);pd.DataFrame(blockrows).to_csv(dest/f'blocks{layer:02d}.csv',index=False)
  np.savez_compressed(dest/f'raw{layer:02d}.npz',methods=np.array(NAMES),priors=torch.stack(priors).cpu().numpy(),ids=torch.stack([x['ids'] for x in selected]).cpu().numpy(),states=torch.stack([x['selected'] for x in selected]).cpu().numpy(),weights=torch.stack(weights).cpu().numpy(),previous_ids=old.cpu().numpy(),previous_headmean_cache=cache.cpu().numpy())
  done.append(layer);print('HEADMEAN_DONE',part,layer,flush=True)
 (dest/'complete.json').write_text(json.dumps(dict(complete=True,layers=done,wall_seconds=time.monotonic()-start,peak_GiB=torch.cuda.max_memory_allocated()/2**30),indent=2)+'\n')

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--part',type=int,required=True);a=p.parse_args()
 with torch.inference_mode():main(a.part)
