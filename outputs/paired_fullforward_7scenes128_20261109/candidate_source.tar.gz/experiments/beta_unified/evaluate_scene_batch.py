"""ETH3D variants share immutable model parameters,never history or fine state."""
import argparse,dataclasses,importlib,json,sys,types
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT),str(ROOT/'evaluation')]
m=types.ModuleType('benchmarks');m.__path__=[str(ROOT/'evaluation/benchmarks')];sys.modules['benchmarks']=m
import saf3r
m=types.ModuleType('saf3r.patch');m.__path__=[str(ROOT/'saf3r/patch')];sys.modules['saf3r.patch']=m;saf3r.patch=m

def main(a):
 spec=json.loads(a.spec.read_text());names=list(spec['candidates']);modules={name:importlib.import_module('experiments.beta_unified.evaluate_'+spec['candidates'][name]['engine']+'_eth') for name in names}
 from saf3r.utils import model_utils
 import saf3r.patch.reuse_residual_exploration as reuse
 original_build=model_utils.build_model;original_install=reuse.install_reuse_residual_exploration;cached={}
 def build(cfg,device):
  signature=json.dumps(dict(cfg),sort_keys=True)
  if not cached:
   cached['model']=original_build(cfg,device);cached['signature']=signature
  assert signature==cached['signature']
  return cached['model']
 def install(model,config):
  if hasattr(model,'reuse_explore_state'):
   state=model.reuse_explore_state;state.config=config;return state
  return original_install(model,config)
 model_utils.build_model=build;reuse.install_reuse_residual_exploration=install
 # Alternate order by scene without using quality truth.
 if spec['scenes'].index(a.scene)%2:names.reverse()
 snapshots=[];versions=None
 for name in names:
  c=spec['candidates'][name];args=argparse.Namespace(scene=a.scene,expected_input=a.expected_input,config=a.root/name/'config.json',output=a.root/name/'runs'/a.scene,alpha=c['alpha'],tau=c['tau'])
  print('BEGIN_VARIANT',a.scene,name,flush=True);modules[name].run(args)
  model=cached['model'];current=tuple(p._version for p in model.parameters())
  if versions is None:versions=current
  else:assert versions==current,'Model parameters mutated between methods'
  for path in [args.output/'forward.json',args.output/'result.json']:
   d=json.loads(path.read_text());d['execution_batch']=dict(shared_checkpoint_model=True,parameter_versions_unchanged=True,all_history_and_clustering_reset_every_forward=True,variant_order=names,common_scene=a.scene,cold_note='Shared process compiler/allocator/graph caches;warmed3 full-forward medians remain measured independently');path.write_text(json.dumps(d,indent=2))
  layers=json.loads((args.output/'layers.json').read_text());assert len(layers)==24 and layers[0]['history_source_layer']==-1
  snapshots.append(dict(method=name,complete=json.loads((args.output/'result.json').read_text())['quality']['complete']))
 (a.root/'batches'/f'{a.scene}.json').write_text(json.dumps(dict(complete=all(x['complete'] for x in snapshots),runs=snapshots,variant_order=names),indent=2))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--spec',type=Path,required=True);p.add_argument('--scene',required=True);p.add_argument('--expected-input',type=Path,required=True);a=p.parse_args();main(a)
