"""Diagnostic reconstruction of inline arithmetic-exp QK observation, actual IDs only."""
import torch

def cache(a):
 q=a['q_full'].cuda();h,g,queries,d=q.shape;k=a['k'].cuda();ids=a['source_ids'].cuda();patch=a['patches'].cuda();mask=a['query_valid'].cuda();mean=a['source_mean'].cuda()[:,:,0];grid=a['grid'].cuda();sizes=a['sizes'].cuda();scale=a['scale']
 valid=ids>=0;safe=ids.clamp_min(0).long();block=grid[safe];count=mean.new_zeros(g,len(sizes)).scatter_add_(1,block,valid.float());missing=(sizes[None]-count).clamp_min(0)
 shift=(mean+sizes.log()[None,None]).logsumexp(-1);result=[]
 for begin in range(0,g,4):
  end=min(g,begin+4);sel=k[:,patch[safe[begin:end]]];z=torch.einsum('hgqd,hgad->hgqa',q[:,begin:end].float(),sel.float())*scale
  weights=(z-shift[:,begin:end,None,None]).exp().masked_fill(~mask[None,begin:end,:,None],0.).sum(2)/mask[begin:end].sum(1)[None,:,None]
  weights=weights.masked_fill(~valid[None,begin:end],0.)
  unknown=((mean[:,begin:end]-shift[:,begin:end,None]).exp()*missing[None,begin:end]).sum(-1)
  result.append((weights/(weights.sum(-1)+unknown)[...,None]).mean(0))
 return torch.cat(result).contiguous()
