"""Complete six-metric per-scene and macro report; partial macros are forbidden."""
import argparse,csv,json,statistics
from pathlib import Path
KEYS=['auc03','auc30','acc','comp','cd','f1']
def csvfile(path,rows):
 if not rows:return
 with path.open('w') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def main():
 p=argparse.ArgumentParser();p.add_argument('root',type=Path);a=p.parse_args();root=a.root;spec=json.loads((root/'frozen_spec.json').read_text());rows=[];macro=[];runtime=[];complete=[]
 for name in spec['candidates']:
  per=[];times=[]
  for scene in spec['scenes']:
   path=root/name/'runs'/scene/'result.json'
   if not path.exists():continue
   d=json.loads(path.read_text());assert d['quality']['complete'],str(path);q=d['quality']['values'];assert abs(q['cd']-(q['acc']+q['comp'])/2)<1e-6
   row=dict(method=name,scene=scene,**{k:q[k] for k in KEYS});rows.append(row);per.append(row)
   t=d['timing'];times.append(dict(method=name,scene=scene,seconds=t['median_seconds'],warm_peak_GiB=max(x['peak_allocated_GiB'] for x in t['samples']),cold_peak_GiB=max(x['peak_allocated_GiB'] for x in t['cold_samples']),speedup_vs_Dense='N/A',reason='No paired Dense timing;unchanged control not rerun'))
  if len(per)==len(spec['scenes']):
   macro.append(dict(method=name,scene_count=len(per),**{k:statistics.mean(x[k] for x in per) for k in KEYS}));runtime.append(dict(method=name,scene_count=len(per),seconds=statistics.mean(x['seconds'] for x in times),warm_peak_GiB=max(x['warm_peak_GiB'] for x in times),cold_peak_GiB=max(x['cold_peak_GiB'] for x in times),speedup_vs_Dense='N/A',reason='No paired Dense timing;unchanged control not rerun'));complete.append(name)
  csvfile(root/name/'runtime_per_scene.csv',times)
 csvfile(root/'quality_per_scene.csv',rows);csvfile(root/'quality_macro.csv',macro);csvfile(root/'runtime_macro.csv',runtime)
 def fmt(r):return f"{r['method']} | {r.get('scene','macro')} | {r['auc03']*100:.2f}% | {r['auc30']*100:.2f}% | {r['acc']:.5f} | {r['comp']:.5f} | {r['cd']:.5f} | {r['f1']*100:.2f}%"
 lines=['Local matched quality;AUC/F1 percentages in table, fractions in rawCSV;distances metres;CD=(ACC+Comp)/2 unsquared.','method | scene | AUC@3 | AUC@30 | ACC | Comp | CD | F1',*[fmt(x) for x in macro],'','Per scene:',*[fmt(x) for x in rows],'','Complete methods:'+str(complete),'Pending methods:'+str(set(spec['candidates'])-set(complete)),'Runtime: 1 cold+3warm,median per scene then equal-scene mean;full forward,not CPUquality or image/model load.',*[str(x) for x in runtime],'Dense-relative speedup N/A:no paired Dense timing;unchanged controls not rerun.','SAF3R Top-K/profile:N/A,not SAF3R. Value clustering and four-state optimizer unchanged;declared config overrides recorded in frozen_spec.json.','All method selection uses fixedQKV and ETH3D;7Scenes test truth never used for tuning.']
 (root/'report.txt').write_text('\n'.join(lines)+'\n');print('\n'.join(lines[:2+len(macro)]));print('Completed',len(rows),'scene-method evaluations')
if __name__=='__main__':main()
