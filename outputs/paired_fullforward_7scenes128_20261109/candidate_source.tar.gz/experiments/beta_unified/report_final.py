"""Compare one frozen7Scenes candidate with reused complete local controls."""
import csv,hashlib,json,statistics,tarfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'outputs/beta_unified_20261108'
KEYS=['auc03','auc30','acc','comp','cd','f1']
SCENES=['chess','fire','heads','office','pumpkin','redkitchen','stairs']

def readcsv(p):return list(csv.DictReader(p.open()))
def writecsv(p,rows):
    with p.open('w') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def main():
    final=OUT/'final7_quality';spec=json.loads((final/'frozen_spec.json').read_text())
    name=next(iter(spec['candidates']));runs=[];audit=[];layers=[]
    fast=json.loads((OUT/'fastvggt_report/raw_results.json').read_text())
    fast_by_scene={d['scene']:d for d in fast}
    for scene in SCENES:
        folder=final/name/'runs'/scene;d=json.loads((folder/'result.json').read_text())
        assert d['quality']['complete'] and d['frames']==128
        reference=fast_by_scene[scene]
        assert d['input']==reference['input']
        image=json.loads((folder/'processed_image.json').read_text())['sha256']
        assert image==reference['processed_image_sha256']
        assert d['quality_protocol']['f1_threshold_m']==.05
        assert d['quality_protocol']['downsample_m']==.0078125
        audit.append(dict(scene=scene,input_identical_to_FastVGGT=True,processed_pixels_identical=True,
                          checkpoint_sha256=d['input']['checkpoint_sha256'],processed_sha256=image))
        runs.append(d)
        for l in json.loads((folder/'layers.json').read_text()):
            f=l['fine_clusters']
            row=dict(scene=scene,layer=l['layer'],query_groups=l['query_groups'],fine_clusters=f,
                     beta=l['beta_mean'],beta_mass_weighted=l['beta_mass_weighted_mean'],
                     selected_edge_density=l['actual_unique_density'])
            for state,label in [(0,'drop'),(1,'rep'),(5,'history'),(10,'exact')]:
                row[label+'_cluster_fraction']=l[f'state_{state}_clusters_mean']/f
            assert abs(sum(row[k+'_cluster_fraction'] for k in ['drop','rep','history','exact'])-1)<1e-5
            layers.append(row)
    q=dict(method=name,scene_count=7,**{k:statistics.mean(d['quality']['values'][k] for d in runs) for k in KEYS})
    rows=[q]
    control=ROOT/'outputs/saf3r_dino_top128_7scenes128_20261108'
    for row in readcsv(control/'quality_macro.csv'):
        rows.append(dict(method=row['method'],scene_count=7,**{k:float(row[k]) for k in KEYS}))
    f=readcsv(OUT/'fastvggt_report/macro.csv')[0]
    rows.append(dict(method='FastVGGT_native_ratio090',scene_count=7,**{k:float(f[k]) for k in KEYS}))
    timings=[dict(method=name,seconds=statistics.mean(d['timing']['median_seconds'] for d in runs),
                  warm_peak_GiB=max(s['peak_allocated_GiB'] for d in runs for s in d['timing']['samples']),
                  batch='final7_quality frozen candidate',paired_dense_speedup=None)]
    for t in readcsv(control/'runtime_macro.csv'):
        timings.append(dict(method=t['method'],seconds=float(t['mean_scene_warmed_median_seconds']),
                            warm_peak_GiB=float(t['max_warm_peak_allocated_GiB']),
                            batch='Historical/reused control; see original batch artifact',paired_dense_speedup=None))
    timings.append(dict(method='FastVGGT_native_ratio090',seconds=float(f['seconds']),warm_peak_GiB=float(f['peak_warm_GiB']),
                        batch='FastVGGT explicit requested evaluation 20261108; separate batch',paired_dense_speedup=None))
    gates={}
    for row in rows[1:]:
        by_metric={k:(q[k]<=row[k] if k in ['acc','comp','cd'] else q[k]>=row[k]) for k in KEYS}
        gates[row['method']]=dict(per_metric=by_metric,all_six_pass=all(by_metric.values()),
                                  difference_new_minus_control={k:q[k]-row[k] for k in KEYS})
    report=OUT/'final_report';report.mkdir(exist_ok=True)
    writecsv(report/'quality_macro.csv',rows);writecsv(report/'runtime_macro.csv',timings)
    writecsv(report/'layer_state_selection_per_scene.csv',layers)
    grouped=[]
    for i in range(24):
        ll=[l for l in layers if l['layer']==i]
        grouped.append(dict(layer=i,scene_count=7,**{k:statistics.mean(l[k] for l in ll) for k in ll[0] if k not in ['scene','layer','query_groups','fine_clusters']}))
    writecsv(report/'layer_state_selection_macro.csv',grouped)
    writecsv(report/'quality_per_scene.csv',[dict(method=name,scene=d['scene'],**d['quality']['values']) for d in runs])
    (report/'matched_input_audit.json').write_text(json.dumps(audit,indent=2))
    (report/'quality_gates.json').write_text(json.dumps(gates,indent=2))
    (report/'raw_candidate_results.json').write_text(json.dumps(runs,indent=2))
    def fmt(r):return f"{r['method']} | {r['auc03']*100:.2f}% | {r['auc30']*100:.2f}% | {r['acc']:.5f} | {r['comp']:.5f} | {r['cd']:.5f} | {r['f1']*100:.2f}%"
    lines=['Local measured/reused7Scenes,all7scenes x128frames,equal-scene macro.',
        'AUC/F1 percentages in table,fractions in CSV. ACC/Comp/CD metres,CD=(ACC+Comp)/2 unsquared.',
        'method | AUC@3 | AUC@30 | ACC | Comp | CD | F1',*[fmt(r) for r in rows],
        '', 'Runtime:1cold+3warm synchronized full forwards; mean of per-scene warmed medians. Includes reset,clustering,routing,history,reordering,all prediction heads. Excludes model/image load and CPU quality.',
        *[str(t) for t in timings],
        'Dense-relative speedup=N/A:no paired Dense timings;unchanged controls not rerun without explicit request. Dense definition=1.00x. Historical controls are not contemporaneous speed comparisons.',
        'No published-reference scores used; native local FastVGGT is not claimed paper-equivalent. No local matchedDense quality is available in this experiment, so degradation againstDense=N/A. No paper reproduction drift is claimed.',
        'Quality protocol:pose+recon_unposed;F1threshold0.05m,downsample/voxel0.0078125m,TSDFtrunc0.04m,1million mesh points;unchanged unposed alignment/fusion. All candidate pixels and checkpoint verified identical to localFastVGGT.',
        'SAF3R:DINO-feature cosine per-frameTop128,profileeth3d-train-fltr-calib_cmpmse.json;not officialTop4. Top128 perframe is16384ordinarykeys/query at128frames. See existing SAF3R artifact for rawprofile.',
        'FastVGGT:upstream6526e275,merging0,merge_ratio0.9,nativeFastAggregator,all original prediction heads;BF16aggregator features converted toFP32inside timedforward.',
        'Hyperparameters frozen on ETH3D before7Scenes;no7Scenes truth tuning.',
        '', 'Strict six-metric gates:',*[k+': '+str(v) for k,v in gates.items()]]
    (report/'report.txt').write_text('\n'.join(lines)+'\n')
    # Common model/evaluation code complements frozen candidate patch snapshots.
    sources=[]
    for directory in ['saf3r/models/official_vggt','saf3r/utils','evaluation','scripts']:
        sources.extend((ROOT/directory).rglob('*.py'))
    hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}
    (report/'common_source_sha256.json').write_text(json.dumps(hashes,indent=2))
    with tarfile.open(report/'common_source.tar.gz','w:gz') as tar:
        for p in hashes:tar.add(ROOT/p,arcname=p)
    print('\n'.join(lines[:3+len(rows)]));print('strict gates', {k:v['all_six_pass'] for k,v in gates.items()})

if __name__=='__main__':main()
