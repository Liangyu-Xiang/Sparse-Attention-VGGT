"""Fixed-QKV causal support replay: only candidate's own previous executed IDs.

Compare linear,squared and square-root loss importance, keeping probability
estimation, execution compensation, Value clusters, budgets and kernels fixed.
"""
import sys,json,time,types
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
import numpy as np,pandas as pd,torch,saf3r
m=types.ModuleType('saf3r.patch');m.__path__=[str(ROOT/'saf3r/patch')];sys.modules['saf3r.patch']=m;saf3r.patch=m
from saf3r.patch import beta_loss_states as states
from saf3r.patch.beta_unified_importance import estimate
from saf3r.patch.beta_moment_importance import observe
from saf3r.triton.beta_moment_attention import attention
from scripts.quality_metrics import quality_record
from saf3r.patch.source_local_unanchored import SourceLocalUnanchoredValue
from saf3r.patch.head_value_sketch import projection,features
SOURCE=ROOT/'outputs/logit_transfer_failure_20261108';OUT=ROOT/'outputs/beta_unified_20261108/causal_cluster095_replay'

def main():
 OUT.mkdir(exist_ok=False);torch.set_num_threads(2);torch.backends.cuda.matmul.allow_tf32=False;start=time.monotonic();cache={fraction:None for fraction in [.095]};fine={};matrix=None;rows=[];previous=None
 for layer in range(24):
  a=torch.load(SOURCE/'capture'/f'layer{layer:02d}.pt',mmap=True,weights_only=True);qfull=a['q_full'].cuda();h,g,queries,d=qfull.shape;k=a['k'].cuda();v=a['v'].cuda();q=qfull.reshape(h,g*queries,d)[:,:k.shape[1]].contiguous();qm=a['query_valid'].cuda();mask=qm.reshape(-1)[:q.shape[1]].contiguous();counts=qm.sum(1).float();grid=a['grid'].cuda();sizes=a['sizes'].cuda();mean=a['source_mean'].cuda();coarse=a['source_coarse'].cuda();patch=a['patches'].cuda();special=a['specials'].cuda().int();labels=a['labels'].cuda();reps=a['reps'].cuda();pop=a['population'].cuda();n=len(labels);f=len(reps);cap=a['patch_cap']
  geo=dict(probe_member_width=a['members'].shape[1],members=a['members'].cuda(),norm2=a['norm2'].cuda(),rep_distance=a['rep_distance'].cuda())
  if matrix is None:matrix=projection(h,d,a['z'].shape[1]//h,q.device)
  phi=features(v,matrix)[patch].contiguous();zz=(phi/phi.square().sum(-1).mean().clamp_min(1e-12).sqrt()).contiguous();torch.testing.assert_close(zz,a['z'].cuda(),rtol=2e-5,atol=2e-6)
  oracle=np.load(SOURCE/'features'/f'layer{layer:02d}.npz');ptrue=torch.from_numpy(oracle['P_head'].mean(0)).cuda()
  from torch.nn.attention import sdpa_kernel,SDPBackend
  with sdpa_kernel(SDPBackend.FLASH_ATTENTION):dense=torch.nn.functional.scaled_dot_product_attention(qfull.reshape(h,g*queries,d)[None],k[None],v[None],scale=a['scale'])[0]
  wo=a['projection_weight'].cuda().float();bias=None if a['projection_bias'] is None else a['projection_bias'].cuda().float()
  def project(out):return torch.nn.functional.linear(out.float().reshape(h,g,queries,d).permute(1,2,0,3).reshape(g,queries,-1),wo,bias)
  target=project(dense);den=(target.square()*qm[...,None]).sum((1,2));shift=(mean[:,:,0]+sizes.log()[None,None]).logsumexp(-1).contiguous()
  baseline_ids=None
  # Power1 first, for fixed-input equivalence checks and mask comparison.
  for fraction in [.095]:
   power=1.
   if fraction not in fine:
    frames=len(special)//5;fine[fraction]=SourceLocalUnanchoredValue(frames,1,n//frames,int(fraction*n),q.device,source_width=32,iterations=1,layout='sequential',temporal_span=1,fused_scatter=True)
   fine[fraction].update(phi,layer);labels=fine[fraction].labels;reps=fine[fraction].reps;f=len(reps);pop=torch.bincount(labels,minlength=f).float();assert (pop>0).all()
   agreement=float((labels==a['labels'].cuda()).float().mean()) if fraction==.1 else None
   if fraction==.1:assert agreement>.9998,('Clustering reconstruction mismatch',layer,agreement)
   norm=zz.square().sum(-1).contiguous();distance=(zz-zz[reps[labels]]).square().sum(-1).contiguous();width=1<<(int(pop.max())-1).bit_length();assert width<=512
   order=labels.argsort(stable=True);starts=pop.long().cumsum(0)-pop.long();rank=torch.arange(n,device='cuda')-starts[labels[order]];members=torch.full((f,width),-1,device='cuda',dtype=torch.int32);members[labels[order],rank]=order.int();geo=dict(probe_member_width=width,members=members,norm2=norm,rep_distance=distance)

   old=torch.full((g,1),-1,device='cuda',dtype=torch.int32) if cache[fraction] is None else cache[fraction]['ids'];history=None if cache[fraction] is None else cache[fraction]['history']
   prior,_=estimate(mean,coarse,previous,old,history,grid,sizes,layer);states.LOSS_POWER=power
   pi=torch.empty(g,f,device='cuda');allowed=torch.ones(g,1,device='cuda',dtype=torch.bool);z=torch.empty(n,0,device='cuda')
   ids,valid,weights,record=states.select(prior,pi,old,allowed,z,reps,labels,pop,geo,cap,16)
   assert not bool(record['implementation_validation_error'].any())
   actual=patch[ids.clamp_min(0)].masked_fill(ids<0,-1).int().contiguous();output,evidence=attention(q,k,v,actual,special,weights,a['scale'],mask,counts,layer<23,4,1,shift)
   if layer<23:
    fresh=observe(mean,grid,sizes,ids,evidence['mean_exp']);assert torch.isfinite(fresh).all();cache[fraction]=dict(ids=ids,history=fresh)
   padded=torch.zeros(h,g*queries,d,device='cuda',dtype=output.dtype);padded[:,:q.shape[1]]=output
   error=((project(padded)-target).square()*qm[...,None]).sum((1,2))
   selected=torch.zeros(g,n+1,device='cuda',dtype=torch.bool).scatter_(1,ids.masked_fill(~valid,n).long(),valid)[:,:n]
   if fraction==.095:baseline_ids=selected
   oldvalid=old>=0;saf=old.clamp_min(0).long();hist_pred=(prior.gather(1,saf)*oldvalid).sum(1);hist_true=(ptrue.gather(1,saf)*oldvalid).sum(1)
   for group in range(g):rows.append(dict(layer=layer,stage='0-5' if layer<6 else '6-17' if layer<18 else '18-23',query_group=group,cluster_fraction=fraction,source_label_agreement=agreement,loss_power=power,output_relative_L2=float((error[group]/den[group]).sqrt()),output_error_squared=float(error[group]),dense_output_squared=float(den[group]),global_TV=float(.5*(prior[group]-ptrue[group]).abs().sum()),selected_true_mass=float((ptrue[group]*selected[group]).sum()),history_mass_pred=float(hist_pred[group]),history_mass_true=float(hist_true[group]),selected_keys=int(valid[group].sum()),mask_jaccard_vs_linear=float((selected[group]&baseline_ids[group]).sum()/(selected[group]|baseline_ids[group]).sum().clamp_min(1)),history_source_layer=layer-1,current_extra_fine_QK=0,actual_previous_support=True,**{key:float(record[key][group]) for key in ['reuse_edges','representatives','exact_edges','dropped_clusters']}))
  previous=coarse
  pd.DataFrame(rows).to_csv(OUT/'per_group_layer.csv',index=False);print('CAUSAL_LAYER',layer,flush=True)
 data=pd.DataFrame(rows);data.groupby(['cluster_fraction','layer','stage']).mean(numeric_only=True).to_csv(OUT/'per_layer.csv');data.groupby(['cluster_fraction','stage']).mean(numeric_only=True).to_csv(OUT/'per_stage.csv')
 quality=quality_record({},'Fixed-QKV causal-support diagnostic,not full model pose/recon_unposed;no paired Dense timing')
 (OUT/'quality.json').write_text(json.dumps(quality,indent=2));(OUT/'complete.json').write_text(json.dumps(dict(complete=True,layers=24,groups=g,cluster_fractions=[.095],wall_seconds=time.monotonic()-start,peak_GiB=torch.cuda.max_memory_allocated()/2**30,probability_model='Moment,alpha0.5,tau0.5',execution_compensation='unchanged gamma0.5',quality=quality),indent=2))
if __name__=='__main__':
 with torch.inference_mode():main()
