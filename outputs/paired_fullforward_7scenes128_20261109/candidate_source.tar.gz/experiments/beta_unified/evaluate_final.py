"""Frozen algorithm + validated DPT batching, complete128frame evaluation."""
import argparse,importlib,json,sys,traceback,types
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT),str(ROOT/'evaluation')]
m=types.ModuleType('benchmarks');m.__path__=[str(ROOT/'evaluation/benchmarks')];sys.modules['benchmarks']=m
import saf3r
m=types.ModuleType('saf3r.patch');m.__path__=[str(ROOT/'saf3r/patch')];sys.modules['saf3r.patch']=m;saf3r.patch=m
from scripts.quality_metrics import quality_record,quality_markdown

def main(a):
 from saf3r.utils import model_utils
 from saf3r.patch.beta_head_batching import install as batch
 original=model_utils.build_model
 def build(cfg,device):
  model=original(cfg,device);batch(model,a.head_chunk,validate=False);return model
 model_utils.build_model=build
 name={'unified':'evaluate_7scenes','moment':'evaluate_moment_7scenes','comp':'evaluate_comp_7scenes','subgroup':'evaluate_subgroup_7scenes','fast_unified':'evaluate_fast_unified_7scenes','fast_moment':'evaluate_fast_moment_7scenes','fast_subgroup':'evaluate_fast_subgroup_7scenes','weight_unified':'evaluate_weight_unified_7scenes','weight_moment':'evaluate_weight_moment_7scenes','weight_subgroup':'evaluate_weight_subgroup_7scenes'}[a.engine]
 evaluation=importlib.import_module('experiments.beta_unified.'+name)
 evaluation.run(a)
 for path in [a.output/'forward.json',a.output/'result.json']:
  data=json.loads(path.read_text());data['engineering']=dict(head_frames_chunk=a.head_chunk,all_heads_retained=True,precision='Unchanged BF16 backbone + FP32 prediction heads',batching_checks='outputs/beta_unified_20261108/head_chunk32/run/head_batching_checks.json',algorithm_engine=a.engine);evaluation.save(path,data)

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--engine',choices=['unified','moment','comp','subgroup','fast_unified','fast_moment','fast_subgroup','weight_unified','weight_moment','weight_subgroup'],required=True);p.add_argument('--head-chunk',type=int,default=32);p.add_argument('--alpha',type=float,required=True);p.add_argument('--tau',type=float,required=True);p.add_argument('--scene',required=True);p.add_argument('--expected-input',type=Path,required=True);p.add_argument('--config',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
 try:main(a)
 except BaseException as exc:
  a.output.mkdir(parents=True,exist_ok=True);q=quality_record({},f'{type(exc).__name__}: {exc}');(a.output/'quality.json').write_text(json.dumps(q,indent=2));(a.output/'quality.md').write_text(quality_markdown(q));(a.output/'failure.json').write_text(json.dumps(dict(error=str(exc),traceback=traceback.format_exc()),indent=2));raise
