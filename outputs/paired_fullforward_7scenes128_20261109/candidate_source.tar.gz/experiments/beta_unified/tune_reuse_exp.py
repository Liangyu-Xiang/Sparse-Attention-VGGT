"""Tile/launch tuning on real128frame tensors, no quality truth or new QK."""
import json,time,statistics,torch,triton

def attach(out):
 from saf3r.triton import beta_moment_attention as mod
 original=mod.attention;calls=0
 from saf3r.triton.beta_reuse_exp_attention import _attention as optimized
 def wrapped(q,k,v,ids,specials,weights,scale,mask,counts,capture=True,warps=4,stages=1,shift=None):
  nonlocal calls
  calls+=1
  if calls!=109:return original(q,k,v,ids,specials,weights,scale,mask,counts,capture,warps,stages,shift=shift)
  ref,evidence=original(q,k,v,ids,specials,weights,scale,mask,counts,capture,warps,stages,shift=shift);rows=[]
  h,r,d=q.shape;g,a=ids.shape
  for bm,bk,nw,ns,cache in [(64,128,4,1,""),(64,128,4,2,""),(64,256,4,1,""),(128,64,4,1,""),(128,128,4,1,""),(128,128,4,2,""),(128,128,8,1,""),(256,128,8,1,"")]:
   def run():
    bias=weights.log().contiguous();o=torch.empty_like(q);mean=torch.zeros(h,g,1,a,device=q.device,dtype=torch.float32)
    optimized[(triton.cdiv(r,bm),h)](q,k,v,ids,specials,bias,mask,counts,shift,o,mean,h,r,k.shape[1],g,a,len(specials),d,q.stride(0),k.stride(0),v.stride(0),o.stride(0),scale,capture,triton.next_power_of_2(d),bm,bk,num_warps=nw,num_stages=ns)
    return o,mean
   try:
    got,mean=run();torch.cuda.synchronize();samples=[]
    for repeat in range(5):
     a0=torch.cuda.Event(enable_timing=True);b0=torch.cuda.Event(enable_timing=True);a0.record();got,mean=run();b0.record();b0.synchronize();samples.append(a0.elapsed_time(b0))
    relative=float((got.float()-ref.float()).norm()/ref.float().norm());rmse=float((mean-evidence['mean_exp']).square().mean().sqrt());maximum=float((mean-evidence['mean_exp']).abs().max())
    valid=relative<.003 and torch.allclose(mean,evidence['mean_exp'],rtol=.003,atol=.003)
    rows.append(dict(kv_cache=cache,bm=bm,bk=bk,warps=nw,stages=ns,median_ms=statistics.median(samples),samples_ms=samples,output_relative_L2=relative,cache_rmse=rmse,cache_max_difference=maximum,valid=bool(valid)))
   except Exception as exc:rows.append(dict(kv_cache=cache,bm=bm,bk=bk,warps=nw,stages=ns,valid=False,error=str(exc)))
   print('TILE_TUNING',rows[-1],flush=True)
  selected=min((x for x in rows if x['valid']),key=lambda x:x['median_ms'])
  (out/'kernel_tuning.json').write_text(json.dumps(dict(shape=dict(q=list(q.shape),k=list(k.shape),ids=list(ids.shape)),rows=rows,selected=selected,selection_rule='Fastest same-formula launch with output relativeL2<0.003,raw cache allclose;no7Scenes truth read',quality={x:None for x in ['auc03','auc30','acc','comp','cd','f1']},quality_unavailable='Kernel diagnostic only,not a complete quality evaluation',dense_speedup=None,dense_speedup_reason='No paired full-forward Dense'),indent=2))
  return ref,evidence
 mod.attention=wrapped
