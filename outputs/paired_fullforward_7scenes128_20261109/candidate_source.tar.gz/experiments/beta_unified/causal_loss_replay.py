"""Fixed-QKV causal support replay: only candidate's own previous executed IDs.

Compare linear,squared and square-root loss importance, keeping probability
estimation, execution compensation, Value clusters, budgets and kernels fixed.
"""
import sys,json,time,types
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
import numpy as np,pandas as pd,torch,saf3r
m=types.ModuleType('saf3r.patch');m.__path__=[str(ROOT/'saf3r/patch')];sys.modules['saf3r.patch']=m;saf3r.patch=m
from saf3r.patch import beta_loss_states as states
from saf3r.patch.beta_unified_importance import estimate
from saf3r.patch.beta_moment_importance import observe
from saf3r.triton.beta_moment_attention import attention
from scripts.quality_metrics import quality_record
SOURCE=ROOT/'outputs/logit_transfer_failure_20261108';OUT=ROOT/'outputs/beta_unified_20261108/causal_loss_replay'

def main():
 OUT.mkdir(exist_ok=False);torch.set_num_threads(2);torch.backends.cuda.matmul.allow_tf32=False;start=time.monotonic();cache={power:None for power in [.5,1.,2.]};rows=[];previous=None
 for layer in range(24):
  a=torch.load(SOURCE/'capture'/f'layer{layer:02d}.pt',mmap=True,weights_only=True);qfull=a['q_full'].cuda();h,g,queries,d=qfull.shape;k=a['k'].cuda();v=a['v'].cuda();q=qfull.reshape(h,g*queries,d)[:,:k.shape[1]].contiguous();qm=a['query_valid'].cuda();mask=qm.reshape(-1)[:q.shape[1]].contiguous();counts=qm.sum(1).float();grid=a['grid'].cuda();sizes=a['sizes'].cuda();mean=a['source_mean'].cuda();coarse=a['source_coarse'].cuda();patch=a['patches'].cuda();special=a['specials'].cuda().int();labels=a['labels'].cuda();reps=a['reps'].cuda();pop=a['population'].cuda();n=len(labels);f=len(reps);cap=a['patch_cap']
  geo=dict(probe_member_width=a['members'].shape[1],members=a['members'].cuda(),norm2=a['norm2'].cuda(),rep_distance=a['rep_distance'].cuda())
  oracle=np.load(SOURCE/'features'/f'layer{layer:02d}.npz');ptrue=torch.from_numpy(oracle['P_head'].mean(0)).cuda()
  from torch.nn.attention import sdpa_kernel,SDPBackend
  with sdpa_kernel(SDPBackend.FLASH_ATTENTION):dense=torch.nn.functional.scaled_dot_product_attention(qfull.reshape(h,g*queries,d)[None],k[None],v[None],scale=a['scale'])[0]
  wo=a['projection_weight'].cuda().float();bias=None if a['projection_bias'] is None else a['projection_bias'].cuda().float()
  def project(out):return torch.nn.functional.linear(out.float().reshape(h,g,queries,d).permute(1,2,0,3).reshape(g,queries,-1),wo,bias)
  target=project(dense);den=(target.square()*qm[...,None]).sum((1,2));shift=(mean[:,:,0]+sizes.log()[None,None]).logsumexp(-1).contiguous()
  baseline_ids=None
  # Power1 first, for fixed-input equivalence checks and mask comparison.
  for power in [1.,.5,2.]:
   old=torch.full((g,1),-1,device='cuda',dtype=torch.int32) if cache[power] is None else cache[power]['ids'];history=None if cache[power] is None else cache[power]['history']
   prior,_=estimate(mean,coarse,previous,old,history,grid,sizes,layer);states.LOSS_POWER=power
   pi=torch.empty(g,f,device='cuda');allowed=torch.ones(g,1,device='cuda',dtype=torch.bool);z=torch.empty(n,0,device='cuda')
   ids,valid,weights,record=states.select(prior,pi,old,allowed,z,reps,labels,pop,geo,cap,16)
   assert not bool(record['implementation_validation_error'].any())
   if power==1. and layer in [0,12,23]:
    from saf3r.patch.history_transfer_states import select as reference
    ref=reference(prior,torch.empty_like(pi),old,allowed,z,reps,labels,pop,geo,cap,16)
    assert torch.equal(ids,ref[0]);torch.testing.assert_close(weights,ref[2],rtol=3e-5,atol=3e-6)
   actual=patch[ids.clamp_min(0)].masked_fill(ids<0,-1).int().contiguous();output,evidence=attention(q,k,v,actual,special,weights,a['scale'],mask,counts,layer<23,4,1,shift)
   if layer<23:
    fresh=observe(mean,grid,sizes,ids,evidence['mean_exp']);assert torch.isfinite(fresh).all();cache[power]=dict(ids=ids,history=fresh)
   padded=torch.zeros(h,g*queries,d,device='cuda',dtype=output.dtype);padded[:,:q.shape[1]]=output
   error=((project(padded)-target).square()*qm[...,None]).sum((1,2))
   selected=torch.zeros(g,n+1,device='cuda',dtype=torch.bool).scatter_(1,ids.masked_fill(~valid,n).long(),valid)[:,:n]
   if power==1.:baseline_ids=selected
   oldvalid=old>=0;saf=old.clamp_min(0).long();hist_pred=(prior.gather(1,saf)*oldvalid).sum(1);hist_true=(ptrue.gather(1,saf)*oldvalid).sum(1)
   for group in range(g):rows.append(dict(layer=layer,stage='0-5' if layer<6 else '6-17' if layer<18 else '18-23',query_group=group,loss_power=power,output_relative_L2=float((error[group]/den[group]).sqrt()),output_error_squared=float(error[group]),dense_output_squared=float(den[group]),global_TV=float(.5*(prior[group]-ptrue[group]).abs().sum()),selected_true_mass=float((ptrue[group]*selected[group]).sum()),history_mass_pred=float(hist_pred[group]),history_mass_true=float(hist_true[group]),selected_keys=int(valid[group].sum()),mask_jaccard_vs_linear=float((selected[group]&baseline_ids[group]).sum()/(selected[group]|baseline_ids[group]).sum().clamp_min(1)),history_source_layer=layer-1,current_extra_fine_QK=0,actual_previous_support=True,**{key:float(record[key][group]) for key in ['reuse_edges','representatives','exact_edges','dropped_clusters']}))
  previous=coarse
  pd.DataFrame(rows).to_csv(OUT/'per_group_layer.csv',index=False);print('CAUSAL_LAYER',layer,flush=True)
 data=pd.DataFrame(rows);data.groupby(['loss_power','layer','stage']).mean(numeric_only=True).to_csv(OUT/'per_layer.csv');data.groupby(['loss_power','stage']).mean(numeric_only=True).to_csv(OUT/'per_stage.csv')
 quality=quality_record({},'Fixed-QKV causal-support diagnostic,not full model pose/recon_unposed;no paired Dense timing')
 (OUT/'quality.json').write_text(json.dumps(quality,indent=2));(OUT/'complete.json').write_text(json.dumps(dict(complete=True,layers=24,groups=g,loss_powers=[.5,1.,2.],wall_seconds=time.monotonic()-start,peak_GiB=torch.cuda.max_memory_allocated()/2**30,probability_model='Moment,alpha0.5,tau0.5',execution_compensation='unchanged gamma0.5',quality=quality),indent=2))
if __name__=='__main__':
 with torch.inference_mode():main()
