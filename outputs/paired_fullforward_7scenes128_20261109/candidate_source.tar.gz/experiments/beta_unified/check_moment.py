"""Check inline cache against offline QK and preserve formal AV output."""
import sys,json,types
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
import torch,saf3r
m=types.ModuleType('saf3r.patch');m.__path__=[str(ROOT/'saf3r/patch')];sys.modules['saf3r.patch']=m;saf3r.patch=m
from saf3r.triton.group_mean_logit_attention import attention as ref
from saf3r.triton.beta_moment_attention import attention
from saf3r.patch.beta_moment_importance import observe
from experiments.beta_unified.moment_cache import cache
from scripts.quality_metrics import quality_record
out=ROOT/'outputs/beta_unified_20261108/moment_check';out.mkdir(exist_ok=True);rows=[]
torch.backends.cuda.matmul.allow_tf32=False;torch.set_num_threads(2)
with torch.inference_mode():
 for layer in [1,12,22]:
  a=torch.load(ROOT/f'outputs/logit_transfer_failure_20261108/capture/layer{layer:02d}.pt',mmap=True,weights_only=True)
  q=a['q_full'].cuda();h,g,qs,d=q.shape;q=q.reshape(h,g*qs,d).contiguous();k=a['k'].cuda();v=a['v'].cuda();ids=a['source_ids'].cuda();patch=a['patches'].cuda();actual=patch[ids.clamp_min(0)].masked_fill(ids<0,-1).int().contiguous();special=a['specials'].cuda().int();mask=a['query_valid'].cuda();counts=mask.sum(1).float();weights=torch.ones_like(ids,dtype=torch.float32).masked_fill(ids<0,0.);mean=a['source_mean'].cuda();sizes=a['sizes'].cuda();grid=a['grid'].cuda();shift=(mean[:,:,0]+sizes.log()[None,None]).logsumexp(-1).contiguous()
  baseline,_=ref(q,k,v,actual,special,weights,a['scale'],mask.reshape(-1),counts,True,4,1)
  output,evidence=attention(q,k,v,actual,special,weights,a['scale'],mask.reshape(-1),counts,True,4,1,shift)
  torch.testing.assert_close(output,baseline,atol=0.,rtol=0.)
  observed=observe(mean,grid,sizes,ids,evidence['mean_exp']);truth=cache(a)
  torch.testing.assert_close(observed,truth,atol=3e-6,rtol=5e-4)
  rows.append(dict(layer=layer,output_identical=True,cache_max_absolute_difference=float((observed-truth).abs().max()),finite=bool(torch.isfinite(observed).all())))
  print(rows[-1],flush=True)
(out/'result.json').write_text(json.dumps(dict(complete=True,checks=rows,quality=quality_record({},'Offline/kernel correctness diagnostic;no pose/recon tasks or paired Dense timing')),indent=2))
