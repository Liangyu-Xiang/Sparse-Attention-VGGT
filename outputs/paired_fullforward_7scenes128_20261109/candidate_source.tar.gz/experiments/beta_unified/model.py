"""One confidence formula for all layers; head-mean history correction."""
import torch

def estimate(mean,coarse,previous,ids,history,grid,sizes,confidence,normalization):
    from saf3r.patch.beta_global_logshrink_importance import estimate as original
    if confidence=='stage':
        return original(mean,coarse,previous,ids,history,grid,sizes,estimate.layer)[0]
    alpha,tau=map(float,confidence.split('_'))
    g=coarse.shape[0];n=len(grid);valid=ids>=0;safe=ids.clamp_min(0).long();block=grid[safe]
    u=coarse[:,grid]/sizes[grid]
    beta=(torch.minimum(coarse,previous)/torch.maximum(coarse,previous).clamp_min(1e-30)).clamp_min(0).pow(tau)
    oldbase=previous.gather(1,block)/sizes[block]
    d=(history/oldbase.clamp_min(1e-30)).clamp_min(1e-30).log()
    values=u.gather(1,safe)*torch.exp(alpha*beta.gather(1,block)*d)
    prior=torch.cat((u,u.new_zeros(g,1)),1).scatter_(1,safe.masked_fill(~valid,n),values.masked_fill(~valid,0.))[:,:n]
    return (prior/prior.sum(1,keepdim=True)).contiguous()
