"""Matched ETH3D scene batches,one CUDA process/GPU,three changed variants."""
import argparse,concurrent.futures,hashlib,json,os,queue,shutil,subprocess,sys,tarfile,threading,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
def main():
 p=argparse.ArgumentParser();p.add_argument('--spec',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();out=a.output.resolve();out.mkdir(parents=True,exist_ok=False);spec=json.loads(a.spec.read_text());(out/'frozen_spec.json').write_text(json.dumps(spec,indent=2));ref=ROOT/'outputs/beta_global_logshrink_eth3d_20261108';shutil.copytree(ref/'expected_inputs',out/'expected_inputs');base=json.loads((ref/'config.json').read_text())
 for name,c in spec['candidates'].items():
  (out/name).mkdir();(out/name/'config.json').write_text(json.dumps(dict(base,**c.get('config_overrides',{})),indent=2))
 (out/'batches').mkdir();tasks=queue.Queue()
 for scene in spec['scenes']:tasks.put(scene)
 sources=list((ROOT/'saf3r/patch').glob('*.py'))+list((ROOT/'saf3r/triton').glob('*.py'))+list((ROOT/'experiments/beta_unified').glob('*.py'));hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources};(out/'source_sha256.json').write_text(json.dumps(hashes,indent=2))
 with tarfile.open(out/'source.tar.gz','w:gz') as t:
  for f in hashes:t.add(ROOT/f,arcname=f)
 env=dict(os.environ,LD_LIBRARY_PATH=str(Path(sys.prefix)/'lib')+os.pathsep+os.environ.get('LD_LIBRARY_PATH',''),OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',PYTORCH_ALLOC_CONF='expandable_segments:True',PYTHONDONTWRITEBYTECODE='1');lock=threading.Lock();done=[];running={}
 def status():
  temp=out/'progress.tmp';temp.write_text(json.dumps(dict(completed=done,running=running),indent=2));temp.replace(out/'progress.json')
 def worker(gpu):
  while True:
   try:scene=tasks.get_nowait()
   except queue.Empty:return
   cmd=[sys.executable,str(ROOT/'experiments/logit_eth3d/run_gpu_exclusive.py'),'--gpu',str(gpu),'--monitor',str(out/'monitors'/f'{scene}.json'),'--log',str(out/'logs'/f'{scene}.log'),'--',sys.executable,'-u',str(ROOT/'experiments/beta_unified/evaluate_scene_batch.py'),'--root',str(out),'--spec',str(out/'frozen_spec.json'),'--scene',scene,'--expected-input',str(out/'expected_inputs'/f'{scene}.json')]
   with lock:running[str(gpu)]=scene;status()
   begin=time.monotonic();code=subprocess.call(cmd,cwd=ROOT,env=env);path=out/'batches'/f'{scene}.json';complete=path.exists() and json.loads(path.read_text())['complete']
   with lock:done.append(dict(scene=scene,gpu=gpu,returncode=code,complete=complete,wall_seconds=time.monotonic()-begin));running.pop(str(gpu));status()
   print('BATCH_DONE',scene,code,complete,flush=True)
   if code or not complete:raise RuntimeError('Incomplete scene batch '+scene)
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(worker,[4,5,6]))
 (out/'complete.json').write_text(json.dumps(dict(complete=len(done)==11 and all(x['complete'] for x in done),runs=done),indent=2))
if __name__=='__main__':main()
