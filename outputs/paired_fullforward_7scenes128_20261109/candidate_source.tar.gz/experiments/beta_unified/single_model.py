"""Fixed-QKV diagnostic: coherent existing coarse-query/actual-edge observation."""
import torch
from saf3r.patch.beta_headmean_importance import observe

def observation(a):
 q=a['q_full'].cuda();h,g,queries,d=q.shape;k=a['k'].cuda();patch=a['patches'].cuda();grid=a['grid'].cuda();sizes=a['sizes'].cuda();mask=a['query_valid'].cuda();r=len(sizes)
 pos=torch.full((g,),32,device='cuda',dtype=torch.long).clamp_max(queries-1)
 bad=~mask[torch.arange(g,device='cuda'),pos];pos=(pos+bad*5).clamp_max(queries-1)
 for _ in range(queries):
  bad=~mask[torch.arange(g,device='cuda'),pos]
  if not bad.any():break
  pos=torch.where(bad,(pos+1)%queries,pos)
 qp=q[:,torch.arange(g,device='cuda'),pos].float()
 pooled=torch.zeros(h,r,d,device='cuda');pooled.index_add_(1,grid,k[:,patch].float());pooled/=sizes[None,:,None]
 mean=torch.einsum('hgd,hrd->hgr',qp,pooled)*a['scale']
 coarse=(mean+sizes.log()[None,None]).softmax(-1).mean(0)
 ids=a['source_ids'].cuda();safe=ids.clamp_min(0).long();raw=(qp[:,:,None]*k[:,patch[safe]].float()).sum(-1)*a['scale']
 return dict(mean=mean[:,:,None].contiguous(),coarse=coarse.contiguous(),cache=observe(mean[:,:,None],grid,sizes,ids,raw[:,:,None]))
