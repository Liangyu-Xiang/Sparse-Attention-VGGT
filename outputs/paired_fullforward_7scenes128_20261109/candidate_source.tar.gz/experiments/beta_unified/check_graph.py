"""Fixed-QKV numerical equivalence for cached selector replay and fresh inputs."""
import json,sys,types
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
import torch,saf3r
m=types.ModuleType('saf3r.patch');m.__path__=[str(ROOT/'saf3r/patch')];sys.modules['saf3r.patch']=m;saf3r.patch=m
from saf3r.patch.history_transfer_states import select as eager
from saf3r.patch.beta_unified_selection import select
from saf3r.patch.reuse_residual_exploration import ReuseExploreConfig
from scripts.quality_metrics import quality_record
out=ROOT/'outputs/beta_unified_20261108/graph_check';out.mkdir(exist_ok=True)
torch.set_num_threads(2);torch.manual_seed(123)
a=torch.load(ROOT/'outputs/logit_transfer_failure_20261108/capture/layer12.pt',weights_only=True,mmap=True)
config=json.loads((ROOT/'outputs/beta_global_logshrink_7scenes128_20261108/config.json').read_text());config['graph_cache_max_mib']=2048
s=types.SimpleNamespace(config=ReuseExploreConfig(**config),budget=a['patch_cap'],_forward_serial=1,graph_cache_creations=0,graph_cache_hits=0,graph_cache_misses=0,graph_cache_evictions=0,graph_constant_updates=0)
labels=a['labels'].cuda();reps=a['reps'].cuda();population=a['population'].cuda();old=a['source_old'].cuda();p=a['source_prior'].cuda();g,n=p.shape;f=len(reps)
geo=dict(width=1,probe_member_width=a['members'].shape[1],members=a['members'].cuda(),norm2=a['norm2'].cuda(),rep_distance=a['rep_distance'].cuda(),current_dense_prior=True,shared_value_loss=True,fuse_state_kernel=True,rep_history_execution='population',drop_bins=[(1,torch.arange(f,device='cuda',dtype=torch.int32))])
results=[]
with torch.inference_mode():
 for i in range(3):
  # Change prior/history and layer constants; graph must never reuse stale values.
  prior=p*(.5+torch.rand_like(p)) if i else p;prior=prior/prior.sum(1,keepdim=True)
  ids=old.clone()
  if i:ids[:,::5]=-1
  geometry=dict(geo,norm2=geo['norm2']*(1+.1*i),rep_distance=geo['rep_distance']*(1+.2*i))
  z=torch.empty(n,0,device='cuda');allowed=torch.ones(g,1,device='cuda',dtype=torch.bool)
  ref=eager(prior,torch.empty(g,f,device='cuda'),ids,allowed,z,reps,labels,population,geometry,s.budget,16)
  got=select(s,i,prior,torch.empty(g,f,device='cuda'),ids,allowed,z,reps,labels,population,geometry)
  assert torch.equal(ref[0],got[0]),f'mask changed replay{i}'
  assert torch.equal(ref[1],got[1])
  torch.testing.assert_close(ref[2],got[2],rtol=3e-5,atol=3e-6)
  for k in ['counts','implementation_validation_error','representatives','dropped_clusters','reuse_edges','exact_edges']:torch.testing.assert_close(ref[3][k],got[3][k])
  results.append(dict(replay=i,ids_equal=True,max_weight_difference=float((ref[2]-got[2]).abs().max()),valid=not bool(got[3]['implementation_validation_error'].any())))
(out/'result.json').write_text(json.dumps(dict(complete=True,checks=results,graph_creations=s.graph_cache_creations,hits=s.graph_cache_hits,quality=quality_record({},'Selector numerical check only; pose/recon not executed;no paired Dense timing')),indent=2))
print(results,flush=True)
