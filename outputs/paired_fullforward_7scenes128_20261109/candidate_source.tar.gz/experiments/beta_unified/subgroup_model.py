"""Four contiguous Query means, all256 queries covered;no Query probes."""
import torch

def observation(a):
 q=a['q_full'].cuda();h,g,queries,d=q.shape;assert queries==256
 k=a['k'].cuda();patch=a['patches'].cuda();grid=a['grid'].cuda();sizes=a['sizes'].cuda();mask=a['query_valid'].cuda();r=len(sizes)
 validq=mask.reshape(g,4,64);counts=validq.sum(-1);weights=counts/counts.sum(-1,keepdim=True)
 qm=(q.reshape(h,g,4,64,d).float()*validq[None,:,:,:,None]).sum(3)/counts.clamp_min(1)[None,:,:,None]
 pooled=torch.zeros(h,r,d,device='cuda');pooled.index_add_(1,grid,k[:,patch].float());pooled/=sizes[None,:,None]
 mean=torch.einsum('hgpd,hrd->hgpr',qm,pooled)*a['scale'];shift=(mean+sizes.log()[None,None,None]).logsumexp(-1)
 coarse=((mean+sizes.log()[None,None,None]).softmax(-1).mean(0)*weights[:,:,None]).sum(1)
 ids=a['source_ids'].cuda();valid=ids>=0;safe=ids.clamp_min(0).long();block=grid[safe]
 count=mean.new_zeros(g,r).scatter_add_(1,block,valid.float());missing=(sizes[None]-count).clamp_min(0);result=[]
 for begin in range(0,g,4):
  end=min(g,begin+4);sel=k[:,patch[safe[begin:end]]].float();z=torch.einsum('hgpqd,hgad->hgpqa',q[:,begin:end].reshape(h,end-begin,4,64,d).float(),sel)*a['scale']
  num=(z-shift[:,begin:end,:,None,None]).exp().masked_fill(~validq[None,begin:end,:,:,None],0.).sum(3)/counts[None,begin:end,:,None].clamp_min(1)
  num=num.masked_fill(~valid[None,begin:end,None],0.)
  unknown=((mean[:,begin:end]-shift[:,begin:end,:,None]).exp()*missing[None,begin:end,None]).sum(-1)
  hp=(num/(num.sum(-1)+unknown).clamp_min(1e-30)[...,None]).mean(0)
  result.append((hp*weights[begin:end,:,None]).sum(1))
 return dict(mean=mean,coarse=coarse.contiguous(),cache=torch.cat(result).contiguous())
