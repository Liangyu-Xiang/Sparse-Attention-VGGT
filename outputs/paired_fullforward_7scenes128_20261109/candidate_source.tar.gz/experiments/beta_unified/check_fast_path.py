"""Numerical checks: undo AV compensation,normalize before head mean,partial tails."""
import sys,json,types
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
import torch,saf3r
m=types.ModuleType('saf3r.patch');m.__path__=[str(ROOT/'saf3r/patch')];sys.modules['saf3r.patch']=m;saf3r.patch=m
from saf3r.triton.beta_moment_attention import attention as slow
from saf3r.triton.beta_reuse_exp_safe_attention import attention as fast
from saf3r.patch.beta_moment_importance import observe as moment_observe
from saf3r.patch.beta_headmean_importance import observe as raw_observe
from saf3r.patch.beta_subgroup_importance import observe as subgroup_observe
from saf3r.triton.beta_subgroup_attention import attention as subgroup_attention
from saf3r.triton.beta_subgroup_reuse_attention import attention as fast_subgroup_attention
from saf3r.triton.beta_importance_finalize import finalize
from experiments.beta_unified.subgroup_model import observation
from scripts.quality_metrics import quality_record
OUT=ROOT/'outputs/beta_unified_20261108/fast_path_check';OUT.mkdir(exist_ok=True);rows=[]
torch.set_num_threads(2);torch.backends.cuda.matmul.allow_tf32=False
with torch.inference_mode():
 for layer in [1,12,22]:
  a=torch.load(ROOT/f'outputs/logit_transfer_failure_20261108/capture/layer{layer:02d}.pt',mmap=True,weights_only=True)
  q=a['q_full'].cuda();h,g,queries,d=q.shape;k=a['k'].cuda();v=a['v'].cuda();q=q.reshape(h,g*queries,d)[:,:k.shape[1]].contiguous();ids=a['source_ids'].cuda();grid=a['grid'].cuda();sizes=a['sizes'].cuda();patch=a['patches'].cuda();actual=patch[ids.clamp_min(0)].masked_fill(ids<0,-1).int().contiguous();special=a['specials'].cuda().int();qm=a['query_valid'].cuda();mask=qm.reshape(-1)[:q.shape[1]].contiguous();counts=qm.sum(1).float();mean=a['source_mean'].cuda();shift=(mean[:,:,0]+sizes.log()[None,None]).logsumexp(-1).contiguous()
  raw=a['exported_raw_groupmean'].cuda();old=raw_observe(mean,grid,sizes,ids,raw);new=finalize(mean,grid,sizes,ids,raw,logit=True);torch.testing.assert_close(new,old,rtol=1e-4,atol=2e-7)
  rows.append(dict(layer=layer,kind='raw_logit_normalizer',max_cache_difference=float((old-new).abs().max())))
  baseline_cache=None
  for kind in ['ones','compensated']:
   weights=torch.ones_like(ids,dtype=torch.float32).masked_fill(ids<0,0.) if kind=='ones' else a['actual_weights'].cuda().float().contiguous()
   ref,e=slow(q,k,v,actual,special,weights,a['scale'],mask,counts,True,4,1,shift)
   got,f=fast(q,k,v,actual,special,weights,a['scale'],mask,counts,True,4,2,shift)
   torch.testing.assert_close(got,ref,rtol=0.,atol=0.)
   old=moment_observe(mean,grid,sizes,ids,e['mean_exp']);new=finalize(mean,grid,sizes,ids,f['mean_exp'],shift=shift)
   torch.testing.assert_close(new,old,rtol=1e-4,atol=2e-7)
   if baseline_cache is None:baseline_cache=new
   else:torch.testing.assert_close(new,baseline_cache,rtol=1e-4,atol=2e-7)
   rows.append(dict(layer=layer,kind=kind,output_identical=True,max_cache_difference=float((old-new).abs().max()),compensation_undone=True))
  oracle=observation(a);mean4=oracle['mean'];counts4=qm.reshape(g,4,64).sum(2).float().contiguous();shift4=(mean4+sizes.log()[None,None,None]).logsumexp(-1).contiguous()
  ref,e=subgroup_attention(q,k,v,actual,special,weights,a['scale'],mask,counts4,True,4,1,shift4)
  got,f=fast_subgroup_attention(q,k,v,actual,special,weights,a['scale'],mask,counts4,True,4,2,shift4)
  torch.testing.assert_close(got,ref,rtol=0.,atol=0.)
  old=subgroup_observe(mean4,grid,sizes,ids,e['mean_exp'],counts4);new=finalize(mean4,grid,sizes,ids,f['mean_exp'],counts=counts4,shift=shift4)
  torch.testing.assert_close(new,old,rtol=1e-4,atol=2e-7)
  rows.append(dict(layer=layer,kind='subgroup_with_incomplete_tail',output_identical=True,max_cache_difference=float((old-new).abs().max())))
  print('FAST_CHECK',layer,rows[-4:],flush=True)
(OUT/'result.json').write_text(json.dumps(dict(complete=True,checks=rows,quality=quality_record({},'Kernel/cache numerical check only;pose/recon not run;no paired Dense timing')),indent=2))
