"""Frozen candidate evaluation, no test-dependent choice inside the runner."""
import argparse,concurrent.futures,hashlib,json,os,queue,shutil,subprocess,sys,tarfile,threading,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
def main():
 p=argparse.ArgumentParser();p.add_argument('--dataset',choices=['eth3d','7scenes'],required=True);p.add_argument('--spec',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();out=a.output.resolve();out.mkdir(parents=True,exist_ok=False)
 spec=json.loads(a.spec.read_text());(out/'frozen_spec.json').write_text(json.dumps(spec,indent=2))
 ref=ROOT/('outputs/beta_global_logshrink_eth3d_20261108' if a.dataset=='eth3d' else 'outputs/beta_global_logshrink_7scenes128_20261108')
 shutil.copytree(ref/'expected_inputs',out/'expected_inputs');base=json.loads((ref/'config.json').read_text());tasks=queue.Queue()
 for name,c in spec['candidates'].items():
  dest=out/name;dest.mkdir();config=dict(base,**c.get('config_overrides',{}));(dest/'config.json').write_text(json.dumps(config,indent=2))
  for scene in spec['scenes']:tasks.put((name,c,scene))
 sources=list((ROOT/'saf3r/patch').glob('*.py'))+list((ROOT/'saf3r/triton').glob('*.py'))+list((ROOT/'experiments/beta_unified').glob('*.py'))
 hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources};(out/'source_sha256.json').write_text(json.dumps(hashes,indent=2))
 with tarfile.open(out/'source.tar.gz','w:gz') as tar:
  for path in hashes:tar.add(ROOT/path,arcname=path)
 lock=threading.Lock();done=[];running={}
 env=dict(os.environ,LD_LIBRARY_PATH=str(Path(sys.prefix)/'lib')+os.pathsep+os.environ.get('LD_LIBRARY_PATH',''),OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',PYTORCH_ALLOC_CONF='expandable_segments:True',PYTHONDONTWRITEBYTECODE='1')
 def status():
  temp=out/'progress.tmp';temp.write_text(json.dumps(dict(completed=done,running=running),indent=2));temp.replace(out/'progress.json')
 def worker(gpu):
  while True:
   try:name,c,scene=tasks.get_nowait()
   except queue.Empty:return
   folder=out/name/'runs'/scene
   cmd=[sys.executable,str(ROOT/'experiments/logit_eth3d/run_gpu_exclusive.py'),'--gpu',str(gpu),'--monitor',str(out/name/'monitors'/f'{scene}.json'),'--log',str(out/name/'logs'/f'{scene}.log'),'--',sys.executable,'-u',str(ROOT/'experiments/beta_unified/evaluate_final.py'),'--engine',c['engine'],'--head-chunk',str(c.get('head_chunk',32)),'--alpha',str(c['alpha']),'--tau',str(c['tau']),'--scene',scene,'--expected-input',str(out/'expected_inputs'/f'{scene}.json'),'--config',str(out/name/'config.json'),'--output',str(folder)]
   with lock:running[str(gpu)]=dict(candidate=name,scene=scene);status()
   begin=time.monotonic();code=subprocess.call(cmd,cwd=ROOT,env=env);r=folder/'result.json';complete=r.exists() and json.loads(r.read_text())['quality']['complete']
   with lock:done.append(dict(candidate=name,scene=scene,gpu=gpu,returncode=code,complete=complete,wall_seconds=time.monotonic()-begin));running.pop(str(gpu));status()
   print('DONE',name,scene,code,complete,flush=True)
   if code or not complete:raise RuntimeError(f'Incomplete {name}/{scene}')
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(worker,[4,5,6]))
 assert len(done)==len(spec['candidates'])*len(spec['scenes']) and all(x['complete'] for x in done)
 (out/'complete.json').write_text(json.dumps(dict(complete=True,runs=done),indent=2))
if __name__=='__main__':main()
